=== asset-pricing-factors__01of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/asset-pricing-factors__01of04/records.jsonl): **86 records in shard order**. JSON, IDs, schema, and **194 verbatim page-cited quotes** passed validation.

Relevance counts: **3: 10 · 2: 30 · 1: 45 · 0: 1**.

Ten promising transfer candidates follow. Evidence describes source support, not a demonstrated Deriv edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pooled ridge/elastic-net forecasts | `4058efa0eb3c` | ensemble | moderate | deriv-ticks |
| Shrink correlated forecast weights | `4058efa0eb3c` | ensemble | moderate | deriv-ticks |
| Compress features within meaningful families | `2a760b66b987` | features | moderate | deriv-ticks |
| Online jump-penalized regimes | `321c2a75e270` | regime | moderate | deriv-ticks |
| Simple linear variance benchmark | `3ef327b1416b` | magnitude | moderate | deriv-ticks |
| Multiple trailing realized-variance scales | `340de38f253c` | magnitude | moderate | deriv-ticks |
| Inspect calibration across forecast-score bins | `335bba7dca21` | calibration | moderate | deriv-ticks |
| Fixed trend/reversion forecast mixtures | `400da98388d4` | ensemble | moderate | deriv-ticks |
| Untouched final period after all tuning | `4058efa0eb3c` | validation | strong | deriv-ticks |
| Condition magnitude gates on scheduled announcements | `3e8139a8e978` | magnitude | moderate | external: announcement calendars |

Read limitations: thesis `111c34872b78` has an unusable main-body extraction; `30daa0aa797a` received a selective read under the over-length exception. All other relevant documents were read fully.

No convincing short-horizon FX evidence overturns the in-house priors. `3ef327b1416b` supports the magnitude-versus-sign distinction. Important internal contradictions: the early FOMC-cycle result reverses in later data, and historical currency seasonality loses significance on spot-only returns.
=== asset-pricing-factors__02of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/asset-pricing-factors__02of04/records.jsonl): **86 records**, in shard order.

Relevance counts: **3: 8 · 2: 22 · 1: 52 · 0: 4**. Depth: 26 full, 4 partial, 56 triage. No unreadable documents. JSON, schema, IDs and all 130 finding quotes/page citations passed verification.

The ten most promising transfers are below. Evidence refers to the cited method, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Bootstrap synchronized pairs in time blocks | `4632c345c3f7` | validation | strong | deriv-ticks |
| Refit all preprocessing inside temporal folds | `57ad36362906` | validation | strong | deriv-ticks |
| Log every candidate and correct for multiple testing | `55ba89d37bc1` | validation | strong | deriv-ticks |
| Benchmark magnitude gates against GARCH/realized variance | `608f81cc3ced` | magnitude | moderate | deriv-ticks |
| Compare target-aware dimension reduction with PCA | `5027d1d9a116` | features | moderate | deriv-ticks |
| Average regularized models under model uncertainty | `5e3a0a13620d` | ensemble | moderate | deriv-ticks |
| Pool standardized rare events across pairs | `70cef11d13a8` | regime | moderate | deriv-ticks |
| Shrink probabilities toward training-only base rates | `771e322b60f8` | calibration | moderate | deriv-ticks |
| Combine penalization, early stopping and seed averaging | `80a5d931819b` | ensemble | moderate | deriv-ticks |
| Combine probabilities before applying one entry gate | `8464a1a2975b` | ensemble | moderate | deriv-ticks |

No finding directly overturns the in-house short-horizon FX priors. `82a15d9899ec` conditionally links external option-implied variance to monthly equity expected returns; it does not establish price-only FX sign prediction. `77ad11de4198` shows that genuine simulated predictability can remain unusable after estimation. The shard does not independently validate the reported in-house edges or tree-versus-deep-net ranking.
=== asset-pricing-factors__03of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/asset-pricing-factors__03of04/records.jsonl). All 86 records match shard order; JSON, schema and 122 source quotes passed validation.

Read by relevance: **3: 12 · 2: 17 · 1: 54 · 0: 2**. One additional relevance-1 document had no readable body.

Ten promising levers—all require only **`deriv-ticks`**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Signed-jump and heterogeneous-lag volatility forecasts | `8c645f702698` | magnitude | moderate |
| Parsimonious MIDAS variance filter | `c61ffeaa9f16` | magnitude | moderate |
| Shrink pair-specific calibration toward pooled estimates | `8db09bd2c9cb` | calibration | moderate |
| Compare regularized trees with shallow networks | `87684ca38b62` | ensemble | moderate |
| Regularized cross-pair lag features | `ace5d2354f14` | features | weak |
| Same-session continuation and cross-session reversal | `caa7108ca357` | direction | weak |
| Require fully matured training labels | `877b6bdef205` | validation | strong |
| Evaluate actual binary payout, ties and coverage | `b7c3ecc99226` | validation | strong |
| Test against the best result across all tried candidates | `8e51665772c2` | validation | strong |
| Require joint venue and period transfer | `968f0d62fb24` | validation | strong |

**Unreadable body:** `ae2e07ca1bf0`, *Explaining the Poor Performance of Consumption-Based Asset Pricing Models*. Only cover and abstract were available.

No convincing result contradicts the weak-FX-direction/stronger-magnitude prior. `be2fecac1d67` and `c61ffeaa9f16` qualify the blanket volatility-predicts-only-size claim through imposed drift or monthly in-sample equity results; neither establishes tradable FX sign accuracy.
=== asset-pricing-factors__04of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/asset-pricing-factors__04of04/records.jsonl): **85 records**, in shard order, containing 88 levers. Validation passed for JSON, IDs, schema and 107 verbatim page-cited quotes.

Relevance counts: **3: 8 · 2: 25 · 1: 49 · 0: 3**.

Reading depth: 13 full, 52 triage, **20 partial**. No files were unreadable, but full-read coverage is incomplete; each partial record identifies its omissions.

The ten most promising tests follow. Evidence grades concern the original method, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Run the entire model search under realistic null simulations | `fa97651efaf9` | validation | strong | Deriv ticks |
| Audit stale quotes and asynchronous cross-pair lead–lag | `20f12718fa37` | validation | strong | Deriv ticks |
| Test conditional coverage after magnitude gates | `98101d890c56` | calibration | strong | Deriv ticks |
| Forecast magnitude with high–low ranges and CARR | `98101d890c56` | magnitude | moderate | Deriv ticks |
| Mix volatility forecasts across plausible change times | `98101d890c56` | regime | moderate | Deriv ticks |
| Compare inverse forecast-variance weighting with existing losses | `e20772cae601` | loss | moderate | Deriv ticks |
| Ensemble models fitted on different past time blocks | `f35a9a4a4960` | ensemble | moderate | Deriv ticks |
| Benchmark additive splines with grouped shrinkage | `edda86aad909` | features | moderate | Deriv ticks |
| Benchmark random Fourier features with ridge | `d92e9b9b96fd` | features | moderate | Deriv ticks |
| Audit performance by UTC session, weekday and expiry | `e31145bfd182` | regime | moderate | Deriv ticks |

Two cautions qualify the in-house priors. Variance-weighted regression favors downweighting volatile observations, challenging indiscriminate absolute-return weighting, although the objectives differ. Regularized complex features succeed in a large monthly equity panel, qualifying blanket preferences for simpler models; this does not establish a short-horizon FX advantage.

No credible finding here overturns the magnitude-versus-sign distinction or directly validates the earlier direction edge.
=== backtesting-validation__01of09
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__01of09/records.jsonl): **48 records**, verified in shard order. All JSON parses; 150 quotations were checked against their cited pages.

Relevance counts: **3: 23 · 2: 17 · 1: 8 · 0: 0**. Reading depth: 39 full, 8 triage, 1 partial.

The ten most promising transferable levers follow. Evidence grades concern the method, **not demonstrated Deriv profitability**.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Enforce feature-source timestamp cutoffs | `032d5e116858` | validation | strong | deriv-ticks |
| Match labels to actual entry, expiry and tie losses | `1642bd288da0` | labels | strong | deriv-ticks |
| Register every trial and correct for multiple testing | `15e407e31867` | validation | strong | deriv-ticks |
| Include split and training-window selection in search correction | `1aad4641b287` | validation | strong | deriv-ticks |
| Account for serial dependence in performance uncertainty | `2042a6992ca9` | validation | strong | deriv-ticks |
| Fit calibration on purged out-of-fold predictions | `1db5e3d9f8bb` | calibration | moderate | deriv-ticks |
| Learn pair-to-pair pooling weights within training periods | `059a58499e6a` | ensemble | moderate | deriv-ticks |
| Average calibrated predictions across training seeds | `14d44435cc2e` | ensemble | moderate | deriv-ticks |
| Penalize additional fitted ensemble dimensions | `2080bb2a273e` | ensemble | moderate | deriv-ticks |
| Evaluate gates jointly by coverage, calibration and payout | `1642bd288da0` | selection-gating | strong | deriv-ticks |

No document was wholly unreadable. **Futuretesting** (`1d7677104518`) was read selectively; its partial record lists the chapters and pages covered.

Qualified challenges to the priors: DeepLOB reports seconds-level direction prediction from full order books, limiting broad “size only” language—but it requires unavailable external data. TabPFN sometimes beats boosted trees under severe label scarcity in a nonfinancial task. Neither establishes a tradable FX edge. No document independently validates the reported in-house fifteen-minute direction edge on Deriv.
=== backtesting-validation__02of09
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__02of09/records.jsonl): **48 records**, in shard order.

Relevance: **3: 18 · 2: 19 · 1: 11 · 0: 0**. Read depth: 37 full, 11 triage. JSON, schema, IDs, quote lengths and exact page quotations passed verification.

The ten most promising levers all use **`deriv-ticks`**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Compare complex models against volatility-scaled momentum/reversal | `31c669350865` | validation | strong |
| Use null data preserving persistence and volatility | `31c669350865` | validation | strong |
| Nest signal signing, selection and ensemble fitting | `3d17670a8372` | validation | strong |
| Register every research trial | `27ad8fdc1189` | validation | strong |
| Use paired calendar-block uncertainty intervals | `39d069e11fa8` | validation | strong |
| Measure power to detect payout-relevant edges | `384c08facf8b` | validation | strong |
| Adapt magnitude quantiles using matured errors | `213e185728ed` | calibration | moderate |
| Recalibrate move-weighted models on original binary outcomes | `263ef4b69eca` | calibration | moderate |
| Evaluate proper scores, payout and gate coverage together | `340524a48f2b` | validation | strong |
| Monitor bounded score differences with valid e-processes | `3cb2b10b2bf7` | validation | moderate |

Evidence grades support the methodological lever, not demonstrated Deriv profitability.

No document was wholly unreadable. Damaged equations and missing chart content are noted.

No convincing direct contradiction overturns the in-house direction/magnitude or simplicity priors. Important qualifications: outcome-weighted losses can change the probability being estimated; ensemble construction consumes search degrees of freedom; and papers disagree sharply about published equity false-discovery rates.
=== backtesting-validation__03of09
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__03of09/records.jsonl): **48 records**, verified JSON, shard order, IDs and page quotes.

Relevance counts: **3: 17 · 2: 20 · 1: 7 · 0: 4**. Reading depth: 36 full, 11 triage, one partial. None unreadable. Partial: `5651f5643a79`; main text and proof read, extensive appendices not fully read.

The ten most promising levers follow. Evidence grades concern the method; Deriv profitability remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Independently implement settlement replay | `5534d89aced8` | validation | moderate | deriv-ticks |
| Audit UTC alignment and causal cross-pair joins | `4ead229772f9` | validation | moderate | deriv-ticks |
| Record every research trial | `42cbced57a0b` | validation | moderate | deriv-ticks |
| Include payout, ties and latency during selection | `5875aec75d7c` | selection-gating | strong | deriv-ticks |
| Test clustering features against nonstationary nulls | `4e8e1dbe197b` | validation | strong | deriv-ticks |
| Simulate finite-sample magnitude-model ranking errors | `52ceccfe4deb` | validation | strong | deriv-ticks |
| Pair global comparisons with local break diagnostics | `4fc8cf2ba5fb` | validation | strong | deriv-ticks |
| Control prospective discoveries using valid e-values | `56824184589c` | validation | strong | deriv-ticks |
| Shrink pair/horizon effects toward past-only pooled priors | `50af54b7a964` | calibration | moderate | deriv-ticks |
| Diversify ensembles using blocked training masks | `4dc20f88dd56` | ensemble | moderate | deriv-ticks |

Nothing directly refutes the reported in-house AUCs. The strongest contrary trading evidence is failed technical-rule persistence after costs (`5875aec75d7c`). Inverse-variance weighting (`511280b328f2`) offers an alternative to magnitude weighting, but its evidence concerns factor inference, so it does not establish superiority for our prediction task.
=== backtesting-validation__04of09
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__04of09/records.jsonl): **48 records**, in shard order.

Relevance: **3: 25 · 2: 19 · 1: 4 · 0: 0**. Read 44 fully and triaged four. None unreadable. JSON, schema, ordered IDs, and numerical quotations passed validation.

Ten most promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Exact endpoint and tie-loss fixtures | `620df6f57509` | labels | strong | deriv-ticks |
| Common temporal cutoffs across pairs and resampled views | `706726ee007d` | validation | strong | deriv-ticks |
| Enforce feature availability and label maturity | `728265cb3c46` | validation | strong | deriv-ticks |
| Exhaustive search ledger and sealed future evaluation | `6185ded9e2ce` | validation | strong | deriv-ticks |
| Studentized joint bootstrap and stepdown testing | `70954e9cf356` | validation | strong | deriv-ticks |
| Planted-edge and matched-null power checks | `59b31b7055a5` | validation | moderate | deriv-ticks |
| Pool pairs with constrained pair-specific deviations | `5e66848c6662` | ensemble | moderate | deriv-ticks |
| Separate past calibration window; freeze subsequent thresholds | `5bfbe2125501` | calibration | moderate | deriv-ticks |
| Compare maximum-probability gating against ensemble uncertainty | `5bfbe2125501` | selection-gating | moderate | deriv-ticks |
| Test Hurst/multifractal statistics against matched surrogates | `6e96f1f1eabe` | validation | strong | deriv-ticks |

“Strong” here supports the validation principle, not demonstrated FX profitability.

The shard challenges guaranteed ensemble benefits: the order-book benchmark’s ensembles failed to beat its best individual model. Calibration also deteriorated under distribution shift. Nothing directly validates or refutes the in-house intraday FX estimates, and no credible result contradicts the size-versus-sign prior.
=== backtesting-validation__05of09
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__05of09/records.jsonl): **48 records**, matching shard order, with exact page quotes checked.

Relevance: **3: 20 · 2: 19 · 1: 9 · 0: 0**. Depth: 36 full, 9 triage, 3 explicit long-document chapter selections. No unreadable files.

The ten most promising levers are mainly improvements to evaluation:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Replay archived live features at identical timestamps | `80341a396083` | validation | strong | Deriv ticks |
| Evaluate the entire strategy-selection procedure on future periods | `7c6e69f57163` | validation | strong | Deriv ticks |
| Use paired studentized time-block bootstrap intervals | `87492bc3317f` | validation | strong | Deriv ticks |
| Shrink winner performance using the complete search history | `87bff2a60cdc` | validation | moderate | Deriv ticks |
| Calculate AUC within held-out periods before averaging | `7b8ec26185d9` | validation | strong | Deriv ticks |
| Compare boosted trees with small embedded MLP seed ensembles | `8aebc851f8e4` | ensemble | moderate | Deriv ticks |
| Test regularized cross-pair HAR magnitude forecasts | `8caba795e887` | magnitude | moderate | Deriv ticks |
| Prefer simpler models among statistically indistinguishable candidates | `91e1ddde55d1` | validation | moderate | Deriv ticks |
| Train an out-of-fold prediction-quality gate | `92282b2bffe1` | selection-gating | moderate | Deriv ticks |
| Preserve cross-pair covariance when comparing model losses | `924b1ef01748` | validation | strong | Deriv ticks |

Nothing directly validates or refutes the reported Deriv direction or magnitude edges. Cross-domain evidence cautions that indiscriminate pooling can hurt and uncertainty gates can miss confidently wrong predictions. TabReD supports strong tree baselines while finding small neural models competitive; the Hawkes studies reinforce the distinction between activity and direction.

The chapter-selected documents are the cryptocurrency thesis (`859409ae503c`), high-dimensional portfolio paper (`8af6ee79f224`), and *Replicating Anomalies* (`8d00169a4cf6`). Their reading limits are recorded explicitly.
=== backtesting-validation__06of09
Saved **48 ordered records and 96 levers** in [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__06of09/records.jsonl). JSON, shard order, IDs, numerical citations and verbatim quotes all pass validation.

Relevance counts: **3: 23 · 2: 20 · 1: 5 · 0: 0**. Reading depth: **42 full, 5 triage, 1 partial**.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Match labels to executable entry and expiry | `9cee9c704ce5` | labels | strong | deriv-ticks |
| Audit the entire pipeline on structured nulls and positive controls | `9b6cdb6b2894` | validation | strong | deriv-ticks |
| Purge overlapping samples; fit preprocessing within training | `9620234e93b9` | validation | strong | deriv-ticks |
| Joint block-bootstrap stepdown comparisons | `aa990b005802` | validation | strong | deriv-ticks |
| Verify settlement code against independent reference traces | `b1fd0d048a94` | validation | strong | deriv-ticks |
| Partially pool pair-specific effects and calibration | `95807b0cc262` | calibration | moderate | deriv-ticks |
| Benchmark magnitude with realized-variance autoregressions | `9d7b12ba6e30` | magnitude | moderate | deriv-ticks |
| Condition magnitude calibration on UTC session | `b76d6e398d16` | magnitude | moderate | deriv-ticks |
| Measure error diversity before stacking models | `99293b5ad6ab` | ensemble | moderate | deriv-ticks |
| Test incremental direction information from volume imbalance | `9cee9c704ce5` | direction | moderate | external: aligned order-book volumes |

Evidence describes source support, not demonstrated Deriv profitability.

No document was wholly unreadable. **`b2097b1630d5` remains partial** because equations and heatmaps are missing from its extracted text.

The shard qualifies several in-house priors: deep models beat trees on a raw order-book benchmark; external imbalance supplies some short-horizon sign information; and learned ensembles sometimes fail to beat their best member. These results do not establish an edge for Deriv’s price-only, fixed-expiry task. Several papers reinforce the distinction between magnitude prediction and sign prediction.
=== backtesting-validation__07of09
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__07of09/records.jsonl): **48 records**, in shard order. JSON, schema, quote lengths, and exact page-quote matches passed verification.

Relevance counts: **3: 23 · 2: 15 · 1: 10 · 0: 0**. Reading depth: **10 full, 28 partial, 10 triage**. No files were missing or unreadable; **the whole-document reading requirement remains unfinished for the partial records**.

The ten most promising levers recorded are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Frequently refitted HAR baseline | cf6626522251 | magnitude | Moderate | deriv-ticks |
| Robust Huber-EWMA baseline | c1b94c6c2e98 | magnitude | Moderate | deriv-ticks |
| Proxy-robust QLIKE evaluation | b9b5bc512661 | loss | Strong | deriv-ticks |
| Fit preprocessing within each fold | c433bceda841 | validation | Strong | deriv-ticks |
| Repeated chronological holdouts | ccc008eb7834 | validation | Strong | deriv-ticks |
| Correct for training-window search | c9051693ef04 | validation | Strong | deriv-ticks |
| Retain a model confidence set | c4abc4759af8 | validation | Strong | deriv-ticks |
| Bootstrap Reality Check for calendar filters | c058bfbc1bfe | validation | Strong | deriv-ticks |
| Compare calibrated singles and ensembles | cf7276efa861 | calibration | Moderate | deriv-ticks |
| Test incremental ensemble information | c16212e647ec | ensemble | Moderate | deriv-ticks |

Evidence grades concern the source methods, not demonstrated Deriv profitability.

The main qualifications to the priors are:

- Carefully refitted HAR models beat boosted trees in the reviewed daily equity-volatility study; tree superiority is not universal.
- Random CV was competitive under stationarity in one study. That study did not compare purged CPCV.
- Calibration outweighed ensemble size in a medical dataset, without directly testing seed ensembles.
- Reviewed evidence does not validate the earlier FX direction edge. The weather-betting paper’s broad impossibility claims are unsupported and its trade counts conflict.
=== backtesting-validation__08of09
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__08of09/records.jsonl): **48 records**, in shard order. JSON, schema and quotation checks passed.

Relevance counts: **3: 26 · 2: 16 · 1: 6 · 0: 0**. Read fully: 42; triaged: 6. Unreadable: none.

Ten most promising levers follow. Evidence strength concerns the method, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit UTC, daylight saving and settlement boundaries | e79d830a74bc | validation | strong | deriv-ticks |
| Nest feature selection, tuning, calibration and gating | db01ac8fabef | validation | strong | deriv-ticks |
| Joint block-bootstrap correction across all trials | da2f9ac31d1d | validation | strong | deriv-ticks |
| Diagnose selection overfitting using candidate payoff streams | d8bfbadaaedb | validation | strong | deriv-ticks |
| Run the entire search on known-null surrogate prices | d68b5881833a | validation | strong | deriv-ticks |
| Test sensitivity across defensible preprocessing choices | dbdf6f57cbfb | validation | strong | deriv-ticks |
| Shrink estimated edges within model families | d338d13e0830 | ensemble | moderate | deriv-ticks |
| Use realized variance as an auxiliary magnitude target | e65a30684b79 | labels | strong | deriv-ticks |
| Benchmark parsimonious multiscale variance models | ecac6c357d71 | magnitude | moderate | deriv-ticks |
| Audit conformal coverage and accepted-trade payout under drift | d9ac8df150eb | selection-gating | moderate | deriv-ticks |

The shard cautions against universal tree or ensemble superiority and shows that calibration and conformal coverage can fail under distribution shift. Volatility findings support magnitude forecasting, while distinguishing path variance from endpoint magnitude. Nothing here cleanly confirms or refutes the earlier direction edge.
=== backtesting-validation__09of09
Wrote and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/backtesting-validation__09of09/records.jsonl): **46 records**, in shard order, with **132 verified page quotes** and **94 levers**.

Relevance: **3: 18 · 2: 23 · 1: 5 · 0: 0**. Unreadable: none. Two long documents received selective reads, documented in their records.

The ten most promising levers all use **Deriv ticks**. Evidence strength concerns the method, not proof of a trading edge.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Rebuild exact settlement labels | `f9549a783874` | labels | moderate |
| SPA testing across all tried alternatives | `fb5ada1987f8` | validation | strong |
| Paired temporal-block uncertainty | `d1027b6d4555` | validation | strong |
| Check model ranks across periods and pairs | `f58f273e3f72` | validation | strong |
| Intraday seasonality and lagged-volatility baseline | `f5d5c7a9a782` | magnitude | moderate |
| Conditional calibration plus proper scoring | `fc9fdf24c070` | calibration | strong |
| Ensemble weights shrunk toward equality | `f188b4fc0a19` | ensemble | moderate |
| Pool and shrink noisy edge estimates | `fc2b69280ad1` | calibration | moderate |
| Replay the complete search on directionless nulls | `d1027b6d4555` | validation | strong |
| Audit extreme-contribution observations | `fb37d1443bcc` | validation | strong |

Qualifications to the in-house priors: a selected ensemble underperformed simpler alternatives; weighting can reverse model rankings; ordinary CV has a restrictive stationary-autoregression exception that does not establish validity for our overlapping binary labels. Nothing here independently confirms the earlier direction edge or overturns the magnitude-versus-sign distinction.
=== behavioral-finance-retail__01of05
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/behavioral-finance-retail__01of05/records.jsonl): **46 records**, in shard order. JSON, schema and all **74 verbatim page-cited quotes** verified.

Relevance: **3 → 3 documents; 2 → 12; 1 → 28; 0 → 3.** Fifteen received full reads. None unreadable.

The ten most promising levers are below. All use **Deriv ticks**; forecasting transfers remain unproven.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Prefix-only replay to detect future-dependent features | `18cbdcda47d2` | validation | strong |
| Score every settled signal, charging payout and ties | `2e9ce70a8c88` | validation | strong |
| Account for overlapping labels using independent time blocks | `12581606f527` | validation | moderate |
| Adjust performance claims for all attempted variants | `057c3319013d` | validation | moderate |
| Check probability coherence for fixed-entry, fixed-expiry events | `260484a62300` | validation | moderate |
| Calibrate ensemble disagreement with an error floor | `303df836f5b9` | calibration | weak |
| Test USD-aligned cross-pair lagged returns | `1d04bc9c7bc5` | features | weak |
| Test round-level distances against shifted-grid placebos | `2564dc165878` | features | weak |
| Calibrate separately by signal strength and horizon | `260484a62300` | calibration | weak |
| Compare latent-state volatility with simple magnitude gates | `270eef8f9db9` | magnitude | weak |

No direct contradiction of the in-house FX results emerged. Latent-state evidence chiefly supports magnitude prediction. Correlated forecast errors caution that ensemble agreement alone does not establish confidence or calibration. No document replicates the reported FX performance or establishes an executable Deriv direction edge.
=== behavioral-finance-retail__02of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/behavioral-finance-retail__02of05/records.jsonl). Validated **46 records**, exact shard order, valid JSON and **89 page-matched quotations**.

Relevance counts: **3: 5 · 2: 19 · 1: 20 · 0: 2**. Reading depth: 21 full, 3 partial, 22 triage.

The ten most promising levers to test are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Random-sign controls preserving volatility | `3f283a4dc2ff` | validation | moderate | deriv-ticks |
| Account for overlapping labels and shared events | `4bec5de21223` | validation | moderate | deriv-ticks |
| Exact settlement and payout ledger | `60dabde09855` | labels | moderate | deriv-ticks |
| Judge ensembles by held-out Brier and error covariance | `4bec5de21223` | ensemble | moderate | deriv-ticks |
| Correct for feature, lag and horizon searches | `5d932b622ee5` | validation | moderate | deriv-ticks |
| Audit stale ticks and apparent lead–lag effects | `5be902faf5b4` | validation | moderate | deriv-ticks |
| Lagged cross-pair residuals after common-USD controls | `5be902faf5b4` | features | weak | deriv-ticks |
| Multiscale absolute-return and burst-decay features | `33c620959deb` | magnitude | weak | deriv-ticks |
| Anchor displacement × volatility/skewness interactions | `6b64a55fa021` | features | weak | deriv-ticks |
| Incremental retail-flow signals | `3bc16d953e4e` | data | weak for FX | external: FX retail flow |

No files were unreadable. Partial reads: `3aec66794106` and `6b64a55fa021` used the long-document exception; `5c3ab39841b6` had its complete English version read, with the Chinese version partly inspected. Extraction limitations are recorded.

Nothing validates or directly overturns the in-house FX performance estimates. External retail equity flow does predict some subsequent returns, qualifying the blanket order-flow/sign prior. Persona-driven ensemble diversity failed to improve accuracy; uncertainty-based reversal claims were anecdotal.
=== behavioral-finance-retail__03of05
Wrote and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/behavioral-finance-retail__03of05/records.jsonl): **46 records**, in shard order, with finding quotes checked against source pages.

Relevance counts: **3: 8 · 2: 4 · 1: 33 · 0: 1**. Eleven documents were read fully; one long document (`6d0331209554`) partially. None were unreadable.

The ten most promising levers—evidence grades support the stated mechanism or evaluation practice, not a demonstrated Deriv edge:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Freeze strategy rankings before future-period evaluation | `94495a6b4a81` | validation | strong | Deriv ticks |
| Account for every expiry outcome, including ties | `94495a6b4a81` | labels | strong | Deriv ticks |
| Correct for all tested variants | `6d0331209554` | validation | moderate | Deriv ticks |
| Report actual trade-weighted, pair and period performance | `7dc4fece5b20` | validation | moderate | Deriv ticks |
| Audit timestamps and information availability | `971e7a9bb64c` | validation | moderate | Deriv ticks |
| Test each tradable horizon separately | `971e7a9bb64c` | validation | moderate | Deriv ticks |
| Bound calibration updates using matured errors | `6d0331209554` | calibration | weak | Deriv ticks |
| Test multiscale trend/reversal context | `7ba0420c97c8` | features | weak | Deriv ticks |
| Detect shifts in trailing risk features with CUSUM | `901faaaa247b` | regime | weak | Deriv ticks |
| Separate signed flow by investor size | `9ab697112680` | direction | moderate | External: identified FX transactions |

Signed equity-flow results qualify the blanket “order flow predicts size only” prior, and `94495a6b4a81` finds rare persistent trader skill after costs. Neither establishes price-only FX predictability. No document independently validates the in-house AUC claims or demonstrates a Deriv binary-contract edge.
=== behavioral-finance-retail__04of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/behavioral-finance-retail__04of05/records.jsonl): **46 records**, in shard order, with 84 verified page-matched quotations and 40 levers.

Relevance counts: **3: 5 · 2: 12 · 1: 28 · 0: 1**. Reading depth: 15 full, 2 partial, 29 triaged.

The ten highest-priority test candidates are below. Evidence grades describe transfer support, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shrink noisy model/pair skill before ensembling | aa6802a2c6e0 | ensemble | Moderate | deriv-ticks |
| Compare adaptive updates with frozen/random controls | b5d19f4d4ae7 | validation | Moderate | deriv-ticks |
| Check interval coverage by volatility regime | a825892ac91c | calibration | Moderate | deriv-ticks |
| Combine proper density scores with calibration diagnostics | cd390a03b7f2 | validation | Moderate | deriv-ticks |
| Audit tie-aware labels and complete payoffs | a8438c277751 | labels | Moderate | deriv-ticks |
| Correct multiple link tests and require subsequent stability | c4e0e8ecddfe | validation | Moderate | deriv-ticks |
| Interact price impulses with lagged price anchors | acd1b99869eb | features | Weak | deriv-ticks |
| Add rolling absolute-return extremes to magnitude models | bba663b19714 | magnitude | Weak | deriv-ticks |
| Test reversal after extreme crowded retail buying | cb823f6f741b | direction | Weak | external: retail FX flow |
| Build release-specific magnitude gates | bba663b19714 | selection-gating | Weak | external: macro release calendar |

No files were missing. **a6f841b429f0** was only partially readable because its extracted text is severely truncated. **cbd5693d40d8** received a section-based partial read under the long-document exception.

Two findings qualify the priors: signed retail equity flow sometimes predicts subsequent direction, so a universal order-flow-only-predicts-size claim is too broad. Also, apparent adaptive-calibration improvement can reflect regression to the mean, while better calibration-test results can accompany worse proper forecast scores. Neither establishes nor refutes the earlier short-horizon FX performance figures.
=== behavioral-finance-retail__05of05
Wrote and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/behavioral-finance-retail__05of05/records.jsonl): **46 records**, exact shard order, valid JSON, and **85 quotes matched to cited pages**.

Relevance counts: **0: 2 · 1: 24 · 2: 16 · 3: 4**

Ten promising levers below. Evidence grades describe support for the proposed transfer; none establishes a profitable Deriv FX signal.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Test selected models’ persistence in later periods | `62a912d5d261` | validation | Moderate | Deriv ticks |
| Account for overlapping labels and cross-pair dependence | `723c42d3f631` | validation | Moderate | Deriv ticks |
| Define regimes causally; test the selection pipeline on null paths | `955993ff64c9` | validation | Moderate | Deriv ticks |
| Test downside/upside semivariance separately | `dc29c8e00da3` | magnitude | Weak | Deriv ticks |
| Normalize target returns against a basket excluding that pair | `f492a05910b8` | features | Weak | Deriv ticks |
| Add scaled trailing high–low range | `fc061a32c7ea` | magnitude | Weak | Deriv ticks |
| Include a no-edge component alongside trend/reversal regimes | `19031d39cbc4` | regime | Weak | Deriv ticks |
| Model fast/slow volatility and time since a shock | `b7e0f43acd80` | magnitude | Weak | Deriv ticks |
| Compare equal averaging with heavily shrunk historical-performance weights | `b7e0f43acd80` | ensemble | Weak | Deriv ticks |
| Condition signed retail flow on retail participation | `f71702a6e4c6` | direction | Weak | External: signed FX trades, participation, venue |

No document was wholly unreadable. **`efab30221db4`**, *Day Trading for a Living?*, has severely truncated body text and is recorded as partial. Selected chapters of long books are also explicitly marked partial.

Nothing directly tests or contradicts the in-house AUC figures. Some studies report future equity-return predictability from signed retail flow, qualifying a blanket size-only interpretation of flow information; they provide no corresponding intraday FX binary accuracy. The shard also shows that documented investor biases can coexist with little tradable predictability.
=== commodities-futures__01of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/commodities-futures__01of06/records.jsonl): **44 records**, in shard order.

Relevance counts: **3: 11 · 2: 17 · 1: 15 · 0: 1**. Completed 28 full reads and 16 triages. Verified JSON/schema, IDs, and 110 verbatim page-cited quotes. No unreadable documents; OCR limitations are flagged.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Evaluate proper probability scores alongside exact binary payoff | `0b45efef4c8d` | validation | strong | Deriv ticks |
| Apply asymmetric online conformal corrections | `079032e00b66` | calibration | moderate | Deriv ticks |
| Weight calibration errors by session and volatility context | `232c26e98c41` | calibration | moderate | Deriv ticks |
| Use regularized, multiscale HAR magnitude models | `0ae5d53c1e50` | magnitude | moderate | Deriv ticks |
| Pool magnitude-quantile slopes across pairs | `1037c68e0e3a` | magnitude | moderate | Deriv ticks |
| Fit constrained same-quantile ensemble weights | `07aa980298ca` | ensemble | moderate | Deriv ticks |
| Select ensemble members by complementary errors | `08e7db4161c1` | ensemble | moderate | Deriv ticks |
| Compare seed ensembles with dropout uncertainty | `11ae28ebefb7` | ensemble | moderate | Deriv ticks |
| Compare noise-aware realized-variance estimates | `1dc287814d56` | magnitude | moderate | Deriv ticks |
| Keep elastic-net and seasonal baselines mandatory | `01d6cb968526` | validation | moderate | Deriv ticks |

Evidence grades describe the source evidence, **not demonstrated FX profitability**.

No robust result overturns the in-house priors. Qualified exceptions are in-sample equity-index return predictability from positioning (`1dc287814d56`) and one claimed oil turning-date success (`1afa8aa1a5dd`).

Two findings temper existing practices: profit-oriented optimization can distort probabilities, and conformal proxy-risk control does not guarantee selected-trade profitability. Neither invalidates gating, but both require separate calibration and payoff checks.
=== commodities-futures__02of06
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/commodities-futures__02of06/records.jsonl): **44 records in shard order**, with 123 verified page-cited quotations.

Relevance: **3: 6 · 2: 22 · 1: 16 · 0: 0**. Full reads: 28; triage: 16. Unreadable documents: none.

The ten most promising levers are below. Evidence reflects the source studies; FX transfer remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Validation gaps and blocks accounting for overlapping targets | `29067b55ff80` | validation | Strong | Deriv ticks |
| Calibrate final probabilities after ensemble/gate transformations | `388dcdefa737` | calibration | Moderate | Deriv ticks |
| Pool calibration with small pair/session effects | `388dcdefa737` | calibration | Moderate | Deriv ticks |
| Model exact zero returns explicitly for ties | `388dcdefa737` | labels | Moderate | Deriv ticks |
| Multiscale volatility with regularized cross-pair residual features | `29067b55ff80` | magnitude | Moderate | Deriv ticks |
| Train direct entry-to-expiry targets | `3231f5d321a1` | labels | Moderate | Deriv ticks |
| Reconcile horizon returns using shrunk error covariance | `3231f5d321a1` | ensemble | Moderate | Deriv ticks |
| Regularized cyclic quantile regression | `3d7fc5b57857` | loss | Moderate | Deriv ticks |
| Adapt history windows and cross-pair subsets | `4a65162ebeac` | regime | Moderate | Deriv ticks |
| Empirical distribution body plus threshold-stable Pareto tail | `4bff00ca9714` | magnitude | Moderate | Deriv ticks |

No robust result overturns the weak-sign/strong-magnitude prior. Some energy papers report LLM gains, but their validation and baseline comparisons do not establish superiority over tuned trees on FX. Leakage risks, overlapping targets, and metric-dependent model rankings recur throughout the shard.
=== commodities-futures__03of06
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/commodities-futures__03of06/records.jsonl): **44 records**, validated for shard order, JSON structure, and verbatim page-cited findings.

Relevance counts: **3: 11 · 2: 19 · 1: 12 · 0: 2**. No unreadable documents; corrupted figure text is noted where applicable.

The ten most promising levers for testing are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Sparse online Student-t location/scale model | `6fd75fa96293` | calibration | moderate | deriv-ticks |
| Low-rank averaging across training windows | `67b5cf157233` | ensemble | moderate | deriv-ticks |
| Ensemble-disagreement normalization | `67b5cf157233` | calibration | moderate | deriv-ticks |
| Bernstein online model aggregation | `732fb75a720e` | ensemble | moderate | deriv-ticks |
| Warm starts with recent-window replay | `732fb75a720e` | regime | moderate | deriv-ticks |
| Causal reweighting of historical paths | `6676695c68d9` | calibration | moderate | deriv-ticks |
| Monotone quantile heads versus simple sorting | `7927c5f55e5a` | calibration | moderate | deriv-ticks |
| Small residual-bias correction model | `77e12923b5ac` | calibration | moderate | deriv-ticks |
| Magnitude gating tested for conditional sign value | `67123d6d2716` | selection-gating | moderate | deriv-ticks |
| Conditional coverage and clustered-miss checks | `67b5cf157233` | validation | strong | deriv-ticks |

No convincing result overturns the in-house FX priors. Material cautions: learned ensemble weights sometimes underperform equal averaging; asymmetric losses can improve one-sided metrics through bias; and Hurst/HMM predictability claims do not establish individual FX sign accuracy at fixed expiry. None demonstrates the required Deriv binary edge.
=== commodities-futures__04of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/commodities-futures__04of06/records.jsonl): **44 records**, verified JSON, shard order, and numerical finding quotes/pages.

Relevance counts: **3: 8 · 2: 22 · 1: 12 · 0: 2**. Depth: 28 full, 14 triage, 2 partial.

Ten promising levers; all use **Deriv ticks**. Evidence grades concern the source findings, not proven FX profitability.

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Evaluate exact binary payoff and threshold calibration | `9323b3ee93eb` | validation | strong |
| Calibrate conformal scores at the actual horizon | `840ccd4f6fab` | calibration | moderate |
| Aggregate adaptive calibration experts | `840ccd4f6fab` | ensemble | moderate |
| Weight training samples by current-state similarity | `7e656d548d72` | regime | moderate |
| Average short- and long-history models | `7e656d548d72` | ensemble | moderate |
| Prefer compact distributional postprocessors initially | `a17f3914a4cb` | calibration | moderate |
| Add irreducible uncertainty beyond ensemble disagreement | `876ed6035527` | magnitude | moderate |
| Train stacking on chronological out-of-fold forecasts | `876ed6035527` | validation | strong |
| Pool related pairs with instrument/session covariates | `9323b3ee93eb` | ensemble | moderate |
| Preserve dependence across pair/horizon scenarios | `7e67e6c9ffdc` | calibration | moderate |

No document was wholly unreadable. Partial records: `7ee7a1c7d65c`—selected thesis chapters within budget; `9ae116d64a25`—substantive pages omitted or garbled in the supplied source.

No convincing contradiction to the in-house priors emerged. Zipf and chaos papers make stronger direction/determinism claims, but weak validation prevents accepting them. Adaptive conformal methods can fail coverage, and the neural results do not establish superiority over tuned boosted trees.
=== commodities-futures__05of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/commodities-futures__05of06/records.jsonl). All **44 records** parse, match shard order, and have verified page quotes for numerical findings.

Relevance: **3: 17 · 2: 13 · 1: 13 · 0: 1**. Thirty documents received full records; fourteen were triaged. **Unreadable: none.**

The ten most promising levers are below. Evidence describes source support; FX transfer remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Nonnegative-weight quantile stacking | c7f2185e54e4 | calibration | moderate | deriv-ticks |
| Explicit zero-return mass for ties | af51c4c30fbc | labels | moderate | deriv-ticks |
| Regularized conditional-scale forecasting | af51c4c30fbc | magnitude | moderate | deriv-ticks |
| Empirical standardized residual tails | a45a320098ef | magnitude | moderate | deriv-ticks |
| Conditional PIT and dependence diagnostics | b46282d6b6f2 | calibration | strong | deriv-ticks |
| Recalibrate conformal intervals across regimes | c41f1d79d42d | calibration | moderate | deriv-ticks |
| Pool pairs with identity and normalized features | ab18a5dc2db6 | features | moderate | deriv-ticks |
| Diversify ensembles beyond random seeds | c1d39a2bf19e | ensemble | moderate | deriv-ticks |
| Test modest magnitude-weighted losses | c1d39a2bf19e | loss | moderate | deriv-ticks |
| Replay exact entry, expiry and losing ties | ccc953e354f7 | validation | strong | deriv-ticks |

The main challenges to the in-house priors are conditional: **c7f5b3b62b6a** favors neural models over boosted trees using external order-derived data, while **c41f1d79d42d** demonstrates conformal undercoverage after a regime shift. Neither establishes an FX sign edge. Hurst/entropy direction claims lack convincing forecast validation, and the spectacular long-memory hybrid results contain substantial methodological inconsistencies.
=== commodities-futures__06of06
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/commodities-futures__06of06/records.jsonl): **39 records**, verified in shard order, with **102 page-matched quotes** and **67 levers**.

Relevance counts: **3: 5 · 2: 16 · 1: 16 · 0: 2**.

The ten most promising test candidates:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Select gates using actual payoff, charging ties | d84005f1a87f | validation | strong | Deriv ticks |
| Remove clock-time volatility seasonality | d84005f1a87f | magnitude | moderate | Deriv ticks |
| Ensemble short and long training windows | d9e9d397ad94 | ensemble | moderate | Deriv ticks |
| Stack corresponding quantile forecasts | d9e9d397ad94 | calibration | moderate | Deriv ticks |
| Compare expectile and quantile stacking | efe861d4a24f | ensemble | moderate | Deriv ticks |
| Fit small additive location-scale-shape models | dd07d5034b65 | calibration | moderate | Deriv ticks |
| Enforce coherent quantile ordering | e506b213147e | calibration | moderate | Deriv ticks |
| Pool cross-pair volatility information | f748da82e3b0 | magnitude | moderate | Deriv ticks |
| Test aligned cross-pair return lags | e95d16139620 | features | moderate | Deriv ticks |
| Calibrate confidence-based trade selection | e95d16139620 | selection-gating | moderate | Deriv ticks |

No document was wholly unreadable. **d9e9d397ad94** is partial because pages **20–23 and 28–29** contain corrupted/truncated text.

Nothing credibly overturns the FX priors. The main counterpoint is electricity direction improvement from external order-book inputs in **e95d16139620**. Entropy/HMM studies do not establish price-sign prediction, while strong neural/news claims have leakage or weak evaluation. No document demonstrates a tradable Deriv edge.
=== computing-software__01of04
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/computing-software__01of04/records.jsonl): **69 records**, in shard order, with exact source quotes checked.

Relevance counts: **3: 1 · 2: 10 · 1: 33 · 0: 25**. Eleven full reads; 58 triaged. No unreadable documents.

The ten most promising levers are below. Evidence supports the source mechanism; FX transfer remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Replay observed ticks for intrabar decisions | `5a04f87112b3` | validation | moderate | deriv-ticks |
| Reconstruct features strictly as of decision time | `50b66c076b00` | validation | moderate | deriv-ticks |
| Audit all timestamp handling against UTC | `040aec7589ee` | validation | moderate | deriv-ticks |
| Compare raw and causally flagged data | `57a8831bc94e` | validation | moderate | deriv-ticks |
| Compare proper-score training with accuracy optimization | `1aa62d318690` | loss | moderate | deriv-ticks |
| Validate confidence gates across retained coverage | `1aa62d318690` | selection-gating | moderate | deriv-ticks |
| Pool small return-distribution models across pairs | `2cb8ca03bf1f` | magnitude | moderate | deriv-ticks |
| Benchmark recency-weighted empirical return distributions | `2cb8ca03bf1f` | magnitude | moderate | deriv-ticks |
| Predict expiry-horizon quantiles directly | `2cb8ca03bf1f` | labels | weak | deriv-ticks |
| Use period/pair holdouts with overlapping observations purged | `08ce8e3a9a86` | validation | moderate | deriv-ticks |

No direct contradiction of the in-house FX priors emerged. Relevant cautions: a simple empirical forecaster slightly beat DeepAR on daily-return distribution forecasts; correctness-only training damaged confidence reliability in a nonfinancial task; regime routing failed to beat a fixed learned selector. None establishes an out-of-sample FX direction edge.
=== computing-software__02of04
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/computing-software__02of04/records.jsonl): **69 records**, in shard order, with valid JSON and checked quotation/page matches.

Relevance counts: **0: 28 · 1: 28 · 2: 12 · 3: 1**. Reading depth: 10 full, 3 partial, 56 triage.

The ten most promising levers are mostly validation improvements; this shard establishes no short-horizon FX edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Sequentially score probabilities fixed before outcomes | 9759388a9544 | validation | Moderate | Deriv ticks |
| Account for overlapping trades and shared-pair dependence | 9759388a9544 | validation | Moderate | Deriv ticks |
| Pool pair/period estimates with heterogeneity and shrinkage | 9759388a9544 | validation | Moderate | Deriv ticks |
| Measure ensemble error covariance and incremental benefit | 9759388a9544 | ensemble | Moderate | Deriv ticks |
| Reconstruct entry, expiry and ties from observed ticks | 8d96afedf0d5 | labels | Weak | Deriv ticks |
| Initialize indicators causally before using them | 633a241a5619 | validation | Weak | Deriv ticks |
| Fit preprocessing and selection within training folds | 7b3c2b686109 | validation | Weak | Deriv ticks |
| Constrain neural capacity with regularization and early stopping | 8763743a874f | loss | Weak | Deriv ticks |
| Test shared FX encoders with limited fine-tuning | 8763743a874f | features | Weak | Deriv ticks |
| Audit simulated outcomes against actual contracts | 676265c0d5ef | validation | Weak | External: Deriv order/settlement logs |

No files were missing or wholly unreadable. **980fa0c2f3b3** has substantial OCR damage and received a partial record; two long documents received selected-section readings.

No direct empirical contradiction of the in-house priors emerged. The statistics report cautions that diverse systems can share failures, qualifying expectations for seed ensembling. The reported general-ML accuracies are not FX win rates.
=== computing-software__03of04
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/computing-software__03of04/records.jsonl): **69 records**, matching shard order. All 36 extracted quotes match their cited pages.

Relevance counts: **3: 0 · 2: 15 · 1: 21 · 0: 33**. Reading depth: 14 full, 1 partial, 54 triage.

The ten strongest levers are mostly correctness checks; forecasting benefits remain unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit actual settlement labels | aa26a28d698e | labels | moderate | Deriv ticks |
| Verify research/live scoring parity | aa26a28d698e | validation | moderate | Deriv ticks |
| Enforce causal timestamp availability | a0378ba52ea2 | validation | moderate | Deriv ticks |
| Synchronize cross-pair callbacks | a8bb182236d2 | validation | moderate | Deriv ticks |
| Prevent array mutation across folds | e53c33dd59ee | validation | moderate | Deriv ticks |
| Verify completed-bar indexing | d241c4ee9d89 | validation | moderate | Deriv ticks |
| Stress-test delayed entry ticks | e78977d2feec | validation | weak | Deriv ticks |
| Test ATR for magnitude gating | f0ba5d0d4f31 | magnitude | weak | Deriv ticks |
| Test multiscale price-bar features | c1ad362c2da6 | features | weak | Deriv ticks |
| Test shared pretraining across pairs | ec0694c0371f | features | weak | Deriv ticks |

**Unreadable documents:** none. Several slide extracts omit code/images; one indicator template has substantial OCR corruption.

**Contradictions with in-house priors:** none established empirically. No document demonstrates a validated FX direction or magnitude edge, or deep-network superiority over boosted trees. All relevant evaluations received C or D.
=== computing-software__04of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/computing-software__04of04/records.jsonl): **68 records**, in shard order. JSON, required fields and all finding quotes/page citations validated.

Relevance counts: **3: 3 · 2: 10 · 1: 18 · 0: 37**, including one unreadable text. Relevant books have selected-chapter coverage marked `partial`.

Ten promising levers—all requiring only `deriv-ticks`:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Purged temporal splits and untouched final testing | da1f48a5d6ab | validation | moderate |
| Exact contract entry/settlement replay | f435ae0b5201 | validation | weak |
| Dependence-aware HAC/block uncertainty | f699752b7233 | validation | moderate |
| EWMA magnitude forecasts | e659a774f31f | magnitude | weak |
| Asymmetric GJR-GARCH magnitude forecasts | f699752b7233 | magnitude | weak |
| Regularized cross-pair return models | e659a774f31f | direction | weak |
| Causal factor-residual reversal | e659a774f31f | direction | weak |
| Platt versus isotonic calibration | 8b53ec9d915d | calibration | weak |
| Future quantile-exceedance calibration | e659a774f31f | calibration | moderate |
| Prior-sensitive, uncertainty-aware gates | eac628411dff | selection-gating | weak |

Unreadable: **f5ba9e21f56d**, *CUDA by Example*—extensive font-encoding corruption.

No credible contradiction to the in-house priors emerged. The “short-term” FX reversal example uses monthly returns; deep-learning superiority claims lack supporting experiments. No document establishes a realistic tradable-horizon FX binary-contract edge.
=== crypto-digital-assets__01of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/crypto-digital-assets__01of05/records.jsonl): **44 records**, in shard order. JSON, quotation pages and numerical citations validated.

Relevance counts: **3: 8 · 2: 12 · 1: 21 · 0: 3**. Twenty documents received full reads; twenty-four were triaged. None were unreadable.

Ten promising levers follow. All use existing Deriv ticks; evidence ratings concern the source evidence, not demonstrated Deriv profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized clock and weekday volatility profiles | `33b3d50d740d` | magnitude | moderate | deriv-ticks |
| Parsimonious square-root SARV benchmark | `0f5050cc27db` | magnitude | moderate | deriv-ticks |
| Joint sign-and-magnitude objective | `0d73575114ca` | loss | moderate | deriv-ticks |
| Common-factor and pair-residual forecast heads | `233aebeb1af7` | ensemble | weak | deriv-ticks |
| Precision/utility thresholds with recalibration | `104e820456f8` | calibration | moderate | deriv-ticks |
| Cross-pair absolute-return features | `179010d68952` | features | weak | deriv-ticks |
| Uncertainty-shrunk payout-adjusted Kelly | `04c10e6288e8` | sizing | weak | deriv-ticks |
| Tail-sample and uncertainty gates | `364510343b59` | selection-gating | moderate | deriv-ticks |
| Model-specific estimation-window selection | `0f5050cc27db` | regime | moderate | deriv-ticks |
| Surrogates and multiple-testing correction for entropy features | `379a2896fefb` | validation | moderate | deriv-ticks |

No robust result overturns the in-house priors. Some crypto studies favor neural models over tree baselines (`233aebeb1af7`, survey `33554fcc7f3b`), with limited transfer evidence. Limited **weekly** volatility clustering in `364510343b59` qualifies volatility-persistence claims but does not test intraday magnitude prediction. The information-flow paper reinforces the distinction between variance dependence and signed-return skill.
=== crypto-digital-assets__02of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/crypto-digital-assets__02of05/records.jsonl): **44 records**, in shard order. All JSON and 105 page-cited quotations validated.

Relevance counts: **3: 8 · 2: 9 · 1: 20 · 0: 7**. Seventeen documents received full reads; none were unreadable.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Clock-phase return features | `4f336a27aa3f` | features | moderate | deriv-ticks |
| Boundary-aligned return lags | `4f336a27aa3f` | direction | weak | deriv-ticks |
| Shifted-clock placebo tests | `4f336a27aa3f` | validation | strong | deriv-ticks |
| Joint cross-pair block bootstrap | `4f336a27aa3f` | validation | strong | deriv-ticks |
| Heavy-tailed conditional densities | `4a51790f8621` | magnitude | moderate | deriv-ticks |
| Pooled shrinkage with stochastic volatility | `4d2abbcce193` | magnitude | moderate | deriv-ticks |
| Horizon-specific threshold calibration | `63561b585cb7` | calibration | moderate | deriv-ticks |
| Jump-robust bipower variation | `4f6938314daa` | magnitude | weak | deriv-ticks |
| Causal short-lag reversal features | `4a51790f8621` | direction | weak | deriv-ticks |
| Entropy match-count and estimator checks | `631983fa3101` | validation | moderate | deriv-ticks |

Strong validation evidence supports better evaluation, not a demonstrated FX trading edge.

The main challenge to the priors comes from crypto clock-boundary direction forecasts and daily Bayesian sign forecasts. The former’s strongest held-out result uses a brief opening VWAP return; longer-horizon order-flow results remain in-sample. The latter lacks directional significance tests and costs. Neither establishes an edge for Deriv contracts. Entropy/Hurst direction claims remain unsupported, and no credible result overturns the boosted-tree prior.
=== crypto-digital-assets__03of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/crypto-digital-assets__03of05/records.jsonl): **44 records**, in shard order. Read 17 fully and triaged 27.

Relevance counts: **3: 6 · 2: 11 · 1: 24 · 0: 3**. Validation passed: 91 page-matched quotes, 48 levers, valid JSON throughout. No unreadable documents.

The ten most promising levers are candidates for testing, not established FX edges:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized log-variance HAR baseline | 8cddfbb23946 | magnitude | moderate | deriv-ticks |
| Calibration from out-of-sample residuals | 8cddfbb23946 | calibration | moderate | deriv-ticks |
| Blend fast and slow volatility estimates | 78cc4cb076c6 | magnitude | moderate | deriv-ticks |
| Regularize unstable distribution parameters | 795638a4b41d | calibration | moderate | deriv-ticks |
| Separate common USD moves from pair residuals | 8d647109a4a4 | features | weak | deriv-ticks |
| Check quantile ordering and conditional coverage | 8cddfbb23946 | validation | moderate | deriv-ticks |
| Test that future ticks cannot change past features | a43f16490818 | validation | moderate | deriv-ticks |
| Group overlapping signals into validation episodes | 92a07dd48d97 | validation | moderate | deriv-ticks |
| Audit exact settlement ticks, boundaries and ties | a86ef69d8853 | labels | moderate | deriv-ticks |
| Model conditional residual distributions for magnitude gates | 795638a4b41d | magnitude | weak | deriv-ticks |

Nothing convincingly overturns the magnitude-over-sign prior. Ensemble improvements were not universal. Volatility-asymmetry findings conflict across papers, with serious table inconsistencies in the skewed-GARCH study. Hurst-based inefficiency claims lack forward trading validation, and the HMM study uses future-smoothed states. No document establishes a profitable Deriv FX direction edge.
=== crypto-digital-assets__04of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/crypto-digital-assets__04of05/records.jsonl): **44 records**, in shard order. All JSON and 85 page-cited quotes validated.

Relevance: **3: 6 documents · 2: 14 · 1: 16 · 0: 8**.

Ten promising tests—all use **deriv-ticks**; evidence grades reflect transferability, not proven Deriv performance:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Regularized log-HAR volatility baseline | cb78faff67e0 | magnitude | Moderate |
| Honest quantile forests | bfbbd60ba402 | magnitude | Moderate |
| Compact multiscale volatility features | bfbbd60ba402 | features | Moderate |
| Conditional coverage and exceedance clustering | bfbbd60ba402 | calibration | Moderate |
| QLIKE alongside magnitude-event scores | cb78faff67e0 | loss | Moderate |
| Lagged cross-pair volatility | d66346caac5c | magnitude | Weak |
| Causal UTC volatility seasonality | d6e67b0dd509 | features | Weak |
| Pool across pairs and forecast horizons | d8cee003c632 | ensemble | Weak |
| Surrogate checks for complexity features | c219ced02d39 | validation | Moderate |
| Purge overlapping outcomes and audit availability times | d8cee003c632 | validation | Moderate |

No document was wholly unreadable. Two records are **partial** because extracted figure text is corrupted: `d66346caac5c` and `d8cee003c632`; their main text and numerical tables were readable.

No convincing contradiction of the in-house priors emerged. Daily/weekly crypto momentum provides qualified contrary evidence to broad price-only pessimism, but does not establish our intraday FX edge. Volatility predictability is better supported than sign predictability; Hurst, entropy and related directional claims generally lack adequate forecast validation.
=== crypto-digital-assets__05of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/crypto-digital-assets__05of05/records.jsonl): **41 records**, in shard order. Validation passed for JSON, IDs, schemas, and **84 exact page-cited quotes**.

Relevance counts: **3: 4 · 2: 12 · 1: 18 · 0: 7**.

Ten promising candidates for testing:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| GARCH magnitude baseline | f4dc7a0adf5a | magnitude | Moderate | Deriv ticks |
| UTC clock/weekday conditioning | fa92b2d04f8e | magnitude | Moderate | Deriv ticks |
| Causal jump-recency features | deb5003ca620 | magnitude | Weak | Deriv ticks |
| Lagged cross-pair dispersion | dbf69a2f48a6 | features | Weak | Deriv ticks |
| Historical return-distribution probabilities | ff57dc8abbf9 | calibration | Weak | Deriv ticks |
| Blend short/long volatility windows | f4dc7a0adf5a | ensemble | Weak | Deriv ticks |
| Noise-robust jump labels with FDR control | deb5003ca620 | labels | Moderate | Deriv ticks |
| Chronological preprocessing and purged labels | 21124d33f1c4 | validation | Moderate | Deriv ticks |
| Episode-aware evaluation of overlapping signals | e4f04ae1ab11 | validation | Moderate | Deriv ticks |
| Macro-event proximity gating | e22a1b33c0ab | selection-gating | Moderate | External calendar |

No files were unreadable. **cca280069da5** contains only a publisher summary and references; the chapter text is unavailable.

No credible result overturns the in-house priors. Complex LSTM forecasts fail to outperform ARIMA significantly; jump-based direction claims largely describe contemporaneous returns. Hurst and volatility-asymmetry findings disagree across papers, with no demonstrated Deriv direction edge.
=== econophysics-fractals-chaos__01of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__01of12/records.jsonl): **49 valid records in shard order**, containing 78 levers. All finding quotes were checked against their cited pages.

Relevance counts: **3: 9 · 2: 24 · 1: 13 · 0: 3**. Reading depth: 30 full, 3 partial, 16 triage.

The ten most promising levers are below. Evidence describes support for the mechanism or diagnostic; none establishes Deriv trading profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized multiscale log-volatility | `06e9d327d8a8` | magnitude | moderate | deriv-ticks |
| Shrunk cross-pair absolute-return features | `06e9d327d8a8` | features | moderate | deriv-ticks |
| Horizon-specific heavy-tail calibration | `07a753263288` | calibration | moderate | deriv-ticks |
| Quiet-run duration and volatility-record age | `0989617fb579` | magnitude | moderate | deriv-ticks |
| Audit gaps and stitched-return artifacts | `0a389382192d` | validation | strong | deriv-ticks |
| Restrict scaling estimates to finite, low-order moments | `0a8e45b3ccdd` | validation | strong | deriv-ticks |
| Matched-length monofractal and shuffled nulls | `0bf041293ffe` | validation | strong | deriv-ticks |
| Separate contemporaneous from lagged cross-pair dependence | `10f55ad61103` | validation | strong | deriv-ticks |
| Upside/downside semivariance features | `15fb91442fe5` | magnitude | weak | deriv-ticks |
| Shrunk short-context up/down pattern probabilities | `14ef9f6655b5` | direction | weak | deriv-ticks |

No document was wholly unreadable. Partial records are `024160ac429b` and `092a8dc4684a` because of truncated extraction, and `02955de094c8` because reading focused on its financial sections.

**No robust contradiction of the in-house priors emerged.** Several papers infer direction or inefficiency from Hurst, Zipf or log-periodic structure, but their evaluations do not establish that inference. Magnitude dependence receives substantially stronger support. None verifies the reported 15-minute direction edge; all substantive records received evaluation grade C or D.
=== econophysics-fractals-chaos__02of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__02of12/records.jsonl): **49 records**, in shard order. Validation passed for JSON, IDs, required fields, and **95 verbatim page-cited quotations**.

Relevance: **3: 5 · 2: 20 · 1: 23 · 0: 1**. Evaluation grades: **2 B, 17 C, 6 D**.

Ten promising levers; each uses existing Deriv ticks:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shared-factor multifrequency volatility | `28e6e971fb63` | magnitude | moderate | deriv-ticks |
| PIT and exceedance calibration | `28e6e971fb63` | calibration | moderate | deriv-ticks |
| Separate change frequency from move amplitude | `2a8211bcc49e` | magnitude | moderate | deriv-ticks |
| Separate seasonal volatility from slow state | `1bb36118e13f` | magnitude | moderate | deriv-ticks |
| Coarse-to-fine volatility features | `1f09da8b2de2` | magnitude | moderate | deriv-ticks |
| Positive/negative return aggregates | `18804bb91682` | features | moderate | deriv-ticks |
| Regularized change-event intensity | `1735e9364041` | magnitude | moderate | deriv-ticks |
| Retest dependence after volatility standardization | `248ef2071c3d` | validation | strong | deriv-ticks |
| Heavy-tail-preserving Hurst controls | `1a1b54cf77aa` | validation | moderate | deriv-ticks |
| Immutable prospective forecast records | `25a010464f67` | validation | strong | deriv-ticks |

No document was wholly unreadable. The long review `25a010464f67` received a partial read of relevant chapters; damaged or missing tables are flagged in affected records.

The shard largely supports magnitude predictability over sign predictability. Apparent exceptions—crypto order-book direction claims and Tehran daily sign persistence—have timing, label, or in-sample limitations. Neither establishes a reliable contradiction for intraday FX. The strongest FX evidence concerns daily return-density calibration; intraday transfer remains untested.
=== econophysics-fractals-chaos__03of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__03of12/records.jsonl): **49 records**, shard order verified, JSON validated, and 115 quotations checked against source pages.

Relevance counts: **3: 4 documents · 2: 24 · 1: 18 · 0: 3**. Read 28 fully and triaged 21. No unreadable files; damaged equations and missing figures are noted.

The ten most promising levers all use **existing Deriv ticks**:

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Forward-only scoring; exclude future-conditioned LOO | `2c47896cb8a5` | validation | strong |
| Signed-covariance and support-count audits | `32e435c62d71` | validation | strong |
| Heavy-tail-matched multifractal null tests | `3dc22b931a19` | validation | strong |
| Common and pair-specific volatility factors | `332f6e82e131` | magnitude | moderate |
| Squared trailing trends for future volatility | `3dd5b1962978` | magnitude | moderate |
| Regularized mixture of volatility decay rates | `3dd5b1962978` | magnitude | moderate |
| Separate bipower variation and jump contribution | `3c092cad24f3` | features | moderate |
| Cross-pair residual return dispersion | `3d1e86b84821` | magnitude | moderate |
| Smooth trends combined across scales | `2fa9af3c38b0` | ensemble | moderate |
| Pooled linear and cubic trend features | `2fa9af3c38b0` | direction | weak |

Evidence labels describe support for each method, not demonstrated Deriv profitability.

**No robust contradiction of the in-house priors.** Apparent Hurst-based direction claims lack convincing validation. The deep-learning paper predicts variance and omits tree baselines. No document establishes an executable short-horizon FX edge under our evaluation standard.
=== econophysics-fractals-chaos__04of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__04of12/records.jsonl): **49 records**, in shard order. Validated JSON, schema, and all 108 page-cited quotations.

Relevance counts: **3: 7 · 2: 21 · 1: 16 · 0: 5**. Reading depth: 27 full, 21 triage, one review read by selected relevant sections. **No unreadable documents.**

The ten most promising tests:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Parsimonious MSM volatility forecast | 543b8f33d1df | magnitude | moderate | deriv-ticks |
| Regularized HAR log-volatility baseline | 4ba0008cc661 | magnitude | moderate | deriv-ticks |
| Combine conventional and multifractal volatility forecasts | 4ba0008cc661 | ensemble | moderate | deriv-ticks |
| Session normalization and interactions | 4610ddad5f62 | features | moderate | deriv-ticks |
| Lagged signed-return kernels for magnitude | 3f373b54666c | features | weak | deriv-ticks |
| Regularized conditional sign history | 439ef455c78e | direction | weak | deriv-ticks |
| Aggregate cross-pair return products | 468c956169c3 | features | weak | deriv-ticks |
| Regularized nonlinear drift versus zero drift | 51d3a0b64bec | direction | weak | deriv-ticks |
| Joint persistence–multifractality null tests | 458703b947f3 | validation | moderate | deriv-ticks |
| Distribution- and dependence-matched surrogate tests | 4ba0008cc661 | validation | moderate | deriv-ticks |

Most evidence supports the magnitude-over-sign prior. **439ef455c78e** qualifies the blanket entropy/sign claim using direct conditional sign entropy and theoretical counterexamples, but supplies no held-out trading edge. **51d3a0b64bec** reports nonlinear crypto drift without forecast validation.

No document establishes a Deriv-style short-horizon FX edge above the payout hurdle.
=== econophysics-fractals-chaos__05of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__05of12/records.jsonl): **49 records**, validated for JSON, shard order, schema and exact page-quote matches.

Relevance counts: **3: 11 · 2: 23 · 1: 13 · 0: 2**. Records contain 114 findings and 92 levers.

The ten most promising levers are below. Evidence grades support the method or validation control; they do not establish Deriv profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized multiscale ARCH feedback | 54f249479eb9 | magnitude | moderate | deriv-ticks |
| Coarse volatility → future finer-scale magnitude | 58d7ffc8b244 | magnitude | weak | deriv-ticks |
| Lagged volatility-normalized price features | 62eb3702d975 | features | moderate | deriv-ticks |
| Beta-binomial probability shrinkage | 61556e52e7c4 | calibration | moderate | deriv-ticks |
| Pool scale-normalized activity distributions across pairs | 662788437c32 | calibration | weak | deriv-ticks |
| Remove a trailing common-currency factor | 55f51d0500bc | features | weak | deriv-ticks |
| Correct memory tests for short-run dependence | 55dd85af063a | validation | strong | deriv-ticks |
| Calibrate correlation spectra with matched detrending nulls | 55f51d0500bc | validation | strong | deriv-ticks |
| Test multifractal width against matched surrogates | 6798def0bb0d | validation | strong | deriv-ticks |
| Preserve zero moves and audit their feature effects | 64d77f7b73b4 | validation | strong | deriv-ticks |

No files were missing. Three records are partial: **61d7e7c1a7ec** contains only a publisher preview; **55c3f88feb8e** has a severely truncated page; **67e07d8e3a07** lacks central equation blocks.

There is **no credible contradiction of the magnitude-over-sign prior**, and no convincing fixed-expiry direction result meeting your evaluation standard. Selected LPPL turning-point forecasts are weak counterevidence. Within the shard, newer work disputes older claims that heavy tails independently cause genuine multifractality: finite samples and short fitting scales can produce that appearance.
=== econophysics-fractals-chaos__06of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__06of12/records.jsonl): **49 records**, validated for JSON, shard order, schema, and quoted passages/pages.

Relevance: **3: 8 · 2: 22 · 1: 13 · 0: 6**. Completed 30 full reads and 19 triages, recording 76 levers. Evaluation grades: 21 C, 9 D.

The ten most promising tests are below. Evidence grades support the method, not established profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Volatility-exceedance recurrence features | `6ecf7a72dcba` | selection-gating | Moderate | deriv-ticks |
| Causal weekly activity normalization | `700213d26f21` | features | Moderate | deriv-ticks |
| Confirmed persistent-reversal features | `74245fab16d2` | features | Moderate | deriv-ticks |
| Explicit expiry tie probabilities | `70f9929aaff5` | labels | Moderate | deriv-ticks |
| Proper distribution/trajectory scoring | `6fd6a6cc9712` | loss | Moderate | deriv-ticks |
| Shuffled-normalized DFA | `6a869f29181c` | features | Moderate | deriv-ticks |
| Dependence-preserving significance tests | `74ffda50a1ae` | validation | Moderate | deriv-ticks |
| Separate genuine unchanged ticks from gaps | `75294646d356` | validation | Moderate | deriv-ticks |
| Compare raw, filtered and jointly fitted memory | `7b8b5d4c67c4` | validation | Moderate | deriv-ticks |
| Timestamp rolling features at actual availability | `7ffa190eee4a` | validation | Strong | deriv-ticks |

No document was wholly unreadable; extraction gaps and missing figures are noted in individual records.

Signed-return memory claims in `7b8b5d4c67c4` and intraday autocorrelation claims in `80c2a082ed32` qualify the blanket “size only” prior. Both remain in-sample and establish no tradable FX sign edge. Nothing validates the reported in-house direction performance or overturns the tree-versus-deep-net prior.
=== econophysics-fractals-chaos__07of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__07of12/records.jsonl): **49 records**, validated for JSON, shard order, schema, and exact page-cited quotes.

Relevance counts: **3: 7 · 2: 15 · 1: 17 · 0: 10**. Read 22 fully; triaged 27. No unreadable documents; extraction limitations are noted in affected records.

The ten most promising levers are below. Strong evidence labels concern validation methods.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Actual-tick entry, expiry and tie simulation | 854d740704ba | validation | strong | deriv-ticks |
| Robust absolute-error or quantile losses | 854d740704ba | loss | moderate | deriv-ticks |
| Parsimonious multifrequency volatility filter | 9a5529929244 | magnitude | weak | deriv-ticks |
| Fast volatility increases, slower decreases | 9a5529929244 | regime | weak | deriv-ticks |
| Waiting times to accumulated absolute-return thresholds | 8a6166571552 | magnitude | weak | deriv-ticks |
| Causal cross-pair factors and residuals | 939b8a020a02 | features | weak | deriv-ticks |
| Trailing multifractal spectral width | 85c8d73f4ff7 | direction | weak | deriv-ticks |
| Correct finite-window Hurst bias | 94cab936a32e | validation | strong | deriv-ticks |
| Preserve covariance signs in multifractal features | 935e9434c0e4 | validation | strong | deriv-ticks |
| Distribution- and spectrum-preserving surrogate tests | 98e4934e7892 | validation | moderate | deriv-ticks |

Two findings qualify the categorical size-only prior: **85c8d73f4ff7** reports small out-of-sample next-day equity return predictability; **918c6dae62da** reports weak intraday flow/return Granger effects. Neither establishes a usable FX binary direction edge. Nothing here overturns the tuned-tree prior.
=== econophysics-fractals-chaos__08of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__08of12/records.jsonl): **49 records**, verified for shard order, JSON validity, and verbatim page-cited findings.

Relevance counts: **3: 8 · 2: 21 · 1: 15 · 0: 5**.

Ten promising levers—all use **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Causal visibility amplitude/sign ratios | `9eb4e438a7fe` | direction | moderate |
| Heavy-tail and short-memory nulls for Hurst claims | `a571559c9131` | validation | moderate |
| Persistent multiscale volatility state | `a6f9680f4870` | magnitude | moderate |
| Trailing time-of-week normalization | `ae0cd4beab74` | magnitude | moderate |
| Lagged cross-pair co-jump counts | `9f14bb4dc2d5` | magnitude | weak |
| Shrunk up/down/zero transition probabilities | `9e3a4785cb6b` | direction | weak |
| Conditional trend/reversion force regression | `b0a2c201ccbb` | direction | weak |
| Causal multiscale cross-pair correlations | `9f2b8a2f92bf` | regime | weak |
| Directional-change age, overshoot and intensity | `afefd06e2644` | magnitude | weak |
| Realized path variation versus net displacement | `b0e3e7f5b0fd` | features | weak |

No document was wholly unreadable. Reads were partial for the wavelet thesis (`9f2b8a2f92bf`), MANES (`a4ff17250264`), and intrinsic-time paper (`afefd06e2644`); the latter contains garbled figure text.

Qualified contradictions: equity-index continuation and individual-stock reversal provide competing short-horizon direction claims, but neither establishes a Deriv edge. Several papers show that fat tails and short memory can mimic long-memory evidence. The shard generally supports separating magnitude prediction from direction; no result establishes profitability under Deriv’s expiry and tie rules.
=== econophysics-fractals-chaos__09of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__09of12/records.jsonl): **49 records, 102 levers**. JSON parsing, shard order, IDs and quoted passages all validated.

Relevance counts: **3: 8 · 2: 23 · 1: 15 · 0: 3**. No unreadable documents; three long works have explicitly documented partial/chapter reads.

Ten priorities below. Evidence strength concerns the stated mechanism or validation method, not demonstrated profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Price-change counts and event-time variance | b5a9a71ecd92 | magnitude | Moderate | deriv-ticks |
| Causal session volatility/activity baselines | b5a9a71ecd92 | features | Moderate | deriv-ticks |
| Pool normalized magnitude dynamics across pairs | b5a9a71ecd92 | magnitude | Moderate | deriv-ticks |
| Regularized distribution scaling across horizons | c4a090ff6c3a | magnitude | Moderate | deriv-ticks |
| Rank correlation and covariance shrinkage | be29fcfcdf6f | features | Moderate | deriv-ticks |
| Cluster prediction errors for ensemble diversity | be29fcfcdf6f | ensemble | Moderate | deriv-ticks |
| Account for correlated strategy trials | be29fcfcdf6f | validation | Moderate | deriv-ticks |
| Audit DFA/Hurst against trends and periodicity | bc388b73b452 | validation | Strong | deriv-ticks |
| Require matched surrogates for nonlinear features | c401ea2ff2d4 | validation | Moderate | deriv-ticks |
| Physical return densities with explicit tie treatment | ca52a56ba2f8 | calibration | Weak | deriv-ticks |

**No robust contradiction of the in-house priors emerged.** Magnitude evidence substantially exceeds direction evidence. The Bombay study infers direction from Hurst without adequate validation; log-periodic crash predictions face explicit counterevidence in `c9d0a0d16fa7`. None of the relevant documents earned evaluation grade A or B.
=== econophysics-fractals-chaos__10of12
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__10of12/records.jsonl): **49 records**, in shard order, with verified page-cited quotes.

Relevance: **3: 13 · 2: 23 · 1: 8 · 0: 5**. Full reads: 36; triage: 13. Unreadable: none. No evaluation earned A or B.

The most promising candidates are below. Evidence describes source support, not demonstrated Deriv performance.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Parsimonious GARCH magnitude baseline | cdc70757ea3b | magnitude | moderate | deriv-ticks |
| Causal intraday seasonality normalization | cfdbec86c153 | features | moderate | deriv-ticks |
| Tail- and length-matched multifractal controls | d06146f37d01 | validation | moderate | deriv-ticks |
| Next-tick entry and tie-aware evaluation | d5d56fe3504c | validation | moderate | deriv-ticks |
| Share magnitude parameters across horizons | d4ccdbba93a8 | calibration | weak | deriv-ticks |
| Burst-amplitude and elapsed-time features | d3f882fe72ff | magnitude | weak | deriv-ticks |
| Remove common USD exposure from dependence features | d8bd902e14b8 | features | weak | deriv-ticks |
| Regularized ensemble of memory lengths | ce094ab987e7 | ensemble | weak | deriv-ticks |
| Separate cross-pair volatility dependence from return correlation | d65083b948ed | magnitude | weak | deriv-ticks |
| Compare block resampling with GAN augmentation | de91a0028489 | ensemble | weak | deriv-ticks |

The Hurst papers **dbf81fe77626** and **dc5fc35fdaf4** claim future-return or crash prediction, challenging the size-only prior superficially; their retrospective, long-horizon evidence does not establish an exception for short-horizon FX. Overall, the shard supports magnitude persistence more strongly than sign predictability and provides no credible contradiction to the in-house model-performance priors.
=== econophysics-fractals-chaos__11of12
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__11of12/records.jsonl): **49 records**, in shard order. JSON, schema and all **102 page-cited quotes** pass validation.

Relevance: **3: 3 documents · 2: 20 · 1: 16 · 0: 10**.

Ten promising levers, all requiring Deriv validation:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Constrained multifrequency volatility model | `e31cb516d085` | magnitude | moderate | deriv-ticks |
| Weekly UTC volatility normalization | `ece9180b5c86` | features | moderate | deriv-ticks |
| Explicit tie-probability calibration | `ea671be034e0` | calibration | moderate | deriv-ticks |
| Horizon-specific tail calibration | `ea671be034e0` | magnitude | moderate | deriv-ticks |
| Amplitude-selective cross-pair correlations | `ec82981bd65e` | features | moderate | deriv-ticks |
| Sampling-scale and staleness audit | `ed1082b97e60` | validation | moderate | deriv-ticks |
| Barrier-crossing and recurrence features | `ef38294667c9` | features | weak | deriv-ticks |
| Shrunk state-conditional predictors | `f17c8e472bd8` | features | weak | deriv-ticks |
| Causal decomposition leakage checks | `ebadf74e8f16` | validation | moderate | deriv-ticks |
| Matched-null calibration of Hurst statistics | `e6c24fe8ad27` | validation | moderate | deriv-ticks |

None was unreadable. The Adaptive Memory dissertation (`e63e11cc3916`) is marked **partial**, with coverage recorded.

No credible out-of-sample FX direction result contradicts the in-house priors. One simulation paper shows that zero unconditional autocorrelation can conceal conditional predictability; it supplies no empirical FX edge. The strongest forecasting evidence concerns volatility, primarily at longer horizons. No paper earned evaluation grade A.
=== econophysics-fractals-chaos__12of12
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/econophysics-fractals-chaos__12of12/records.jsonl): **38 records**, in shard order, containing 103 page-checked findings and 75 levers.

Relevance counts: **3: 9 · 2: 16 · 1: 11 · 0: 2**. Completed 25 full/relevant-chapter reads and 13 triages. None unreadable; OCR limitations are noted.

Ten priority levers—all use **Deriv ticks**:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Model magnitude separately from sign | `5efd73f93e76` | magnitude | Moderate | deriv-ticks |
| Separate UTC seasonality from volatility state | `fec40a49c64c` | calibration | Moderate | deriv-ticks |
| Model no-move probability; charge ties as losses | `fec40a49c64c` | labels | Moderate | deriv-ticks |
| Update a small trend-horizon ensemble after labels mature | `f82413ff3875` | ensemble | Weak | deriv-ticks |
| Test multiscale cross-pair lead–lag features | `f943eedd8847` | features | Weak | deriv-ticks |
| Compare compact Markov volatility with long-memory models | `fc45dab23974` | regime | Moderate | deriv-ticks |
| Validate distributions across target horizons | `7dd688951c84` | validation | Moderate | deriv-ticks |
| Require null controls and estimator stability for complexity features | `f9ea8001cabb` | validation | Strong | deriv-ticks |
| Calibrate finite-sample multifractal bias bands | `fcb483cb8f4a` | validation | Moderate | deriv-ticks |
| Evaluate the entire model search, including failed variants | `fe0bd86e4f99` | validation | Moderate | deriv-ticks |

No document earned evaluation grade A. The strongest evidence concerns validation safeguards.

`f9a898189bfc`, `3d4f0164316b`, and `f055c2036871` make Hurst-based directional claims that conflict with the in-house prior, but lack adequate forecasting validation. Overall, this shard supports persistent magnitude information without establishing a reliable directional edge.
=== elections-polling__01of02
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/elections-polling__01of02/records.jsonl): **86 ordered records**, all validated.

Relevance counts: **3: 11 · 2: 30 · 1: 33 · 0: 12**. Depth: 40 full reads, 44 triages, two incomplete source texts.

The ten most promising levers follow. All require only existing **Deriv ticks**; evidence grades concern the source studies, with FX transfer still untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Replay exact settlement, ties and payout alongside proper scores | `45c65e632707` | validation | moderate | deriv-ticks |
| Keep future periods untouched by threshold and window selection | `67b93b6124ce` | validation | moderate | deriv-ticks |
| Audit clocks, missing sentinels and units before modeling | `81fb853b8236` | validation | moderate | deriv-ticks |
| Benchmark trees against properly regularized hierarchical models | `732c423ce46b` | validation | moderate | deriv-ticks |
| Fit convex stacks from purged chronological predictions | `0c9541f8f09c` | ensemble | moderate | deriv-ticks |
| Account for shared residual bias and covariance | `28f07ebdc70c` | ensemble | moderate | deriv-ticks |
| Cap ensemble weights using held-out forecast errors | `61e84946ae80` | ensemble | moderate | deriv-ticks |
| Select useful source pairs, then regularize pair-specific corrections | `68209fc87e98` | regime | moderate | deriv-ticks |
| Pool error-variance estimates separately by horizon | `7f884a7f87d8` | calibration | moderate | deriv-ticks |
| Model coherent rise, fall and tie probabilities | `6eb5872b5956` | labels | moderate | deriv-ticks |

Two underlying documents were unavailable beyond repository pages and abstracts: **Leaping into the Unknown** (`06fc98f9df2c`) and **Collective Failure?** (`32ed05c58423`). Both are marked unreadable.

Nothing directly contradicts the in-house FX direction/magnitude results. Useful qualifications emerge: ensembling can worsen forecasts, internal filter precision can understate predictive uncertainty, and corrected hierarchical baselines can erase apparent ML advantages.
=== elections-polling__02of02
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/elections-polling__02of02/records.jsonl): **85 records**, in shard order. All JSON, IDs, and 151 page-cited quotations passed validation.

Relevance: **3: 10 · 2: 38 · 1: 32 · 0: 5**. Reading depth: 42 full, six partial, 37 triaged.

The ten most promising levers for testing are below. Evidence grades describe support in these documents; FX transfer remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Average within model families, then across families | e87a2744e1c1 | ensemble | moderate | deriv-ticks |
| Pool pair/session calibration through hierarchical shrinkage | e4c464bf7bee | calibration | moderate | deriv-ticks |
| Benchmark strongly shrunk, predeclared features | ee242b512c26 | features | moderate | deriv-ticks |
| Account for overlapping horizons and synchronized pairs | f2610aefb896 | validation | moderate | deriv-ticks |
| Run the complete tuning pipeline against block-preserving placebos | ee242b512c26 | validation | moderate | deriv-ticks |
| Validate conditional gate failures directly | f5aea3b6fe7e | selection-gating | moderate | deriv-ticks |
| Report risk–coverage curves for accepted and rejected trades | d81cbc270745 | selection-gating | moderate | deriv-ticks |
| Tune representations against held-out settlement outcomes | cb4fcaa183e9 | validation | moderate | deriv-ticks |
| Stress calibration against prior strength and sample removal | b5bafc3a703f | validation | moderate | deriv-ticks |
| Compare asymmetric return distributions with symmetric baselines | fc66afa5b578 | calibration | weak | deriv-ticks |

No source files were unreadable. Document `cda630d69e14` supplies only an abstract-and-references capture; the other partial reads are explicitly identified in their records.

Nothing credibly contradicts the stated FX sign-versus-magnitude priors. Relevant cautions: combinations sometimes underperform their strongest component, and marginal conformal coverage does not establish conditional win probabilities for a trading gate.
=== execution-optimal-trading__01of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/execution-optimal-trading__01of06/records.jsonl): **47 records**, in shard order. JSON, schema, exact page quotes and quote lengths verified.

Relevance: **3: 6 · 2: 7 · 1: 34 · 0: 0**. Read 13 fully; triaged 34. Unreadable: none.

Ten priority tests follow. Evidence grades concern the source method; none establishes a Deriv edge.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool magnitude models across pairs | `24f1a363dafa` | ensemble | Moderate | Deriv ticks |
| Separate seasonal activity from recent surprises | `24f1a363dafa` | magnitude | Weak | Deriv ticks |
| Shrinkage cross-pair VAR/error correction | `130549c7c174` | direction | Weak | Deriv ticks |
| Audit prediction versus contemporaneous explanation | `0d6f662e795b` | validation | Moderate | Deriv ticks |
| Reproduce exact entry and expiry tick timing | `289db4306c3f` | validation | Moderate | Deriv ticks |
| Compare frozen and rolling-retrained models | `289db4306c3f` | validation | Moderate | Deriv ticks |
| Distill complex models; test residual value | `0dc5aa3f58eb` | validation | Moderate | Deriv ticks |
| Regularized regime-dependent expert blending | `0fb39ac0b487` | ensemble | Weak | Deriv ticks |
| Relative-volatility magnitude gating | `23c3022142d0` | magnitude | Weak | Deriv ticks |
| Leading-venue versus Deriv price discrepancy | `1ef3ce6c2938` | direction | Weak | External: synchronized FX venue prices |

No robust contradiction to the in-house AUC or tree-versus-deep-net priors emerged. Signed-flow associations and cross-venue price signals qualify blanket claims about directional information, but do not validate unsigned complexity statistics as sign predictors. Several impressive execution results depend entirely on simulated dynamics.
=== execution-optimal-trading__02of06
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/execution-optimal-trading__02of06/records.jsonl): **47 records in shard order**, with 69 verified page-cited quotes and 45 levers.

Relevance counts: **3 → 3; 2 → 10; 1 → 33; 0 → 1**. Thirteen documents received full reads; 34 were triaged. None were unreadable.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool normalized predictors with shrunk pair-specific deviations | `452ee40e4d88` | ensemble | weak | deriv-ticks |
| Include parameter uncertainty in predictive probabilities | `39f8fd4ae6b6` | calibration | weak | deriv-ticks |
| Integrate signal decay separately for each expiry | `41379d33d3a5` | ensemble | weak | deriv-ticks |
| Test trailing net-movement/path-length ratio | `44dbe9f8ec92` | magnitude | weak | deriv-ticks |
| Compare compensated-jump and Gaussian magnitude models | `4c32189f39b7` | magnitude | weak | deriv-ticks |
| Compare price-change event clocks with UTC features | `4cd49cc6e35c` | features | weak | deriv-ticks |
| Reproduce exact entry, expiry and tie rules | `4c32189f39b7` | labels | moderate | deriv-ticks |
| Audit availability of entire forecast curves and preprocessing | `4c32189f39b7` | validation | moderate | deriv-ticks |
| Stress-test predictive decay under observation/order delays | `47ab464777dc` | validation | moderate | deriv-ticks |
| Test signed queue imbalance and its expiry-specific decay | `4cd49cc6e35c` | direction | weak | external: synchronized FX quotes and queue sizes |

A qualified contradiction to the stated priors appears in `47ab464777dc` (p. 5) and `4cd49cc6e35c` (p. 21): **signed** equity queue imbalance contains short-lived directional information. These overlapping, in-sample studies require external order-book data and do not establish a tradable Deriv FX edge.

No document establishes price-only FX binary profitability at our horizons or overturns the boosted-tree prior. Execution improvements, VWAP win rates and assumed simulated alpha were explicitly distinguished from directional forecasting evidence.
=== execution-optimal-trading__03of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/execution-optimal-trading__03of06/records.jsonl): **47 records**, in shard order.

Relevance counts: **3: 1 · 2: 15 · 1: 30 · 0: 1**. Read 16 documents fully and triaged 31. None unreadable. JSON, IDs, order, schemas and all finding quotes/pages passed validation.

Ten promising levers—all usable with `deriv-ticks`:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Exact entry/settlement tick evaluation | `6068424111b1` | validation | moderate |
| Delay-stressed entry and horizon labels | `619d4487e977` | validation | moderate |
| Period-blocked null tests for feature searches | `75c2971782eb` | validation | moderate |
| Nested temporal selection of signature depth/ridge | `78bd84612721` | validation | moderate |
| Low-order cross-pair path signatures | `78bd84612721` | features | weak |
| Shared models with pair-specific calibration | `818c2c6629dc` | ensemble | weak |
| Penalized additive magnitude models | `6068424111b1` | magnitude | weak |
| Price-change age and event clustering | `6a7b066a47ec` | magnitude | weak |
| Simple sigmoid/spline probability calibration | `65b0a541b4a8` | calibration | weak |
| Measure forecast decay before adding lagged signals | `7ce08ac3efff` | features | weak |

No robust contradiction to the in-house priors emerged. Investor-identity information predicts intraday signed returns in `75c2971782eb`, but unavailable order data, random splits and realized-volume inputs limit transfer. No document establishes the required Deriv binary win rate; execution savings and contemporaneous return fits frequently resemble stronger forecasting evidence than they provide.
=== execution-optimal-trading__04of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/execution-optimal-trading__04of06/records.jsonl).

All 47 records passed JSON, shard-order, schema and quotation checks: 53 page-matched quotes and 43 levers.

Relevance counts: **3: 4 · 2: 11 · 1: 32 · 0: 0**. Full reads: 15; triages: 32.

The ten most promising tests all use `deriv-ticks`:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Exact entry/expiry tick labels | 9a42d7a57052 | labels | moderate |
| Dependence-aware uncertainty estimates | 9a42d7a57052 | validation | moderate |
| Separate UTC seasonality from activity clustering | 9aa5740a9227 | magnitude | weak |
| Fast/slow realized-volatility features | 9b490fa2e147 | magnitude | weak |
| Synchronized lagged cross-pair returns | 946e1e68de69 | features | weak |
| Sign-reflected calibration pooling | 9d01433cbbfe | calibration | weak |
| Low-parameter quantile-bucket calibration | 9d01433cbbfe | calibration | weak |
| Local price-change duration surprise | a37e576c6dc8 | magnitude | weak |
| Persistence-conditioned abstention | 8ac572467c23 | selection-gating | weak |
| Missing-label and censoring audits | a77bdeda89c9 | labels | moderate |

No document was unreadable; some SHAP chart text in `a77bdeda89c9` is garbled.

No robust contradiction of the in-house priors emerged. Bund depth imbalance has a signed-return association (`8cffc62ee992`, p5), qualifying the blanket order-flow claim, but lacks out-of-sample evidence. The LSTM results concern execution costs, and the Hurst paper assumes perfect foresight; neither establishes superior directional prediction.
=== execution-optimal-trading__05of06
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/execution-optimal-trading__05of06/records.jsonl): **47 records**, in shard order. Verified JSON, IDs, page citations and verbatim quotes.

Relevance: **3: 3 documents; 2: 13; 1: 29; 0: 2.** Read 16 fully and triaged 31. Unreadable: **none**.

The ten most promising transfers are below. Evidence concerns the source method; none establishes a Deriv FX edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool normalized features across pairs | d19346cfe7fc | ensemble | Moderate | deriv-ticks |
| Conditional scale plus empirical residual quantiles | c6d7a1a922ae | calibration | Weak | deriv-ticks |
| Weight signals by decay and expiry | abe05feaa49e | ensemble | Weak | deriv-ticks |
| Cross-pair error-correction features | ca8895c32ba3 | direction | Weak | deriv-ticks |
| Causal EWMA range baseline | ca91a34cb287 | magnitude | Weak | deriv-ticks |
| Session, range expansion and prior-extrema features | c87b29f14477 | magnitude | Weak | deriv-ticks |
| Integrate drift uncertainty into probabilities | d5c09c9baa89 | calibration | Weak | deriv-ticks |
| Training-only teacher distillation | d19346cfe7fc | loss | Weak | deriv-ticks |
| Conservative shared hyperparameters | b47609dcb0bb | validation | Moderate | deriv-ticks |
| Score actual endpoint events, avoiding smoothed-target substitution | ca91a34cb287 | validation | Moderate | deriv-ticks |

**No convincing contradiction of the in-house priors emerged.** Apparent directional successes rely on assumed latent drift, oracle forecasts or contemporaneous flow regressions. Execution improvements do not establish binary win rates. No document earned evaluation grade A; the shard neither validates the reported magnitude AUCs nor challenges the boosted-tree prior directly.
=== execution-optimal-trading__06of06
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/execution-optimal-trading__06of06/records.jsonl): **47 records**, in shard order, with 73 verified page-cited quotes.

Relevance counts: **3: 7 · 2: 10 · 1: 30 · 0: 0**.

The ten most promising levers below all use **Deriv ticks only**. Evidence strength concerns the lever, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Causal filtering and historical-only parameter fitting | `b7c5f196d3c0` | validation | strong |
| Audit forecast availability at decision time | `e7bda0c607fc` | validation | strong |
| Evaluate log loss and binary Brier score | `e0e41b8659db` | validation | moderate |
| No-regime and randomized-sign controls | `dd47854ec3e4` | validation | moderate |
| Pool normalized features across pairs | `e37c11f38fc8` | features | weak |
| Monotonic magnitude-threshold probabilities | `e0e41b8659db` | calibration | weak |
| Regularized cross-pair VAR residuals | `91da17bdcb55` | features | weak |
| Small prespecified MACD feature grid | `dd88f8be7cfd` | features | weak |
| Ranges, absolute returns and activity for magnitude | `91da17bdcb55` | magnitude | weak |
| Calibration-uncertainty allowance before trading | `e7bda0c607fc` | selection-gating | weak |

No document was wholly unreadable. Two records are partial: `e7bda0c607fc` covers selected sections; `a41d35dd295e` has a truncated source missing its forecasting and backtesting chapters.

No reliable contradiction of the in-house priors emerged. Deep-model gains concern order fills, while many execution gains assume predictive alpha. One apparent sign-accuracy result explicitly uses future realized returns.
=== forecasting-methods__01of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__01of32/records.jsonl): **50 records**, validated for shard order, JSON parsing, and verbatim finding quotes with source markers.

Relevance: **3: 16 · 2: 29 · 1: 5 · 0: 0**. Coverage: **30 full, 15 partial, 5 triage**. None wholly unreadable; partial coverage and extraction defects are flagged.

Ten promising levers—all use **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Coherent Rise/Fall/tie probabilities | `01e2e0df0ccc` | calibration | strong |
| Proper scoring near the decision cutoff | `02fc5db991f8` | validation | strong |
| Correct for the complete model/gate search | `02f46db7d283` | validation | strong |
| Repair crossing quantiles | `036597f90e25` | calibration | strong |
| Distributional boosted trees | `047042dd5cf1` | magnitude | moderate |
| Shrink ensemble weights toward equal weights | `04ab2754e3ce` | ensemble | moderate |
| Multiscale realized-variance baseline | `0658d9339ac0` | magnitude | moderate |
| Pool session effects with pair-specific deviations | `06e335326424` | magnitude | moderate |
| Recalibrate the final ensemble | `0729ae01b02a` | calibration | strong |
| Proper threshold-focused magnitude loss | `073b482ebdff` | loss | moderate |

“Strong” includes theoretical evidence, not demonstrated Deriv profitability.

No robust short-horizon FX result overturns the in-house direction priors. Qualifications: calibration can hurt small-sample performance, conservative gates can increase costs, and averaging calibrated forecasts need not preserve calibration.
=== forecasting-methods__02of32
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__02of32/records.jsonl): **50 records**, correct shard order, valid JSON and 142 exact page-cited quotes.

Relevance counts: **3: 11 · 2: 34 · 1: 5 · 0: 0**. Reading depth: 44 full, 5 triage, 1 partial.

The ten most promising levers are below. Evidence grades concern the mechanism, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shrink ensemble weights toward equal weighting | `0dc211652696` | ensemble | strong | deriv-ticks |
| Horizon-specific calibration using matured outcomes | `0e0ae3ec832a` | calibration | strong | deriv-ticks |
| Normalize conformity residuals by causal volatility | `09bafbdf509e` | calibration | moderate | deriv-ticks |
| Pool models with pair, UTC and horizon context | `09369f843573` | features | moderate | deriv-ticks |
| Iterative supervised PCA for weak predictive factors | `0da9c70cf1f6` | features | moderate | deriv-ticks |
| Sparse-group regularization and compressed lag histories | `0afb9ef1c4da` | features | moderate | deriv-ticks |
| Strongly shrunk cross-pair VAR | `0cefdabdf97d` | features | moderate | deriv-ticks |
| Small periodic distributional magnitude model | `0da1a3c2a156` | magnitude | moderate | deriv-ticks |
| Diversify ensembles across lookbacks and losses | `09878c6971ee` | ensemble | moderate | deriv-ticks |
| Audit paired loss distributions and dependence-aware uncertainty | `0e7cb94d2102` | validation | strong | deriv-ticks |

**Unreadable documents: none.** The long *Prediction When Factors Are Weak* document was partially read: pages 1–52; the lengthy proof appendix was omitted.

No convincing result directly contradicts the in-house FX priors. Qualifications matter: learned ensemble weights and confidence weighting can hurt, weighted losses can damage probability calibration, and long-run conformal coverage does not guarantee selected-trade coverage. Deep-model successes on other datasets do not establish superiority over trees for our FX task.
=== forecasting-methods__03of32
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__03of32/records.jsonl).

50 records, in shard order: **19 relevance 3, 30 relevance 2, 1 relevance 1, 0 relevance 0**. All JSON parses; quotations match their cited pages and satisfy the word limit. No unreadable documents. Two long works were read by relevant sections.

The ten most promising levers:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Anytime-valid model comparisons | `141075326527` | validation | strong | Deriv ticks |
| Overlap-aware uncertainty and power estimates | `10bb58642e15` | validation | strong | Deriv ticks |
| Conditional probability recalibration | `101baa95f59f` | calibration | moderate | Deriv ticks |
| Scale-normalized adaptive conformal intervals | `15f35bf6d3ff` | calibration | moderate | Deriv ticks |
| Shallow Student-t GAS volatility trees | `1322cae39c51` | magnitude | moderate | Deriv ticks |
| Pooled multiscale variance features | `13c92bb86033` | magnitude | moderate | Deriv ticks |
| Cluster redundant ensemble members before pooling | `10a767d8ec1f` | ensemble | moderate | Deriv ticks |
| Shared representations with small pair-specific heads | `10ff2240a68f` | ensemble | moderate | Deriv ticks |
| Proper threshold-weighted distribution scores | `1573cf1d8724` | loss | strong | Deriv ticks |
| Small bounded residual adapters | `15ef4a50e328` | calibration | moderate | Deriv ticks |

Evidence grades concern the stated mechanism or methodology; none establishes a Deriv trading edge.

No convincing result overturns the in-house FX priors. Important qualifications: adaptive conformal coverage does not guarantee selected-trade profitability; return-weighted direction losses can change the probability target; and selective ensembles do not consistently improve on broad pooling. Some neural models outperform trees in other domains, which remains weak evidence for FX transfer.
=== forecasting-methods__04of32
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__04of32/records.jsonl): **50 records**, correct shard order, valid JSON, and **97 quotes verified against cited pages**.

**Reading remains incomplete:** 12 full reads, 25 partial reads, 13 triages. Relevance counts: **0: 0 · 1: 13 · 2: 28 · 3: 9**. No files were missing or unreadable; partial records identify their coverage.

The most promising levers are below. Evidence grades concern the method, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Grouped permutation importance | `173f14135aed` | features | moderate | deriv-ticks |
| Distributional boosted trees | `173f14135aed` | magnitude | moderate | deriv-ticks |
| Isotonic probability calibration | `17cb3876c95e` | calibration | moderate | deriv-ticks |
| Full-data seed ensembles | `185b16b3530d` | ensemble | moderate | deriv-ticks |
| Partial pooling across pairs | `19ce430d32d1` | ensemble | moderate | deriv-ticks |
| Adaptive weights with equal-weight shrinkage | `1d42c9ca86c7` | ensemble | moderate | deriv-ticks |
| Historical-rank copula for forecast samples | `1ce960fe9fbf` | ensemble | moderate | deriv-ticks |
| Joint score-based calibration tests | `1ce960fe9fbf` | calibration | strong | deriv-ticks |
| Per-pair scores and persistence baselines | `186f4a6367e1` | validation | strong | deriv-ticks |
| Sequential prediction ledger | `18e1ec7f8a8d` | validation | strong | deriv-ticks |

No verified result directly contradicts the in-house direction/magnitude priors. Important qualifications: summed CRPS can conceal poor forecasts; adaptive ensembles did not significantly beat the static alternative; and dispersion across point-only networks can substantially understate predictive uncertainty.
=== forecasting-methods__05of32
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__05of32/records.jsonl): **50 records**, with IDs/order, JSON, schema, and quote/page matches verified.

Relevance: **3: 12 · 2: 28 · 1: 8 · 0: 2**. Reading depth: **7 full, 33 partial, 10 triage**. The requested full reading remains incomplete for the 33 entries explicitly marked partial. No files were missing or unreadable; one had corrupted figure text.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Adaptive volatility baseline | `244d69a46f58` | magnitude | Moderate | deriv-ticks |
| Scale-normalized conformal residuals | `28bbed19a871` | calibration | Moderate | deriv-ticks |
| Venn–Abers versus Platt calibration | `21a39da2cdfe` | calibration | Moderate | deriv-ticks |
| Convex proper-score ensemble weights | `22c42954b89c` | ensemble | Moderate | deriv-ticks |
| Lag-corrected sequential calibration tests | `252a4c29f5c7` | validation | Strong | deriv-ticks |
| Dependence-adjusted paired score comparisons | `23b1d957a78e` | validation | Strong | deriv-ticks |
| Pooled ridge baselines | `2732dcc96e89` | features | Moderate | deriv-ticks |
| Interval scores matched to interval type | `286933bb4ac7` | loss | Strong | deriv-ticks |
| Joint coverage across expiry horizons | `284c96c15a17` | validation | Strong | deriv-ticks |
| Simplest ensemble within one standard error | `2837e718f9c1` | validation | Moderate | deriv-ticks |

“Strong” here concerns methodological validity, not demonstrated Deriv profitability.

No convincing contradiction to the weak-sign/stronger-magnitude prior emerged. The main qualifications are that conformal coverage does not guarantee selected-trade performance, and ensembling or optimizing proper scores does not automatically deliver calibration.
=== forecasting-methods__06of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__06of32/records.jsonl): **50 records**, in shard order. JSON, IDs, page citations and verbatim quotes passed validation.

Relevance counts: **3: 11 · 2: 34 · 1: 5 · 0: 0**. Reading depth: 44 full, five triage, one partial.

The ten most promising levers all use **Deriv ticks only**. Evidence grades concern the method, not a proven Deriv edge.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Update only after labels mature | `2b5aed2de735` | validation | strong |
| Delay-aware sequential e-value monitoring | `2e259a65ddca` | validation | strong |
| Sigmoid calibration with scarce independent outcomes | `29a5bff2ea76` | calibration | strong |
| Evaluate exact payoff, timing and tie losses | `30000f3047af` | validation | strong |
| Proper censored scoring for large-move forecasts | `2a3b4ee0fb49` | loss | moderate |
| Supervised cross-pair lag factors | `292e45a67dd2` | features | moderate |
| Average small feature-subset models | `2ea9ac787e92` | ensemble | moderate |
| Pool uncertainty regimes across pairs | `2b77c4925efc` | magnitude | moderate |
| Explicit zero-return probability mass | `30187e44c29a` | calibration | moderate |
| Expert router with ensemble fallback | `2e5b269ad36c` | ensemble | moderate |

No files were missing. **`320013ec2f47` remains partial** because truncated, corrupted text omits experimental details and the conclusion.

No convincing evidence contradicts the size-versus-sign prior. Important qualifications: outcome-weighted probability losses can change the calibration target; conformal coverage does not guarantee gated win rates; calibration can hurt already calibrated models. No document establishes a deployable Deriv direction edge.
=== forecasting-methods__07of32
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__07of32/records.jsonl): **50 valid records in shard order**, with 125 page-matched quotations.

Relevance counts: **3: 16 · 2: 24 · 1: 8 · 0: 2**. Depth: 39 full, 1 partial, 10 triage. None unreadable. The long document `32a72947ef0b` is explicitly marked partial.

The ten most promising levers are below. Evidence describes the source setting; FX transfer remains unproven. All require only **deriv-ticks**.

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Partially pool ensemble weights across pairs/horizons | `35395cc19fa9` | ensemble | moderate |
| Recalibrate final pooled probabilities | `3776efb6bbe1` | calibration | strong |
| Conformalize magnitude quantiles | `348d7f4ced80` | calibration | moderate |
| Leave-window-out residual calibration | `3531d7faf510` | calibration | moderate |
| Simultaneous block-bootstrap skill bands | `33fa7ac348a1` | validation | strong |
| Audit density residuals and their serial dependence | `331eab590c36` | validation | strong |
| Smooth daily/weekly absolute-return seasonality | `32d0d757d193` | magnitude | moderate |
| Online aggregation of volatility/quantile forecasters | `368dc3b55d65` | ensemble | moderate |
| Test other-pair features against autoregressive/noise controls | `35b37e922b30` | validation | moderate |
| Test cumulative calibration across forecast probabilities | `38e01f3bf212` | validation | moderate |

No reliable result directly contradicts the in-house FX sign/magnitude priors. Relevant qualifications: probability pooling can introduce underconfidence; estimated ensemble weights can lose their advantage after regime changes; large pretrained models can overfit scarce data. The HMM financial example predicts order flow, with statistically insignificant gains, and establishes no price-direction edge.
=== forecasting-methods__08of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__08of32/records.jsonl): **50 records**, in shard order. JSON, IDs, schema and all 142 finding quotations passed validation.

Relevance counts: **3: 11 · 2: 30 · 1: 6 · 0: 3**. Reading depth: 40 full, 9 triage, 1 partial.

Ten promising levers follow. Evidence grades concern the method; transfer to Deriv remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized beta calibration | `3d3de5ee33d4` | calibration | strong | Deriv ticks |
| Seasonal kernel densities for magnitude | `3b99412cfc6a` | magnitude | moderate | Deriv ticks |
| Joint location–scale boosted trees | `3e9ee7eaa7be` | magnitude | moderate | Deriv ticks |
| Proper scores focused on magnitude thresholds | `415e598cc6bd` | loss | moderate | Deriv ticks |
| Regularized probability stacking | `3c6cb930d1a4` | ensemble | moderate | Deriv ticks |
| Residual covariance to assess ensemble saturation | `3d8ac92b9704` | ensemble | strong | Deriv ticks |
| Calibration within changing trade selections | `41a9d17cdf0b` | validation | strong | Deriv ticks |
| Sequential calibration monitoring with e-values | `3b2aab5cfb18` | validation | strong | Deriv ticks |
| Murphy scores near the payout threshold | `3c48c237ea77` | validation | strong | Deriv ticks |
| Conditional calibration beyond pooled coverage | `3d5487b1856c` | validation | strong | Deriv ticks |

No files were missing. `3da76eb83ff3` is marked **partial** because corrupted body-text encoding prevented complete technical verification.

No convincing result overturns the size-versus-sign prior. Robust-loss and noisy-label studies motivate counter-tests to indiscriminate |return| weighting; ensemble studies qualify expectations of continued gains from additional correlated seeds. No document earned evaluation grade A under the requested standard.
=== forecasting-methods__09of32
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__09of32/records.jsonl): **50 records**, correct shard order, 130 page-cited findings and 95 levers.

Relevance counts: **3: 13 · 2: 22 · 1: 13 · 0: 2**. Reading depth: 34 full, 15 triage, 1 partial.

Ten promising levers—all usable with **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Distributional boosting for return magnitude and tails | `46ff0c37af60` | magnitude | Moderate |
| Probability-mixture weights shrunk toward equality | `497f03711273` | ensemble | Moderate |
| Sparse stacking with pooled coefficients | `48c6813202ff` | ensemble | Moderate |
| Reconcile forecasts across temporal aggregations | `454ea55c9e5e` | ensemble | Moderate |
| Partially pool volatility models across regimes | `45f7235eb7d6` | regime | Moderate |
| Shrunk correction using settled forecast residuals | `4412d4e873d3` | ensemble | Moderate |
| Shared or grouped multihorizon prediction heads | `4a05cf102ef0` | ensemble | Moderate |
| Explicit zero-return mass for tie-aware probabilities | `45f1582ea77c` | labels | Moderate |
| Dependence-aware Brier reliability/resolution diagnostics | `475d729119d7` | validation | Strong |
| Audit probability distortion from magnitude-weighted losses | `4954378f7aad` | loss | Strong |

None was entirely unreadable. **Chronos (`46fb566d9e70`)** was partially read because of length and corrupted extraction; limitations are recorded.

The main qualifications to the in-house priors concern calibration and weighting: lower ECE can accompany worse selection ranking; conformal coverage does not establish selected-trade win calibration; outcome-weighted losses can distort probabilities. Nothing credibly overturns the tree-model or magnitude-versus-sign priors, and no paper establishes a Deriv-ready direction edge under the specified settlement rules.
=== forecasting-methods__10of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__10of32/records.jsonl). Validated all 50 JSON records, shard order, and exact page-cited quotations.

Relevance: **3: 10 · 2: 35 · 1: 4 · 0: 1**. Depth: 44 full, 5 triage, 1 partial.

The ten most promising tests are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Calibrate the exact expiry winning event | `4b33eb2003c9` | calibration | moderate | deriv-ticks |
| Regularized beta/Dirichlet calibration | `4a891404fb5b` | calibration | moderate | deriv-ticks |
| Residual-quantile tracking with PI correction | `4b5ee1458b4d` | selection-gating | moderate | deriv-ticks |
| Shrunk, horizon-specific residual boosting | `4d1ed9076e19` | ensemble | moderate | deriv-ticks |
| Ridge/PCA over synchronized pair features | `4deca9837482` | features | moderate | deriv-ticks |
| Functional spline compression of tick histories | `51223ec0ef92` | features | moderate | deriv-ticks |
| Include coefficient uncertainty in gating intervals | `4ea008aa9a53` | selection-gating | moderate | deriv-ticks |
| Constrain ensemble weights and shrink toward equality | `51821148ae49` | ensemble | moderate | deriv-ticks |
| Evaluate log loss, Brier and actual payout together | `4fab6a807c0f` | validation | strong | deriv-ticks |
| Pool volatility through sparse shared factors | `4fbcc6e91cdb` | magnitude | moderate | deriv-ticks |

No unreadable files. `50033f21ba88` remains partial: its complete main paper was read; extensive supplementary material was omitted.

No convincing contradiction to the weak-sign/strong-magnitude prior emerged. Important qualifications: conformal coverage does not establish selected-trade profitability, return-weighted losses can change the probability target, and several advertised ensemble gains suffer from leakage or retrospective selection. No paper establishes a tie-aware Deriv direction edge.
=== forecasting-methods__11of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__11of32/records.jsonl): **50 records**, with shard order, JSON structure and all finding quotations checked against cited pages.

Relevance counts: **3: 15 · 2: 29 · 1: 4 · 0: 2**. Reading depth: 43 full, one selective book reading, six triages. No unreadable documents.

The ten most promising levers all use **Deriv ticks only**:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit return-weighted losses using unweighted proper scores | `52b11274ab0f` | validation | strong | Deriv ticks |
| Evaluate decisions near the payout break-even threshold | `59735601905b` | validation | strong | Deriv ticks |
| CORP reliability and calibration–resolution decomposition | `52e2651892a8` | validation | strong | Deriv ticks |
| Threshold-weighted CRPS for magnitude gates | `54437770d6b0` | validation | strong | Deriv ticks |
| Trim unstable models before equal-weight pooling | `55169e15a631` | ensemble | moderate | Deriv ticks |
| Add residual uncertainty to ensemble spread | `52cbabba77ee` | calibration | moderate | Deriv ticks |
| Regularize covariance-aware model pooling | `542ab68628b6` | ensemble | moderate | Deriv ticks |
| Restore joint dependence using historical residual ranks | `57a45519e265` | ensemble | moderate | Deriv ticks |
| Adapt small magnitude corrections after labels mature | `595a686b261b` | calibration | moderate | Deriv ticks |
| Pool smooth effects across pairs, then fit residual trees | `596038e295e2` | features | moderate | Deriv ticks |

The clearest qualification to the in-house priors concerns **absolute-return-weighted losses**: they can distort probability calibration, so retain unweighted proper-score evaluation. Conformal gating also requires explicit checks of temporal dependence and finite calibration-sample feasibility.

This shard provides no convincing evidence overturning the weak-direction/stronger-magnitude prior, and no demonstrated profitable Deriv FX edge. Strong evidence above generally supports an evaluation principle; its trading benefit remains untested.
=== forecasting-methods__12of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__12of32/records.jsonl): **50 records**, validated against shard order, JSON schema, and source quotations.

Relevance: **3: 9 · 2: 35 · 1: 5 · 0: 1**. Completed 44 full reads and six triages. Unreadable documents: **none**.

The ten most promising levers are below. Evidence describes methodological support, not demonstrated Deriv profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Evaluate probabilities at the contract’s break-even threshold | `5f885e661a34` | validation | strong | deriv-ticks |
| Pool forecasts across history lengths using PCA and shrinkage | `5a7defbe7c60` | ensemble | moderate | deriv-ticks |
| Recalibrate ensemble probabilities, allowing learned extremization | `5a17f03dc653` | calibration | moderate | deriv-ticks |
| Establish GARCH/EWMA magnitude baselines | `60353d437aad` | magnitude | moderate | deriv-ticks |
| Diagnose conditional interval calibration before gating | `5cce76bad69c` | validation | strong | deriv-ticks |
| Account for model and split searches in forecast comparisons | `5c1425a8a7d7` | validation | strong | deriv-ticks |
| Test incremental cross-pair information against univariate baselines | `605fb3af7bbd` | validation | strong | deriv-ticks |
| Preserve historical scale information after normalization | `60797bc736ba` | features | moderate | deriv-ticks |
| Reconcile direct and linear-combination return forecasts | `5c4f246ea3d9` | ensemble | moderate | deriv-ticks |
| Measure activity, recall and payoff alongside gate risk control | `5ce87f0272c3` | validation | strong | deriv-ticks |

No clean result overturns the in-house FX direction or boosted-tree priors. Material qualifications: conformal gates can become inactive, oracle ensemble guarantees can fail with estimated covariance, and return-weighted losses can distort probabilities relative to the bounded contract payoff. Volatility evidence principally supports **magnitude**, not sign.
=== forecasting-methods__13of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__13of32/records.jsonl): **50 records**, in shard order. JSON, schemas, quote lengths, source-page matches and numeric citations pass validation.

Relevance: **3: 12 · 2: 27 · 1: 11 · 0: 0**. Depth: **24 full, 15 partial, 11 triage**; partial coverage is explicitly recorded.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Decaying-step adaptive conformal | 64622d7b5e65 | calibration | moderate | Deriv ticks |
| Recalibrate the final pooled distribution | 6753a75343b0 | calibration | moderate | Deriv ticks |
| Shrink ensemble weights toward equality | 667329a59d38 | ensemble | moderate | Deriv ticks |
| Test local performance reversals | 686bcd9156a6 | validation | strong | Deriv ticks |
| Ensemble training-window lengths | 686bcd9156a6 | ensemble | moderate | Deriv ticks |
| Refit the entire pipeline when estimating uncertainty | 68daa034db9b | validation | strong | Deriv ticks |
| Audit return-weighted probability losses | 634e253a8afd | loss | strong | Deriv ticks |
| Cross-pair absolute-return dependence | 664d39afbca7 | magnitude | moderate | Deriv ticks |
| Adaptive local variance windows | 68e5474765f0 | magnitude | moderate | Deriv ticks |
| Evaluate calibration and payout on selected trades | 67f8352b6054 | selection-gating | moderate | Deriv ticks |

No document was wholly unreadable. MIRAI (`66f96049a46f`) has corrupted extraction on pages 3–4.

No reviewed result establishes a clean short-horizon FX sign edge contradicting the priors. Copula evidence supports the magnitude/sign distinction. Proper-scoring theory challenges interpreting return-weighted classification outputs as calibrated probabilities; conformal results also show that average coverage can conceal uninformative intervals.
=== forecasting-methods__14of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__14of32/records.jsonl): **50 records in shard order**, with 118 levers. JSON, IDs, quote lengths and page locations verified.

Relevance counts: **3: 15 · 2: 30 · 1: 5 · 0: 0**. Reading depth: 44 full/relevant-chapter reads, one partial, five triaged.

The ten most promising transfers are below. Evidence concerns the source method; Deriv profitability remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Distributional boosted trees for return magnitude | `6bfd25b5d532` | magnitude | Moderate | deriv-ticks |
| Pareto tails on volatility-standardized returns | `703c5c6404bd` | magnitude | Moderate | deriv-ticks |
| Account for common ensemble residual factors | `6a5a3fc53a63` | ensemble | Moderate | deriv-ticks |
| Shrink dynamic weights toward stable positive pools | `6c3c52c05428` | ensemble | Moderate | deriv-ticks |
| Pool pairs and expiries with task embeddings | `6fe2ffe7c81a` | ensemble | Moderate | deriv-ticks |
| Regularized Platt/temperature calibration baseline | `6ece47cdd8c6` | calibration | Moderate | deriv-ticks |
| Low-dimensional local kernel calibration | `6bb3084c2218` | calibration | Moderate | deriv-ticks |
| Adaptive conformal magnitude intervals | `6c646e638172` | calibration | Moderate | deriv-ticks |
| Online quantile correction using matured labels | `6fdac94f89b5` | calibration | Moderate | deriv-ticks |
| Independently recalibrate return-weighted classifiers | `6b6cc2f0fd3d` | loss | Strong | deriv-ticks |

No document was wholly unreadable. **TimeSAF (`6ee906ddbda3`) remains partial** because portions of pages 8–16 are corrupted.

The clearest qualification of the in-house priors is that outcome-weighted losses change the statistical target; their outputs need independent probability calibration. The shard also reinforces that magnitude or mean-return skill does not establish binary win-probability skill. No paper directly verifies the reported in-house FX performance.
=== forecasting-methods__15of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__15of32/records.jsonl): **50 valid records**, in shard order; **142 quotes verified** against their cited pages.

Relevance: **3: 12 · 2: 31 · 1: 6 · 0: 1**. Reading depth: **20 full, 23 partial, 7 triage**. The full-reading requirement remains incomplete; partial coverage is explicitly recorded.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shrink ensemble weights toward equal weights | `70ac14aba3c6` | ensemble | moderate | deriv-ticks |
| Pool encoder with pair-specific heads | `716a78dfa8e0` | ensemble | moderate | deriv-ticks |
| Compare scaled and raw CRPS | `7469022167a7` | validation | strong | deriv-ticks |
| Beta-CDF recalibration of pooled probabilities | `752de15e67b1` | calibration | moderate | deriv-ticks |
| Clark–West test for nested linear models | `75c4dad47eee` | validation | strong | deriv-ticks |
| Validate target-only versus cross-pair subsets | `76c454524b12` | ensemble | moderate | deriv-ticks |
| Local PIT recalibration | `774fc46f70c5` | calibration | moderate | deriv-ticks |
| Convert magnitude predictions into exceedance distributions | `77bfeb11055e` | calibration | moderate | deriv-ticks |
| Compare robust context scaling | `78d3dd17c764` | features | moderate | deriv-ticks |
| Shrink or abstain in sparse calibration regions | `795b760d7b76` | selection-gating | moderate | deriv-ticks |

No file was wholly unreadable. Material extraction gaps affect `716511842eb5`, `78d3dd17c764`, and `78ecf692250d`.

No credible contradiction of the FX priors was established. Qualifications: averaging can require recalibration; magnitude weighting changes evaluation priorities; calibration intervals do not automatically bound conditional win probabilities. The sequential-testing paper was downgraded after identifying proof gaps.
=== forecasting-methods__16of32
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__16of32/records.jsonl): **50 records**, in shard order, with **135 source-verified page quotes**. JSON and schema checks passed.

Relevance counts: **3: 12 · 2: 25 · 1: 12 · 0: 1**. This comprises 37 full reads and 13 triage records.

The ten most promising levers all use **`deriv-ticks`**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Pool standardized examples across pairs in regularized boosted trees | `7e104c5c30cd` | features | moderate |
| Test adaptive input centering and scaling | `83338bed88a7` | features | moderate |
| Combine experts using price-derived regime features | `7aff4710f538` | ensemble | moderate |
| Benchmark equal weights and strongly shrunk ensemble weights | `80bfa1cad283` | ensemble | moderate |
| Select training-window length within chronological validation | `81f1150899a7` | validation | moderate |
| Gate trades using conservative calibration lower bounds | `7ba073cdcf9d` | selection-gating | moderate |
| Keep plain sequential split conformal as a baseline | `823a37f3b7d1` | calibration | moderate |
| Test recency-weighted conformal residual quantiles | `7d09be24289d` | calibration | moderate |
| Audit magnitude coverage separately for ties and large moves | `842dbff66045` | validation | moderate |
| Evaluate actual payout thresholds and predeclared magnitude gates | `7d2c9628702d` | validation | strong |

These grades concern methodological evidence, not demonstrated Deriv profitability.

No documents were missing or wholly unreadable; extraction damage is flagged in affected records.

Nothing convincingly overturns the weak price-only direction or trees-versus-nets priors. The clearest qualification concerns adaptive conformal: it can under-cover, and ordinary split conformal can remain competitive. Aggregate coverage also does not establish coverage among selected trades or rare large moves.
=== forecasting-methods__17of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__17of32/records.jsonl). Verified 50 records in shard order, 121 verbatim page-cited findings, and 118 levers.

Relevance counts: **3: 11 · 2: 33 · 1: 4 · 0: 2**. Completed 44 full or relevant-chapter reads and six triages. **None unreadable.**

The ten most promising levers all use **deriv-ticks**. Evidence grades concern methodological support; FX profitability remains unestablished.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Shrink pair-specific coefficients toward pooled estimates | `88a1cac4d0df` | direction | moderate |
| Benchmark a compact causal CNN | `8d83fe8f106d` | features | moderate |
| Ensemble adaptive-conformal learning rates | `882c20f4cdd2` | calibration | moderate |
| Conformalize volatility-scaled residuals | `882c20f4cdd2` | magnitude | moderate |
| Audit calibration around trading thresholds | `89b1c71320fc` | validation | strong |
| Check coverage inside selected trades | `8d0ceee9728a` | validation | strong |
| Shrink uncertain regime-specific ensemble weights | `89fcaab6f6a2` | ensemble | moderate |
| Audit calibration after return-weighted training | `8a1407a3a7af` | calibration | moderate |
| Account for overlapping horizons in uncertainty estimates | `86219c6df292` | validation | strong |
| Use clustered paired comparisons and multiplicity correction | `8864938816bd` | validation | strong |

Nothing credibly overturns the in-house FX performance estimates or establishes a tradable Deriv direction edge. The main qualifications are that return-weighted losses can change the probability target, marginal conformal coverage does not guarantee selected-trade reliability, and post-hoc scaling does not automatically ensure calibration. The ensemble miscalibration paper’s headline claims have serious theoretical and reporting inconsistencies, documented in its record.
=== forecasting-methods__18of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__18of32/records.jsonl): **50 records**, in shard order. JSON, IDs, schema, and all 117 quotations—including 41 numeric findings—validated.

Relevance counts: **3: 14 · 2: 21 · 1: 11 · 0: 4**. Reading depth: 33 full, 15 triage, 2 partial.

The 10 most promising levers are below. Evidence grades concern the source result; FX transfer remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Hierarchical pooling across pairs | `9183b979066e` | calibration | Moderate | deriv-ticks |
| Shrunk local Beta calibration | `92f10865548d` | calibration | Moderate | deriv-ticks |
| Beta/Venn–Abers versus no calibration | `93e5f15847ba` | calibration | Moderate | deriv-ticks |
| Separate forgetting for location and scale | `8fdd4a494fc1` | magnitude | Moderate | deriv-ticks |
| Noncrossing conformal quantiles | `8f7c95363d82` | calibration | Moderate | deriv-ticks |
| Synchronized residual-block bagging | `948e77bbe763` | ensemble | Moderate | deriv-ticks |
| Explicit up/down/tie probabilities | `9565c3ab4471` | labels | Moderate | deriv-ticks |
| Arithmetic mean of scaled proper scores | `93a941edb458` | validation | Strong | deriv-ticks |
| Tail evaluation using every observation | `925047d12ab0` | validation | Strong | deriv-ticks |
| Untouched prospective test after model search | `9241886ff167` | validation | Strong | deriv-ticks |

**Unreadable documents: none.** Partial records: `900012159f38` and `9067b701828a`, with corrupted figure text and omitted extended figure appendices documented.

Calibration sometimes worsens strong trees, qualifying its use as an edge improver. Neural wins on other domains qualify universal tree-superiority claims, but no convincing result here overturns the magnitude-versus-sign prior or establishes a tradable Deriv direction edge.
=== forecasting-methods__19of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__19of32/records.jsonl): **50 records**, in shard order. JSON, schema, IDs, quotes, pages and numerical citation checks pass.

Relevance counts: **3: 11 · 2: 28 · 1: 10 · 0: 1**. Depth: 37 full, 2 partial, 11 triage.

The ten strongest candidates below concern methods and validation; “strong” does not establish profitable FX prediction.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Release online labels only after expiry | `9792c091af5e` | validation | strong | Deriv ticks |
| Require simple baselines and shuffled-context controls | `97abddd1821c` | validation | strong | Deriv ticks |
| Recalibrate ensembles while accounting for dependence | `9827735b8b38` | calibration | strong | Deriv ticks |
| Shrunk rolling joint PIT recalibration | `99829868980b` | calibration | moderate | Deriv ticks |
| Separate calibration from discrimination in scores | `99eccc2da895` | validation | strong | Deriv ticks |
| Shrunk beta calibration of return distributions | `9b4957815144` | calibration | moderate | Deriv ticks |
| Lag-aware sequential calibration monitoring | `9be3f8a0971b` | validation | strong | Deriv ticks |
| Compact pooled multihorizon models and seed ensembles | `9cc39b44b26e` | ensemble | moderate | Deriv ticks |
| Small Student-t mixture return heads | `9cfe94b8cd6e` | magnitude | moderate | Deriv ticks |
| Distributional forests that detect variance changes | `9d22264930c0` | magnitude | moderate | Deriv ticks |

No document was wholly unreadable. Partial records are `96811b6fafa8` (long-paper proof sections omitted) and `9d947ee31f44` (unreadable appendix plots).

No convincing contradiction of the in-house priors emerged. Simple baselines remain competitive, and distributional gains mainly support magnitude forecasting. The shard does **not** independently validate the reported short-horizon direction edge. It also shows why calibration or ensemble improvements need separate payout evaluation, and why robust losses should be tested against return-weighted objectives.
=== forecasting-methods__20of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__20of32/records.jsonl): **50 records**, with JSON, shard order, quote lengths and numeric evidence checks passing.

- Relevance **3: 11**, **2: 29**, **1: 10**, **0: 0**.
- **40 full reads**, **10 triage reads**; none unreadable. Some figure text was degraded.

The ten most promising levers below all use **Deriv ticks only**. Evidence describes the source result, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool regularized models across pairs | `9f6d8f807d94` | ensemble | Moderate | Deriv ticks |
| Boosted quantile trees for magnitude | `a3833a3dd37c` | magnitude | Moderate | Deriv ticks |
| Monotone return CDF for coherent probabilities | `9ffc3a380147` | magnitude | Moderate | Deriv ticks |
| Shrink probabilities toward historical baselines | `9f9618d3726f` | calibration | Moderate | Deriv ticks |
| Shrink ensemble weights toward equality | `a0f8a9037203` | ensemble | Moderate | Deriv ticks |
| Heavy-tailed residual-density mixtures | `a1af4119d596` | ensemble | Moderate | Deriv ticks |
| Compare Venn–Abers with simpler calibrators | `a1032ea6743f` | calibration | Moderate | Deriv ticks |
| Calibrate ensemble bias and spread | `a0fa4bbde2b8` | calibration | Moderate | Deriv ticks |
| Score contract and magnitude thresholds explicitly | `a02735b850e6` | validation | Strong | Deriv ticks |
| Test paired losses with dependence-aware uncertainty | `a071dcc079fb` | validation | Strong | Deriv ticks |

Nothing credibly overturns the weak-direction/stronger-magnitude prior. TimesNet’s daily FX results favor the linear baseline. Two findings qualify existing practices: loss weighting can damage probability calibration, and combining calibrated forecasts need not preserve calibration. Apparently strong reservoir results have serious timing or leakage concerns.
=== forecasting-methods__21of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__21of32/records.jsonl). Validation passed: 50 JSON lines, shard-order IDs, and verbatim page-cited findings.

Relevance counts: **3: 14 · 2: 27 · 1: 9 · 0: 0**. Reading depth: **27 full, 14 partial, 9 triage**.

The ten most promising transferable levers are below. All require only `deriv-ticks`; evidence grades do **not** establish an FX trading edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool regularized boosted trees across pairs | a76ecc9bfb79 | ensemble | moderate | deriv-ticks |
| Add causal multiscale histories | a599b338e44a | features | moderate | deriv-ticks |
| Shrink stacking weights toward equal weights | a6bf8d243087 | ensemble | moderate | deriv-ticks |
| Fit conditional scale from honest residuals | a89cf99d0f35 | magnitude | moderate | deriv-ticks |
| Shrink coefficients across adjacent quantiles | a94d6d90e0ef | magnitude | moderate | deriv-ticks |
| Calibrate scale-normalized residual distributions | a8de9a6b6eb4 | calibration | moderate | deriv-ticks |
| Retrieve residuals from similar volatility regimes | aa511c1191b9 | calibration | moderate | deriv-ticks |
| Track quantiles with a small online linear model | aa5a0f9f379a | calibration | moderate | deriv-ticks |
| Audit feature-conditional quantile hits sequentially | a8afae4658e1 | validation | moderate | deriv-ticks |
| Evaluate calibration through actual payout regret | aafdcdb9f548 | selection-gating | moderate | deriv-ticks |

No document was wholly unreadable. **Timer (`a81ab2ff761d`) has partly corrupted extracted text.** Partial reading coverage is explicitly recorded.

Nothing directly tests or overturns the in-house FX AUC priors. Important qualifications: magnitude-weighted losses can distort win probabilities; redundant or weak ensemble members can hurt; marginal conformal coverage does not certify calibration among selected trades. Several papers support retaining simple, regularized models as serious baselines.
=== forecasting-methods__22of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__22of32/records.jsonl): **50 records**, verified in shard order, with valid JSON, 134 exact page quotes and 117 levers.

Relevance counts: **3: 10 · 2: 32 · 1: 8 · 0: 0**. Depth: 41 full reads, eight triages, one long review read by selected relevant sections. No unreadable documents.

Ten promising levers—all use **deriv-ticks**; evidence describes transfer potential, not demonstrated Deriv profitability:

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Rolling empirical residual-CDF calibration | `b33cd2ceecac` | calibration | moderate |
| Shrunk pair/session-conditioned calibration | `aedd3e54ce0d` | calibration | moderate |
| Online Brier expert aggregation | `af2582ef6d22` | ensemble | moderate |
| Constrained horizon-specific ensemble weights | `acc33ac9bf77` | ensemble | moderate |
| Pooled direct multi-horizon quantiles | `acedb348ade4` | magnitude | moderate |
| Horseshoe-shrunk quantile regression | `b442b0920549` | magnitude | moderate |
| Parsimonious multiscale HAR baseline | `b1f804107240` | magnitude | moderate |
| Hierarchical lag shrinkage | `b1f804107240` | features | moderate |
| Proper censored tail scores | `af5a9964a25d` | validation | moderate |
| Explicit unchanged-price probability mass | `ae693457134b` | labels | weak |

No convincing contradiction of the FX priors emerged. Qualifications: outcome-weighted losses can distort event probabilities; correlated seeds provide limited diversification; better calibration need not produce profitable decisions. A PV study favors LSTM over its fixed GBR comparator (`b435830d0d7a`), offering limited evidence against the broader tree-model prior.
=== forecasting-methods__23of32
Created and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__23of32/records.jsonl): **50 records**, matching shard order, with 95 exact page-cited quotes.

**Full-text coverage remains incomplete:** 6 full reads, 35 explicitly marked partial reads, 9 triages. No files were missing or unreadable.

Relevance counts: **3: 10 · 2: 31 · 1: 6 · 0: 3**

The ten leading candidates below all require **deriv-ticks**; their evidence is **moderate**, without demonstrated Deriv profitability.

| Lever | Document ID | Kind |
|---|---|---|
| Local expert pools with sparse-data shrinkage | `ba439eb3c0c4` | ensemble |
| GA-NoVaS magnitude forecasts | `b50bfdf803e3` | magnitude |
| Context-dependent residual correction | `bad0bb62a600` | regime |
| Shared cross-pair volatility factors | `b9499c2d62ea` | magnitude |
| Forgetful online CRPS pooling | `bc36d6a46b9b` | ensemble |
| Robust median quantile pooling | `bb78326a9196` | ensemble |
| PIT-density recalibration | `b6efe98bf05a` | calibration |
| Adaptive residual-pool calibration | `b98e3343ce94` | calibration |
| Payoff-focused kernel calibration penalties | `bc50b57ac236` | loss |
| Joint PIT uniformity and dependence diagnostics | `b558f99bd4f0` | validation |

No convincing short-horizon FX contradiction of the in-house priors emerged. SoTra raises calibration concerns about utility-weighted probability training, but supplies medical evidence rather than an FX ablation.
=== forecasting-methods__24of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__24of32/records.jsonl): 50 records in shard order. JSON, schema, IDs and 94 verbatim page citations passed validation.

Relevance counts: **3: 17 · 2: 25 · 1: 6 · 0: 2**.

**Reading remains incomplete:** 10 full readings, 32 partial readings and 8 triages. No files were missing or wholly unreadable; incomplete coverage is explicitly marked.

The ten most promising candidates are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Separate mean/volatility models with residual resampling | c1ef301945ae | magnitude | moderate | deriv-ticks |
| Pool related pairs with pair-specific conditioning | c1bb225c2ed9 | features | moderate | deriv-ticks |
| Bayesian binning calibration | c1688bddfa3c | calibration | moderate | deriv-ticks |
| Past-only online bin recalibration | bd61ac2d50db | calibration | moderate | deriv-ticks |
| Fixed-persistence volatility baseline | bec1be949e8b | magnitude | moderate | deriv-ticks |
| Bootstrap model-form ensembles | c38cd724c822 | ensemble | moderate | deriv-ticks |
| Equal-weight parsimonious ensembles | c2c36b2e44c0 | ensemble | moderate | deriv-ticks |
| Calibration/discrimination decomposition with uncertainty | c40b8c079cb4 | validation | moderate | deriv-ticks |
| Rolling performance tests adjusted for repeated testing | be3b85717ae9 | validation | moderate | deriv-ticks |
| Predeclared payout-relevant threshold scoring | c568b7b48a22 | selection-gating | moderate | deriv-ticks |

Evidence grades describe the source settings; none establishes a Deriv trading edge.

The main qualifications to the in-house priors are that recalibration can worsen strong classifiers, an additional adaptive conformal offset produced little incremental benefit, and bagging gains sometimes came primarily from model-form diversity rather than parameter variation. No persuasive contradiction of the magnitude-versus-sign prior emerged from the inspected material.
=== forecasting-methods__25of32
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__25of32/records.jsonl): **50 records**, in shard order. All JSON parses; all 121 finding quotes match their cited source pages.

Relevance: **3: 13 · 2: 26 · 1: 11 · 0: 0**. Depth: 38 full, 11 triaged, 1 partial.

The ten most promising levers are below. Evidence describes methodological support, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Require a zero-return, horizon-matched residual baseline | `c89bae66d4c9` | validation | strong | deriv-ticks |
| Compare pipelines using conditional loss differences | `cc6e86b69e2c` | validation | strong | deriv-ticks |
| Test calibration conditional on rival forecasts | `c667ba436051` | calibration | strong | deriv-ticks |
| Use debiased reliability estimates with block uncertainty | `cc4e4bde39f5` | validation | strong | deriv-ticks |
| Benchmark temperature and shrinkage Platt scaling | `cb654a65acb7` | calibration | moderate | deriv-ticks |
| Select trade gates with multiplicity-controlled risk bounds | `c69aa191d836` | selection-gating | moderate | deriv-ticks |
| Predict residual quantiles from matured historical errors | `c9d75513be1a` | magnitude | moderate | deriv-ticks |
| Map a compact magnitude score into an absolute-return CDF | `cc2cb916bbfe` | magnitude | moderate | deriv-ticks |
| Pool a small distributional model across pairs | `c668d936226b` | ensemble | moderate | deriv-ticks |
| Enforce noncrossing quantiles | `c951c484a5e3` | calibration | moderate | deriv-ticks |

No document was wholly unreadable. **`cc7a04d9545c`**, *Forecasting Future World Events with Neural Networks*, is partial because its supplied extraction omits central methods/results pages.

No convincing result overturns the in-house magnitude-versus-sign or tree-model priors. Important qualifications: the attention model’s financial experiment uses contemporaneous constituents (`c764112970a1`); low binned calibration error can be misleading (`cc4e4bde39f5`); and finite simulation-ensemble size can create apparent scoring gains (`cc97de46cb39`).
=== forecasting-methods__26of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__26of32/records.jsonl): **50 records**, comprising 39 full reads and 11 triages.

Relevance counts: **3: 11 · 2: 28 · 1: 9 · 0: 2**. Validation passed for JSON parsing, shard order, required fields and all 123 page-cited quotes. Unreadable documents: **none**.

Ten promising levers follow. Evidence grades concern the source mechanism, not demonstrated FX profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit calibration after absolute-return-weighted training | d2771b85e6f2 | loss | strong | deriv-ticks |
| Benchmark equal-weight and strongly shrunk ensembles | d3addc3de880 | ensemble | strong | deriv-ticks |
| Limit stacking complexity to independent validation information | d172ea7b04bc | ensemble | strong | deriv-ticks |
| Estimate a compact conditional CDF for sign and magnitude probabilities | d17a9504bb2b | magnitude | moderate | deriv-ticks |
| Pool pair coefficients with Bayesian shrinkage | cf17cdd565a4 | features | moderate | deriv-ticks |
| Learn small error-predictive calibration groups | d1ed18124b03 | calibration | moderate | deriv-ticks |
| Audit coverage by pair, volatility regime and time block | d590f760a973 | validation | strong | deriv-ticks |
| Represent flat-price ties explicitly | d31a0c5f0ae8 | labels | strong | deriv-ticks |
| Fit sparse nonlinear volatility autoregressions | d54d6ad3e9cf | magnitude | moderate | deriv-ticks |
| Use causally filtered volatility regimes for magnitude gates | d477b1a2eca3 | regime | moderate | deriv-ticks |

No convincing result overturns the tree-baseline or magnitude-versus-sign priors. Two qualifications matter: realized-return weighting can distort probability calibration, and conformal interval coverage does **not** guarantee selected-trade win rates. No paper establishes a tradable Deriv direction edge.
=== forecasting-methods__27of32
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__27of32/records.jsonl): **50 records, in shard order**, containing 101 levers and 141 page-checked quotations.

Relevance counts: **3: 13 · 2: 29 · 1: 6 · 0: 2**. Read fully: 42; triaged: 8. Unreadable: none. No evaluation earned grade A.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Model down, exact tie, and up separately | `dd8fad4323a3` | labels | moderate | deriv-ticks |
| Distributional boosted trees for magnitude | `db4b8730941c` | magnitude | moderate | deriv-ticks |
| Evolving Fourier seasonality for volatility | `d7bc3852c5d9` | magnitude | moderate | deriv-ticks |
| Adaptive loss-discounted ensembles | `d70b801ce4f8` | ensemble | moderate | deriv-ticks |
| Shrunk stacking on chronological out-of-fold predictions | `d7296a69864f` | ensemble | moderate | deriv-ticks |
| Update ensemble weights only after labels settle | `d72866ae177a` | validation | strong | deriv-ticks |
| Sort or isotonic-project crossed quantiles | `d7e5a569453e` | calibration | strong | deriv-ticks |
| Assess calibration after final ensemble aggregation | `dd333e71318a` | calibration | strong | deriv-ticks |
| Evaluate utility across prespecified trading thresholds | `dc272f6a0060` | validation | strong | deriv-ticks |
| Diagnose joint forecast dependence across pairs/horizons | `d8fd88bdf5fa` | calibration | strong | deriv-ticks |

No convincing result overturns the in-house direction-versus-magnitude or tabular-model priors. Important qualifications: aggregation can worsen calibration, and better proper scores need not improve binary-contract utility. The reported adaptive-conformal failure in `d9c42d9cde19` uses reversed radius feedback, so it is not sound evidence against the in-house approach.
=== forecasting-methods__28of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__28of32/records.jsonl): 50 records in shard order. JSON, IDs, numeric citations and verbatim quotes passed validation.

Relevance counts: **3: 14 · 2: 29 · 1: 7 · 0: 0**. Reading depth: **10 full, 33 partial, 7 triage**. The requested whole-document reading remains incomplete for those 33 partial records. No documents were unreadable.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Prediction-bucket reliability checks | e59fecdaf53a | calibration | Strong | deriv-ticks |
| Recalibrate magnitude-weighted classifiers | e15dde0b65fb | calibration | Strong | deriv-ticks |
| Dependence-aware comparisons and search correction | e586732ea4c3 | validation | Strong | deriv-ticks |
| Bellman conformal interval calibration | e25d3c1857ff | calibration | Moderate | deriv-ticks |
| ARCH variance baseline | e0bf86939d87 | magnitude | Moderate | deriv-ticks |
| Student-t mixture volatility density | deab19380f8c | magnitude | Moderate | deriv-ticks |
| Tree forecasts feeding compact quantile models | e0679a7b4ea1 | ensemble | Moderate | deriv-ticks |
| Small interval ensembles with coverage checks | de828c6fcd4c | ensemble | Moderate | deriv-ticks |
| Exponential averaging of neural weights | e14ddab6a029 | ensemble | Moderate | deriv-ticks |
| Sparse, slowly changing ensemble weights | e2b7d233d349 | ensemble | Moderate | deriv-ticks |

“Strong” here includes mathematical validation mechanisms; it does not mean demonstrated FX profitability.

Two qualifications to the in-house priors stand out: realized-|return| weighting generally changes the probability target, and Diebold challenges treating pseudo-out-of-sample selection as universally superior to penalized full-sample model comparison. Conformal coverage also does not guarantee selected-trade win rates. The reviewed material establishes no Deriv-like direction edge.
=== forecasting-methods__29of32
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__29of32/records.jsonl): **50 records**, in shard order; 114 page-verified finding quotes and 113 levers.

Relevance counts: **3: 12 · 2: 29 · 1: 5 · 0: 4**. Full reads: 41; triage: 9.

The ten strongest candidates below all use **Deriv ticks**. Evidence grades concern the source result, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Delayed-feedback MultiQT recalibration | `eef0fedc2890` | calibration | moderate | Deriv ticks |
| Correct for selecting conformal coverage levels | `edb5ca577894` | validation | strong | Deriv ticks |
| Audit threshold frequency and exceedance severity separately | `e9c72c6cd63a` | calibration | strong | Deriv ticks |
| Low-capacity conditional PIT recalibration | `ebb2b013eb21` | calibration | moderate | Deriv ticks |
| Test state-dependent skill with search adjustment | `e9a8dd72c570` | validation | moderate | Deriv ticks |
| Sparse, jointly smoothed quantile models | `ea47dccd3084` | loss | moderate | Deriv ticks |
| Pool normalized histories across pairs | `e8d9d4ff0aa8` | ensemble | moderate | Deriv ticks |
| Equal-weight ensembles; shrink learned weights | `eda72b19a2fd` | ensemble | moderate | Deriv ticks |
| Compress volatility histories with MIDAS bases | `ec5e37adbdb1` | features | moderate | Deriv ticks |
| Enforce coherent direction, tie and magnitude probabilities | `ed8c6b1b5c88` | calibration | moderate | Deriv ticks |

No document was entirely unreadable. `ec0673f1f3a3` has damaged equation and numerical extraction, flagged in its record.

No convincing result overturns the weak FX direction or tabular-tree priors. Some electricity studies favor deep nets, but transfer is unproven. The clearest qualification concerns conformal gating: overall coverage does not establish coverage or win rate among selected trades, and tuning coverage levels requires additional correction.
=== forecasting-methods__30of32
[records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__30of32/records.jsonl) contains all **50 records**, in shard order. JSON, IDs, schema, and **116 page-cited quotes** passed validation.

Relevance counts: **3: 13 · 2: 26 · 1: 9 · 0: 2**. Reading depth: **13 full, 26 partial, 11 triage**. No files were unreadable; the 26 partial readings remain incomplete and are explicitly marked.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit coverage after trade selection | f3176171da72 | validation | strong | deriv-ticks |
| Evaluate near the payout threshold | efdf887a72bc | validation | strong | deriv-ticks |
| Use conditional reliability diagnostics | f20e0b1b3775 | validation | strong | deriv-ticks |
| Shrink ensemble weights toward equality | f3b7f4a4f68e | ensemble | moderate | deriv-ticks |
| Combine quantiles with smooth adaptive weights | f390585fef91 | ensemble | moderate | deriv-ticks |
| Audit predictable probability residuals | f203a2582732 | validation | strong | deriv-ticks |
| Learn ordered magnitude thresholds | f5e0eb697afa | labels | moderate | deriv-ticks |
| Test causal calendar and seasonal features | f5810a42f0f4 | features | moderate | deriv-ticks |
| Model price-change signs, sizes and waiting times | f3de64aa3c82 | magnitude | weak | deriv-ticks |
| Track magnitude intervals with conformal PID | f44ec51e5c20 | calibration | weak | deriv-ticks |

The main challenge to the priors concerns **conformal gating**: marginal or adaptive coverage does not automatically establish selected-trade reliability. Some nonfinancial benchmarks favor deep models, but none establishes a robust Deriv direction edge. The directly relevant EUR/USD example reports distributional improvements with evaluation-week parameter selection, rather than demonstrated directional profitability.
=== forecasting-methods__31of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__31of32/records.jsonl): **50 records**, matching shard order. JSON, schema, quotes and numeric citations validated.

Relevance counts: **3: 13 · 2: 30 · 1: 6 · 0: 1**. Reading depth: **7 full, 36 partial, 7 triage**; omissions are recorded. No unreadable files.

Ten promising levers—all can be tested using **deriv-ticks**. Evidence grades concern the method, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Sequential comparisons with delayed labels | `fd87e23a30c6` | validation | strong |
| Rolling tests for forecast bias | `f6afcb67541b` | validation | moderate |
| Correct inference for persistent predictors | `fb49ee809090` | validation | strong |
| Online residual-quantile adaptation | `faf6a90b76ff` | calibration | moderate |
| Calibration using lagged cross-pair residuals | `fcc1baf15a71` | calibration | moderate |
| Equal-weight ensembles with simple calibration | `f71c69a6bbfc` | ensemble | moderate |
| Smooth confidence weights for specialists | `f69d766bce34` | ensemble | moderate |
| Match magnitude losses to decision regions | `f75df29353b8` | loss | moderate |
| Horizon-specific corrections to pooled forecasts | `f8bd28093c8e` | ensemble | moderate |
| Evaluate actual payout, timing and tie rules | `fa7f39fa497d` | validation | strong |

No convincing direct contradiction of the in-house FX findings emerged. Qualifications: shared information can harm ensemble accuracy, and class-weighted/focal losses hurt some clinical forecasts. Neither directly tests Deriv or return-magnitude-weighted trading losses.
=== forecasting-methods__32of32
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/forecasting-methods__32of32/records.jsonl): 50 ordered records. JSON, shard IDs and all 128 quoted passages verified.

Relevance: **3: 12 · 2: 33 · 1: 4 · 0: 1**. Depth: **5 full, 40 partial, 5 triage**. The partial entries do **not** satisfy the requested full-reading depth.

Most promising levers below all need **`deriv-ticks`**. Evidence strength reflects methodological support, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Evaluate conformal coverage among selected trades | c74ea6301c77 | selection-gating | Strong |
| Charge exact settlement rules and ties | 3010276a9610 | loss | Strong |
| Account for overlapping expiry outcomes | ffce92482e3d | validation | Strong |
| Test stability across periods and windows | b034b42a7e2d | validation | Strong |
| Fit horizon-specific calibration | fe2f385c7497 | calibration | Moderate |
| Pool different training-window forecasts | ffd0b5d465be | ensemble | Moderate |
| Shrink ensemble weights toward equal weights | ff77bf7dbb98 | ensemble | Moderate |
| Compare absolute-return volatility features | 4c24c7cd52b0 | magnitude | Moderate |
| Share channel-independent temporal encoders | ffd4021d25b4 | features | Moderate |
| Benchmark heavy-tailed conditional volatility | 0e466ded2fa8 | magnitude | Moderate |

No entire file was unreadable. **d6813a5c85d3** ends before later chapters advertised in its contents; some other figures have corrupt OCR.

The main qualifications to the in-house priors are that adaptive conformal coverage does not ensure selected-trade correctness, magnitude-weighted losses can misalign with fixed payouts, and historical daily currency-trend profits sometimes existed but later faded. Nothing extracted independently verifies the in-house edge estimates.
=== fx-currencies__01of02
Saved [records.jsonl](/tmp/claude-1000/-home-sean-git-binary-algo/ff7f09cd-9df3-4f26-8b91-76d69bf436c4/scratchpad/lit/work/fx-currencies__01of02/records.jsonl): **50 records**, verified in shard order, with 109 verbatim page quotations and 71 testable levers.

Relevance counts: **3: 21 · 2: 8 · 1: 19 · 0: 2**. Reading depth: 28 full, 21 triage, one partial.

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale log realized-volatility forecasts | `19bf21b8ccdc` | magnitude | Moderate | Deriv ticks |
| Cross-pair liquidity-stress aggregate | `58d647107787` | selection-gating | Moderate | Dukascopy |
| Session × spread × volatility gates | `2fe2933b5b32` | selection-gating | Moderate | Dukascopy |
| Announcement-specific magnitude regimes | `21aac91efe5b` | regime | Moderate | On-disk calendar |
| Pair-specific session direction priors | `60c1b9640700` | direction | Weak | Dukascopy |
| Lagged equity-index features for USDJPY | `205f3e3b7534` | direction | Weak | External index quotes |
| Genuine lagged signed-flow inputs | `2c5b65c14152` | data | Moderate | External signed transactions |
| Dependence-aware binary significance tests | `29f74353084c` | validation | Moderate | On-disk |
| Window-selection and instability-aware tests | `5d978647c3cb` | validation | Strong | On-disk |
| Raw-tick entry and fixing-timestamp audit | `60c1b9640700` | labels | Strong | On-disk |

No document was unreadable. `58d647107787` was partially read: substantive main sections, relevant tables and proxy-method appendices; remaining supplementary material was mapped.

Qualified challenges to the priors include lagged signed-flow forecasting, historical session-direction effects, and a small reported hourly regime-expert correlation. None establishes a robust minute-scale Deriv edge. Hurst and multifractal results largely support magnitude rather than sign. The classic `6a7fca9bc21a` forecasting headline uses **future realized order flow**, so it does not demonstrate an actionable forecast.
=== fx-currencies__02of02
Saved [records.jsonl](/tmp/claude-1000/-home-sean-git-binary-algo/ff7f09cd-9df3-4f26-8b91-76d69bf436c4/scratchpad/lit/work/fx-currencies__02of02/records.jsonl): **50 validated records**, with 89 findings and 70 levers.

Read depth: 24 full, 26 triage. Relevance counts: **3: 13 · 2: 11 · 1: 25 · 0: 1**. Unreadable documents: **none**.

The ten most promising levers are below. Evidence ratings describe source support; transfer to Deriv remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Sparse release-type and post-release decay features | `7379c7b9008c` | magnitude | Moderate | Existing calendar/ticks |
| Seasonally normalize volatility before modeling persistence | `9c0c418c36c3` | magnitude | Moderate | Dukascopy |
| Add lagged spread profiles | `c536132f174a` | magnitude | Moderate | Dukascopy |
| Separate jumps from continuous variance | `cb0f76a8941c` | magnitude | Moderate | Dukascopy |
| Test pair-specific pre/post-fixing direction | `807fdb20dac0` | direction | Moderate | Dukascopy |
| Model fixing-window magnitude effects | `bea2bee19643` | magnitude | Moderate | Dukascopy |
| Condition gates on spreads, jumps and quote freshness | `f1e8c9abcdfd` | selection-gating | Moderate | Dukascopy |
| Distinguish round-number approach from crossing | `e31f624ebf90` | direction | Weak | Dukascopy |
| Preserve untouched later-era strategy replications | `ac2279981a13` | validation | Strong | On-disk |
| Enforce benchmark window-completion and publication timestamps | `f505a1a7ccfb` | validation | Strong | On-disk |

No convincing direct contradiction of the in-house priors emerged. Qualified exceptions are hour-scale fixing reversals and historical daily Markov-rule profits; neither establishes a current minute-scale Deriv edge. Multifractal findings primarily concern magnitude, while claimed neural and sentiment successes have substantial task or validation limitations.

Checks passed for record count, shard order, IDs, titles, required fields, quote lengths and exact page-quote matches.
=== kelly-bet-sizing__01of03
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/kelly-bet-sizing__01of03/records.jsonl): **41 ordered records**, with JSON and all 75 page-cited quotations verified.

Relevance: **3: 3 documents; 2: 19; 1: 16; 0: 3.** Read 22 fully and triaged 19. None unreadable. No evaluation earned grade A or B.

The ten most promising candidates to test:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shrink estimated win probabilities before sizing | `5d17d0ad8db7` | calibration | moderate | deriv-ticks |
| Gate trades on conservative probability quantiles | `1f3ba3bf1107` | selection-gating | moderate | deriv-ticks |
| Allocate robustly under probability uncertainty | `027ac061b870` | sizing | moderate | deriv-ticks |
| Cap concurrent bets and shared-currency exposure | `2c8401bbed44` | sizing | moderate | deriv-ticks |
| Correct selected-edge bias using chronological calibration | `2c8401bbed44` | validation | moderate | deriv-ticks |
| Optimize exact binary expected log wealth | `35a5f91938a2` | sizing | moderate | deriv-ticks |
| Test profitability against payout-implied break-even, charging ties | `06e64a40bf28` | validation | moderate | deriv-ticks |
| Assess features through held-out sign-label log loss | `53a2c942adb7` | features | moderate | deriv-ticks |
| Check calibration within coarse observable regimes | `0bfd75cf0187` | calibration | weak | deriv-ticks |
| Combine causal strategies through wealth weighting | `038313c5ad62` | ensemble | weak | deriv-ticks |

These are transferable ideas, not established FX edges. No credible result contradicts the in-house prediction priors. Apparent Kalman direction results assume predictable latent drift; binary-options performance includes hindsight-adjusted probabilities. Mathematical and accounting concerns are flagged in the affected records.
=== kelly-bet-sizing__02of03
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/kelly-bet-sizing__02of03/records.jsonl): **41 records in shard order**, validated JSON, with all quotations matched to cited pages.

Read 40 documents: relevance **3: 3**, **2: 17**, **1: 18**, **0: 2**. One additional record is unreadable.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Conservative probability-interval gate | `7b2c5df6d052` | selection-gating | moderate | deriv-ticks |
| Exact entry-tick and latency replay | `76a944ccf977` | validation | moderate | deriv-ticks |
| Conditional uncertainty for magnitude | `87e0b3ee7f27` | magnitude | moderate | deriv-ticks |
| Combine forecast variance and model disagreement | `87e0b3ee7f27` | selection-gating | moderate | deriv-ticks |
| Pool and smooth sparse probability estimates | `964fb1fea84e` | calibration | moderate | deriv-ticks |
| Limit conditional-history complexity | `964fb1fea84e` | features | moderate | deriv-ticks |
| Compare risk-constrained and fractional Kelly | `9ae925b33f6f` | sizing | moderate | deriv-ticks |
| Allocate concurrent bets jointly | `a9ec5fa7d606` | sizing | weak | deriv-ticks |
| Test a small lagged-sign baseline | `6a826bcee45f` | direction | weak | deriv-ticks |
| Test causal cross-pair information | `7e4838bebb15` | features | weak | deriv-ticks |

These are proposed adaptations; the Eurodollar evidence used external order-book data.

Unreadable: `b6a3126988c0`, **Risk Management Example: Position Sizing a Bullish Triangle Breakout**—empty text path.

No convincing contradiction of the in-house priors emerged. Information-theoretic results do not establish FX sign prediction. The Eurodollar paper supports uncertainty-aware sizing, but its model advantage depends on horizon and costs, and it provides no tree comparison. Most remaining results assume an edge rather than demonstrate one.
=== kelly-bet-sizing__03of03
Created [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/kelly-bet-sizing__03of03/records.jsonl): **40 records**, validated for JSON, shard order, and all 79 page-cited quotations.

Relevance counts: **3: 2 · 2: 22 · 1: 15 · 0: 1**. Read 39 documents, including 24 fully. Unreadable: **b93fe64b3603 — Lots per Account Size**, whose shard entry supplies no text path.

The ten most promising levers all use existing **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Payout-aware strict-win participation gate | d422b9380569 | selection-gating | Strong* |
| Sequential likelihood-weighted forecast ensemble | f3412d532509 | ensemble | Strong* |
| Posterior-predictive probability shrinkage | fd939dbbc833 | calibration | Moderate |
| Balance estimation-window size against drift | e166b508c6b7 | validation | Moderate |
| Conservative fractional Kelly sizing | ba954c0dcbcb | sizing | Moderate |
| Joint sizing of simultaneous contracts | 921d05665a06 | sizing | Moderate |
| Account for serial covariance in bankroll risk | d7a09ba4cd62 | sizing | Moderate |
| Temper ensemble updates to preserve diversity | f1ee12d9bb87 | ensemble | Weak |
| Range-based volatility features for magnitude gating | d6fd1cce0928 | magnitude | Weak |
| Test incremental causal information across pairs | e2996bb83d04 | features | Weak |

*Strong refers to mathematical guarantees under stated assumptions, not demonstrated FX profitability.*

No credible result contradicts the supplied FX forecasting priors; this shard does not test those AUC or direction claims. Entropy identities assume an informative channel and supply no price-sign evidence. Several simulations mishandle negative wealth, and the compression paper’s general portfolio KL identity has a substantive derivation flaw.
=== macro-nowcasting__01of05
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/macro-nowcasting__01of05/records.jsonl): **46 records**, correct shard order, valid JSON, and 121 page-checked quotations.

| Relevance | Documents |
|---|---:|
| 3 — direct | 4 |
| 2 — transferable | 27 |
| 1 — tangential | 13 |
| 0 — irrelevant | 2 |

The 10 most promising levers are below. Evidence describes the source findings or validation principle; none demonstrates Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shared time folds across pairs, with overlapping labels purged | `1012a966085e` | validation | strong | Deriv ticks |
| Train scale models on cross-fitted residuals | `1771a6d90d0e` | calibration | moderate | Deriv ticks |
| Separate persistent volatility from transitory shocks | `1299392341c7` | magnitude | moderate | Deriv ticks |
| Compare pooled, pair-specific and partially pooled models | `1012a966085e` | ensemble | moderate | Deriv ticks |
| Compress lag histories with polynomial bases and sparse penalties | `01c4c4b6f23d` | features | moderate | Deriv ticks |
| Benchmark PCA features with kernel ridge regression | `2b1d17133ea3` | features | moderate | Deriv ticks |
| Weight training observations by current-state similarity | `1cfd86b31814` | regime | moderate | Deriv ticks |
| Shrink quantile-specific ensemble weights toward equal weights | `106663b16275` | ensemble | moderate | Deriv ticks |
| Derive contract probabilities from a coherent return CDF | `250e6329a1e0` | calibration | moderate | Deriv ticks |
| Screen feature families conditional on the existing baseline | `2ca2b99ba7ef` | features | moderate | Deriv ticks |

No document was wholly unreadable. Extraction gaps in equations or figures are noted in individual records.

Nothing directly tests the reported in-house FX edges. Some macro studies favor neural networks, qualifying broad claims of tree superiority. Pooling, optimized combinations and stochastic volatility sometimes worsen forecasts. Apparent gains also frequently depend on crisis exclusions, revised data, small effective samples or reused evaluation periods.
=== macro-nowcasting__02of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/macro-nowcasting__02of05/records.jsonl): **46 records**, verified in shard order, with **147 exact page-cited quotations**.

Relevance counts: **3: 2 · 2: 29 · 1: 14 · 0: 1**.

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit feature availability at executable entry | `771272cece2e` | validation | strong | deriv-ticks |
| Search-aware model and horizon comparisons | `7af31c6a0067` | validation | strong | deriv-ticks |
| Target-specific screening before factor extraction | `78bc3ba25d2d` | features | moderate | deriv-ticks |
| Shrink feature groups and coefficients within groups | `77b765b3198f` | features | moderate | deriv-ticks |
| Conditional distributions of cross-fitted residuals | `44207e1d1574` | calibration | moderate | deriv-ticks |
| Regularized magnitude quantile forecasts | `424a5926d1be` | magnitude | moderate | deriv-ticks |
| Adapt residual scale separately from directional mean | `424a5926d1be` | calibration | moderate | deriv-ticks |
| Discounted predictive-score ensemble weights | `798c66359ca0` | ensemble | moderate | deriv-ticks |
| Pool pairs through a small shared representation | `3e364016c787` | ensemble | weak | deriv-ticks |
| Low-order causal path-signature features | `6d1aa0365e8e` | features | weak | deriv-ticks |

No document was wholly unreadable. **30 received full reads; 15 were triaged;** the long survey `477c4718a756` received a partial read. Extraction limitations are recorded individually.

No direct contradiction of the FX direction/magnitude priors emerged. Qualifications: averaging correlated forecasts sometimes adds nothing; single-model selection can outperform averaging; adaptive bias corrections can fail after regime changes. The tree-versus-deep-net comparison supports the in-house prior, but none establishes a tradable Deriv edge.
=== macro-nowcasting__03of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/macro-nowcasting__03of05/records.jsonl): **46 valid records in shard order**, with 108 verified verbatim findings.

Relevance counts: **0: 0 · 1: 9 · 2: 31 · 3: 6**. Coverage: **11 full reads, 26 partial reads, 9 triages**. No unreadable files. The full-reading requirement remains incomplete for the 26 partial records; each identifies its omissions.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Empirical residual-quantile calibration | 9622b191f09b | calibration | moderate | deriv-ticks |
| Monotone magnitude-threshold probabilities | 8c6808dc7e92 | calibration | moderate | deriv-ticks |
| Horizon-specific density stacking | 7f2377c842ac | ensemble | moderate | deriv-ticks |
| Shrink dynamic states toward static models | 80c167324105 | regime | moderate | deriv-ticks |
| Training-only screening followed by PCA | 9eb8d7da866e | features | moderate | deriv-ticks |
| Forests with structured linear predictions | 9eb8d7da866e | ensemble | moderate | deriv-ticks |
| Dependence-aware small-sample comparisons | 949d32f27867 | validation | moderate | deriv-ticks |
| Block-bootstrap model confidence sets | 97cc9bd7da8a | validation | moderate | deriv-ticks |
| Audit pretrained-model future exposure | a4077f36df81 | validation | strong | deriv-ticks |
| Speech/testimony event-risk gates | 8f3db06aba01 | selection-gating | moderate | external: event calendar |

Evidence grades reflect source support, not demonstrated Deriv profitability.

No credible result directly contradicts the in-house FX direction/magnitude priors. The world-trade study qualifies a blanket preference for standard trees: structured regression-based forests performed better on its monthly target. Several impressive “direction” or “accuracy” claims instead concern policy decisions, employment changes, or interval coverage.
=== macro-nowcasting__04of05
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/macro-nowcasting__04of05/records.jsonl): **46 records**, in shard order.

- Relevance **3: 5**, **2: 29**, **1: 12**, **0: 0**.
- Read 34 fully and triaged 12. None unreadable.
- JSON/schema checks passed; all 87 finding quotes match their cited pages.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Match information cutoffs and settlement labels across models | `b45a104361e5` | validation | strong | deriv-ticks |
| Require apparent effects to survive forward-period forecasts | `cb89ee1e2971` | validation | strong | deriv-ticks |
| Compress long lag vectors into regularized smooth bases | `b73359c95cb1` | features | moderate | deriv-ticks |
| Adapt volatility while constraining mean-model complexity | `b21a8a059350` | magnitude | moderate | deriv-ticks |
| Forecast magnitude quantiles directly | `bde1242232c6` | magnitude | moderate | deriv-ticks |
| Pool within model families before pooling across families | `c1b2b579837c` | ensemble | moderate | deriv-ticks |
| Compare arithmetic and geometric density pools | `d4c3b49aad6d` | calibration | moderate | deriv-ticks |
| Check conditional calibration and serially dependent errors | `ade2e931395f` | calibration | moderate | deriv-ticks |
| Combine common cross-pair factors with sparse residual features | `c6bd486e1250` | features | weak | deriv-ticks |
| Separate persistent volatility from transient outlier scales | `d2c293fa6d74` | magnitude | moderate | deriv-ticks |

Evidence grades describe the source evidence; transfer to FX remains unproven.

No convincing contradiction of the in-house priors emerged. Some macro studies favor neural models, but none establishes a settlement-aware Deriv direction edge. Volatility-in-mean results concern macroeconomic outcomes and provide no demonstrated FX-sign counterexample. Several headline gains depend on test-period selection, revised data or incomplete uncertainty treatment; these caveats are recorded.
=== macro-nowcasting__05of05
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/macro-nowcasting__05of05/records.jsonl): **43 records**, matching shard order, with 63 page-checked quotations and 66 levers.

Relevance counts: **3: 7 · 2: 14 · 1: 22 · 0: 0**. Reading depth: 19 full, 2 partial, 22 triaged. None unreadable.

The ten most promising levers:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Dependence-aware forecast comparisons | e31f71872188 | validation | strong | deriv-ticks |
| Correct for model and threshold searches | e31f71872188 | validation | strong | deriv-ticks |
| Calibrate from held-out residuals | eb858eb2c1cc | calibration | moderate | deriv-ticks |
| Strongly regularize ensemble weights | ea6bfe9f4fa2 | ensemble | moderate | deriv-ticks |
| Common FX factors plus pair residuals | 30c8e5003ad8 | features | moderate | deriv-ticks |
| Dense ridge versus PCA and sparse selection | f3cb683defe6 | features | moderate | deriv-ticks |
| Separate outliers from persistent volatility | fdc3998cf1c9 | magnitude | moderate | deriv-ticks |
| Ablate mean, scale and shape separately | e4b084476fb9 | validation | moderate | deriv-ticks |
| Reconcile adjacent return forecasts across horizons | 5b6fcb167b11 | ensemble | moderate | deriv-ticks |
| Ensemble several training-window lengths | e31f71872188 | ensemble | moderate | deriv-ticks |

Evidence grades describe source support; none establishes a profitable Deriv FX strategy.

No direct refutation of the in-house FX priors emerged. Macro tail-risk results warn against assuming magnitude predictability transfers automatically. Neural networks beat trees on some macro targets, while apparent foundation-model advantages have leakage or comparison problems.

Partial reads covered relevant sections of **e4b084476fb9** and **30c8e5003ad8**; their limits are recorded explicitly.
=== market-commentary__01of01
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-commentary__01of01/records.jsonl): **52 ordered records**, with JSON, IDs, schema, verbatim quotes and numerical citations verified.

Relevance counts: **3: 8 · 2: 24 · 1: 16 · 0: 4**. Evaluation grades: **5 C, 27 D**; no A/B evidence.

Ten promising tests below. “Ticks” means existing Deriv data; evidence concerns shard support, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Exact entry, expiry and tie labels | `6f8c4057e20f` | labels | Weak | Ticks |
| Calibrated payout-aware selection | `ae2667486e1d` | selection-gating | Weak | Ticks |
| Coherent magnitude threshold probabilities | `5ef43b2c81ae` | calibration | Weak | Ticks |
| Simple volatility persistence baseline | `c4734068a3be` | magnitude | Weak | Ticks |
| Pooled cross-pair residual uncertainty | `c4734068a3be` | regime | Weak | Ticks |
| Yen/franc cross-pair stress features | `fef57fd5a9d7` | features | Weak | Ticks |
| Quiet-period-to-volatility-burst interactions | `fef57fd5a9d7` | magnitude | Weak | Ticks |
| Whole-event holdouts for stress gates | `fef57fd5a9d7` | validation | Moderate | Ticks |
| Policy surprises relative to expectations | `14aa7d06d808` | features | Weak | External: releases and expectations |
| Lagged oil returns for USDCAD | `14aa7d06d808` | features | Weak | External: synchronized oil prices |

**Unreadable files:** none. Four chart roundups lack their charts; paywall and pagination limitations are recorded individually. Duplicates are flagged.

**Contradictions with in-house priors:** none credible. AQR supports uncertainty/volatility persistence, while BIS documents carry-unwind mechanisms; neither demonstrates prospective FX sign accuracy or overturns the trees-versus-deep-nets prior.
=== market-making__01of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__01of07/records.jsonl).

All **49 documents** recorded in shard order: relevance **3: 8**, **2: 10**, **1: 29**, **0: 2**. Full reads: **18**; triaged: **31**. None unreadable. Validation passed for JSON, IDs, schema and **79 exact page-cited quotes**.

The ten most promising levers all use `deriv-ticks`:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Calibration near the trading threshold | `0c3c24baff44` | calibration | moderate |
| Exact next-tick entry and expiry labels | `25e5a53b6576` | labels | moderate |
| Explicit Rise/Fall/tie probabilities | `1f3dc69fcd62` | labels | moderate |
| Expert rankings using only settled outcomes | `0c3c24baff44` | validation | moderate |
| Frozen-model execution-delay stress tests | `25e5a53b6576` | validation | moderate |
| Direction-relative pooling of examples | `0d6325583813` | labels | weak |
| Shock-after-oscillation reversal features | `0d6325583813` | features | weak |
| Coherent joint direction/magnitude distribution | `278236c46337` | labels | weak |
| Audit calibration after magnitude-weighted training | `0de14c3461aa` | calibration | weak |
| Small, regularized rolling expert ensemble | `059b57b64543` | ensemble | weak |

No document provides strong validation of a tradable Deriv FX edge. External crypto order-book evidence qualifies the blanket “order flow predicts only size” prior, but concerns seconds-scale effects. The shard also warns that spread-capture profits and inventory mean reversion should not be interpreted as predictable midprice direction.
=== market-making__02of07
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__02of07/records.jsonl): **49 records**, verified in shard order. All 66 finding quotes match their cited pages.

Relevance counts: **3: 7 · 2: 12 · 1: 29 · 0: 1**. Depth: 18 full, 1 partial, 30 triage.

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Adapt a small head using matured labels | `37da01bcb19f` | calibration | weak | deriv-ticks |
| Shrink and cap online updates | `37da01bcb19f` | loss | weak | deriv-ticks |
| Pool comparable calibration groups | `3e442cf544c6` | calibration | weak | deriv-ticks |
| Enforce joint up/down/tie and magnitude coherence | `3cf3865b4efc` | calibration | weak | deriv-ticks |
| Regularize online forecaster weights | `3cf3865b4efc` | ensemble | weak | deriv-ticks |
| Test a moving-equilibrium baseline | `475886cc78ba` | regime | weak | deriv-ticks |
| Benchmark heavy-tailed threshold probabilities | `4d6af70a024a` | calibration | weak | deriv-ticks |
| Stress delayed and adverse entry prices | `335c6c4b4a23` | validation | moderate | deriv-ticks |
| Retain regime breaks in held-out tests | `37da01bcb19f` | validation | strong | deriv-ticks |
| Separate participant-initiated flow from liquidity provision | `4e5a48a6d2f1` | direction | moderate | external: identified trades, quotes, inventory |

No files were missing or wholly unreadable. Thesis `3aba8e44068c` covers relevant chapters only; damaged extraction is noted there and in `438ccee5a9aa` and `4c7385ddae21`.

**No robust contradiction to the in-house priors emerged.** OU direction is assumed, Kalshi win rates are incomparable, and specialist-flow evidence uses external data with in-sample return regressions.
=== market-making__03of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__03of07/records.jsonl): **49 records**, in shard order. JSON, schemas, page references, and all 56 verbatim quotes validated.

Relevance: **3: 5 · 2: 9 · 1: 33 · 0: 2**. Fourteen full/relevant-chapter reads; 35 triaged. No unreadable documents.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Constrained return-memory filters | `6df5f5179022` | magnitude | Weak | deriv-ticks |
| Coherent Rise/Fall/tie/magnitude probabilities | `58170e2db5ea` | calibration | Weak | deriv-ticks |
| Regularized cross-pair VAR | `585548e39c37` | direction | Weak | deriv-ticks |
| USD-oriented cross-pair concordance | `6bdcb7cc003a` | features | Weak | deriv-ticks |
| Smoothed return-distribution forecasts | `69d68d83fe01` | calibration | Weak | deriv-ticks |
| Causal aggregation and denoising | `74483cba980d` | features | Weak | deriv-ticks |
| Smooth or hysteretic reliability gates | `6e9db4b8791d` | selection-gating | Weak | deriv-ticks |
| Actual-payoff-aware model selection | `585548e39c37` | loss | Moderate | deriv-ticks |
| Calendar-period uncertainty beyond seed variation | `75aa5024e05b` | validation | Moderate | deriv-ticks |
| Leading-venue price discrepancies | `585548e39c37` | data | Moderate in crypto; FX unproven | external: synchronized FX venue prices |

**No robust contradiction of the in-house priors.** The directional candidates remain theoretical or venue-specific. Hawkes results concern order events, and market-making profits often arise without price-direction skill. The deep-model papers provide no controlled evidence against the tuned-tree prior.
=== market-making__04of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__04of07/records.jsonl): **49 records**, in shard order. JSON, schema, quote lengths, and exact page quotations all passed validation.

Relevance counts: **3: 5 · 2: 13 · 1: 29 · 0: 2**. All 18 relevance 2–3 documents were read fully.

Ten promising transfer ideas—all use **deriv-ticks**; none establishes a tradable FX edge:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Signed continuation/reversal hazards with elapsed time | `8fe9db0b207f` | direction | weak |
| Separate diffusion and jump variance | `96fcab04d395` | magnitude | weak |
| Cross-pair simultaneous-jump features | `96fcab04d395` | magnitude | weak |
| Strictly causal filtering with raw settlement labels | `96fcab04d395` | features | weak |
| Smoothed conditional return distributions | `8fb71e5ae1b2` | calibration | weak |
| Session/weekend-conditioned risk gates | `8a8896be3930` | regime | weak |
| Conservative uncertainty bounds on expected payoff | `97cf8a3e47f9` | selection-gating | weak |
| Rolling past-only estimation and forward evaluation | `9042b9d9181f` | validation | moderate |
| Dependence-aware SPA/reality checks across variants | `898b247ffe2d` | validation | moderate |
| Covariance-aware limits across overlapping contracts | `981b551a3f5d` | sizing | weak |

**Unreadable:** `8fc035d7fbd4`, the Japanese intermittent-updating market-maker paper. Its English abstract was readable; corrupted body text prevented reliable extraction.

**Contradictions:** No reliable contradiction of the in-house FX priors. Counterevidence includes a simple return forecast reducing average strategy performance, a Hawkes classifier trailing its majority baseline, and profitable market making coexisting with negative directional positioning returns. These limitations and the variance paper’s conflicting metric claims are recorded explicitly.
=== market-making__05of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__05of07/records.jsonl): **49 records**, in shard order. JSON, schema, quotations and numeric citations validated.

Relevance: **3: 9 · 2: 13 · 1: 27 · 0: 0**. Read depth: 21 full, one selective thesis reading, 27 triaged. Unreadable: **none**.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Calendar splits with overlap embargoes | b0d15558bcaf | validation | strong | deriv-ticks |
| Exact entry, expiry and tie-loss replay | 9e46cd039e06 | validation | moderate | deriv-ticks |
| Retain stress days; require causal exclusion gates | ab0503cf451b | validation | strong | deriv-ticks |
| Small HMM with causal filtering | 9f2b62489997 | magnitude | moderate | deriv-ticks |
| Calibrate against settled outcomes | 9c693bd99fe2 | calibration | moderate | deriv-ticks |
| Regularized heavy-tail return distributions | b0d15558bcaf | magnitude | moderate | deriv-ticks |
| Coherent direction, tie and magnitude probabilities | b3b25782832b | calibration | moderate | deriv-ticks |
| Currency factors plus pair-specific residuals | bfd49cbc86fd | features | weak | deriv-ticks |
| Test seed averaging against voting and individual models | becd70dcc936 | ensemble | weak | deriv-ticks |
| Measure decay across entry delays and expiry horizons | c12466a86da5 | validation | strong | deriv-ticks |

Evidence ratings concern the stated mechanism or validation lesson, **not proven Deriv profitability**.

The main qualification to the in-house priors is that seed voting harmed a policy in one simulator. Signed order-flow alpha is also claimed, but its evidence relies on single-session estimation and simulations with extremely fast decay; it does not establish an edge at our contract horizons. The HMM paper supports magnitude rather than sign prediction. No document directly validates or refutes the reported in-house FX scores or boosted-tree advantage.
=== market-making__06of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__06of07/records.jsonl): **49 records**, in shard order. All JSON, IDs, and 75 page-cited quotations validated.

Relevance counts: **3: 10 · 2: 11 · 1: 27 · 0: 1**. Reading depth: 19 full, 2 partial, 28 triage. No document earned evaluation grade A or B.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Exact entry, expiry and tie-aware replay | c2ba70560c71 | validation | Moderate | deriv-ticks |
| Outcome-based probability calibration | d256dfb5e83a | calibration | Moderate | deriv-ticks |
| Joint Rise/Fall/Tie probabilities | de14d8949353 | labels | Moderate | deriv-ticks |
| Separate continuous variance from jumps | caced21e9971 | magnitude | Weak | deriv-ticks |
| Seasonality-adjusted multiscale activity memory | dfbf44fd7697 | magnitude | Weak | deriv-ticks |
| Soft regime probabilities and uncertainty gates | ccec6ba1859b | selection-gating | Weak | deriv-ticks |
| Adaptive calibrator uncertainty resets | cc1d9f2374fb | calibration | Weak | deriv-ticks |
| Regularized online ensemble weights | d1f3e129bc82 | ensemble | Weak | deriv-ticks |
| Compact signed-change and waiting-time history | d8d3d85d4f25 | features | Weak | deriv-ticks |
| Distinguish trade-driven from cancellation-driven depletion | d8d3d85d4f25 | direction | Moderate, very short horizon | external: signed trades and book events |

No files were missing or wholly unreadable. Extraction damage limited portions of **ccec6ba1859b** and **d131dc414268**; both records identify affected pages.

Nothing establishes a tradable Deriv direction edge or overturns the trees-versus-deep-net prior. One narrow qualification: specific signed order-book events show directional associations at much shorter horizons using external data. Unsigned activity persistence supports magnitude research, not sign claims. Several headline results weaken substantially after checking simulator assumptions, future-informed regime labels, or fee income versus net losses.
=== market-making__07of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-making__07of07/records.jsonl): **46 records**, in shard order. JSON, schema and exact page quotes validated.

Relevance counts: **3: 5 · 2: 11 · 1: 30 · 0: 0**. Reading depth: 14 full, 2 selective long-document reads, 30 triages. None unreadable.

Ten promising levers follow. Evidence describes source support; Deriv adaptations remain unvalidated.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Settlement-aligned model comparisons | `f2087a951380` | validation | Moderate | Deriv ticks |
| Freeze causal filter snapshots | `ea9f200cab23` | validation | Weak | Deriv ticks |
| Time-of-day plus recent-window magnitude forecasts | `ebaca5bf8095` | magnitude | Moderate | Deriv ticks |
| Coarse feature bins and symmetric pooling | `ebaca5bf8095` | features | Weak | Deriv ticks |
| Decayed price-activity and large-move counts | `e602e1c3ee50` | magnitude | Weak | Deriv ticks |
| Signed shock-and-decay features | `e290200c11bf` | features | Weak | Deriv ticks |
| Capped exponential model weights using matured labels | `ea443f293afc` | ensemble | Weak | Deriv ticks |
| Tune uncertainty penalties separately from trade thresholds | `f7739aa0f532` | selection-gating | Moderate | Deriv ticks |
| Dependence-aware intervals and detectable-effect reporting | `feec76b5eb4c` | validation | Moderate | Deriv ticks |
| Best-level book imbalance | `ebaca5bf8095` | direction | Moderate | External: synchronized depth and signed orders |

A narrow contradiction to the blanket “order flow predicts only size” prior appears: signed book imbalance predicts immediate equity price direction. That evidence uses external data at millisecond horizons and does not establish a tradable Deriv-horizon edge.

Kalman direction claims rely on imposed mean reversion; entropy theory supplies no empirical sign predictor. Nothing here validates the in-house AUC figures or overturns the trees-versus-deep-nets prior. No document earned evaluation grade A.
=== market-microstructure__01of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__01of19/records.jsonl): **49 records in shard order**, validated JSON, 114 exact page-quoted findings and 71 levers.

Relevance counts: **3: 11 · 2: 14 · 1: 23 · 0: 1**.

Ten most promising levers; evidence grades concern the cited mechanism, with transfer limitations recorded:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Exact causal joins and settlement labels | `08ea62da81d8` | labels | strong | Deriv ticks |
| Round-level distance, approach and touch history | `0132a12fe111` | features | moderate | Deriv ticks |
| Conditional calibration by pair, horizon and session | `060810f54243` | calibration | moderate | Deriv ticks |
| Calibrated payoff gate charging ties | `060810f54243` | selection-gating | moderate | Deriv ticks |
| Adaptive trailing normalization | `0a18323597a7` | regime | moderate | Deriv ticks |
| Regularized categorical lag model | `0068de297556` | direction | weak | Deriv ticks |
| Price-change intensity and waiting times | `001ef582b5cb` | magnitude | weak | Deriv ticks |
| Conditional threshold first-passage distributions | `00da12bed842` | magnitude | weak | Deriv ticks |
| Detrended cross-pair deviations controlling own momentum | `0cb3fef78282` | features | weak | Deriv ticks |
| Common time-block uncertainty across pairs | `0a66122ecb9d` | validation | moderate | Deriv ticks |

None was wholly unreadable. `036d36bc255a` is **partial** because pages 11–13 are largely missing from its text extraction.

No robust result contradicts the in-house priors at Deriv’s tradeable horizons. Signed queue/flow models and subsecond cross-price reversals provide direction channels, but do not establish an available Deriv edge. Hurst-based “inefficiency” claims lack directional trading validation.
=== market-microstructure__02of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__02of19/records.jsonl). Verified **49 valid records in shard order**, including 112 page-quoted findings and 78 levers.

Relevance counts: **3: 13 · 2: 13 · 1: 23 · 0: 0**. Read 26 fully and triaged 23. None unreadable; extraction gaps are noted.

The ten most promising levers for our setup:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Require complexity features to beat volatility/activity baselines | `1407e8ae8002` | validation | strong | deriv-ticks |
| Test lead/lag against timestamp-matched nulls | `12df47d24d98` | validation | moderate | deriv-ticks |
| Lagged cross-pair returns and common-dollar features | `12df47d24d98` | direction | weak | deriv-ticks |
| Signed-return × normalized-magnitude interactions | `10fb010b6a53` | direction | weak | deriv-ticks |
| Causal change-point probabilities for gating | `0e676efa0f8a` | regime | weak | deriv-ticks |
| Separate seasonal activity from excess clustering | `1006c65e7654` | features | moderate | deriv-ticks |
| Up/down price-change excitation | `1006c65e7654` | magnitude | weak | deriv-ticks |
| Diversify ensemble feature families and model classes | `0eeeb63ceb39` | ensemble | weak | deriv-ticks |
| Joint Brier and reliability checks by regime | `0ea40762ac2e` | calibration | weak | deriv-ticks |
| Exact settlement labels and entry-delay sensitivity | `1465ef5b835d` | labels | moderate | deriv-ticks |

Signed external-flow findings qualify the blanket size-only prior; they do not establish sign prediction from entropy or Hurst statistics. The strongest price-only directional evidence concerns much shorter event horizons. **Nothing here validates the reported in-house edge on Deriv.**
=== market-microstructure__03of19
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__03of19/records.jsonl): **49 records**, matching shard order, with **120 exact page-cited quotations**.

Relevance counts: **3: 13 · 2: 17 · 1: 19 · 0: 0**. Reading depth: 28 full, 2 partial, 19 triage.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Noise-aware volatility estimation | `1dd32634cd1e` | magnitude | moderate | deriv-ticks |
| Sparse cross-pair lagged returns | `262339e7dacb` | direction | weak | deriv-ticks |
| Explicit down/tie/up probabilities | `284510b5e963` | labels | weak | deriv-ticks |
| Expected volatility versus surprise | `1e9ab9bb307c` | regime | moderate | deriv-ticks |
| Price-change activity and waiting times | `1be2cca1f879` | magnitude | moderate | deriv-ticks |
| Training-only session profiles | `1cefa72d2ac3` | features | moderate | deriv-ticks |
| Common predictability regimes across pairs | `1bc182e4dd38` | regime | weak | deriv-ticks |
| Timestamp and latency stress tests | `1d6c2d95dabc` | validation | moderate | deriv-ticks |
| Dependence-aware uncertainty estimates | `238f2b1e04d5` | validation | moderate | deriv-ticks |
| Dealer gamma × prior-return interactions | `1aca4b3b9cc4` | direction | moderate | external: FX option positioning and Greeks |

Evidence describes the papers; transfer to our FX contracts remains unverified.

No document was wholly unreadable. **`261f9f5a45ee` and `28917aaa7994` are partial** because their supplied texts truncate portions of pages.

Several papers report conditional directional effects from order flow or queue state, qualifying the blanket “size, never sign” prior. These mostly require external data and concern shorter horizons. None establishes our required Deriv edge or provides a convincing contradiction to the stronger magnitude prior or the tree-versus-deep-net prior.
=== market-microstructure__04of19
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__04of19/records.jsonl): **49 records**, verified JSON, shard order, verbatim quotes and page citations.

Relevance: **3: 11 · 2: 11 · 1: 27 · 0: 0**. Full reads: 22; triage: 27. Unreadable documents: none. Extracted 72 levers.

Ten promising levers for the available data:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Separate zero-return probability from positive magnitude | `319e38a9fc53` | magnitude | Moderate | deriv-ticks |
| Calibrate thresholds with trailing residual quantiles | `319e38a9fc53` | calibration | Moderate | deriv-ticks |
| Model post-shock volatility decay | `33d1061c9ade` | magnitude | Moderate | deriv-ticks |
| Pool cross-pair lag features with shrinkage | `2f9f7c52ede8` | features | Weak | deriv-ticks |
| Combine fast and slow activity decay | `2fabf8864cbd` | magnitude | Weak | deriv-ticks |
| Use noise-robust volatility features | `319e38a9fc53` | features | Moderate | deriv-ticks |
| Fit rolling seasonal normalization on past data | `319e38a9fc53` | features | Moderate | deriv-ticks |
| Estimate cross-pair lags with sampling-artifact controls | `30ecb3a974a4` | features | Weak | deriv-ticks |
| Jointly tune lookback and refit frequency | `31ff7e81a131` | validation | Moderate | deriv-ticks |
| Apply dependence-aware SPA/reality checks | `2fc840dea997` | validation | Moderate | deriv-ticks |

These grades describe source support; none establishes a Deriv edge.

One qualification to the priors: `2b1bd427aff3` finds directional information in **external signed equity flow**, so “order flow predicts only size” is not universal. Conversely, prominent accuracy claims elsewhere concern trade side or spread-crossed returns, rather than our midpoint settlement target. This shard does not validate the reported in-house contract-horizon direction or magnitude performance.
=== market-microstructure__05of19
Wrote and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__05of19/records.jsonl): **49 records**, correct shard order, valid JSON, and verified quote/page matches.

Relevance: **3: 14 · 2: 12 · 1: 23 · 0: 0**. Reading depth: **18 full, 8 partial, 23 triage**. Partial coverage is identified in each record. No unreadable documents.

The ten most promising levers follow. Evidence strength concerns the underlying finding or validation lesson; FX adaptations remain unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Chronological purged splits; training-only scaling | `3b1a0b9d6d90` | validation | strong | deriv-ticks |
| Dependence-aware confidence intervals | `464e005df9ce` | validation | strong | deriv-ticks |
| Require incremental skill beyond realized volatility | `447ac8ef22c4` | validation | strong | deriv-ticks |
| Parsimonious multiscale lag averages | `3ae2f4ecd694` | features | moderate | deriv-ticks |
| Score-driven online volatility updates | `3ae2f4ecd694` | magnitude | moderate | deriv-ticks |
| Local-session features with correct DST | `403276b2ea82` | features | moderate | deriv-ticks |
| Multiscale cross-pair features with causal alignment | `472a5387a7b0` | features | moderate | deriv-ticks |
| Jump-size-dependent continuation versus reversal | `47871f5e3c1b` | direction | weak | deriv-ticks |
| Explicit zero-return probability for ties | `420a01579d9c` | calibration | weak | deriv-ticks |
| Visible book imbalance as a directional feature | `3d49eecd477e` | direction | weak | external: FX venue depth |

The shard qualifies the blanket “order flow predicts only size” prior: some papers show signed responses associated with observed flow or book imbalance. These results do **not** establish a price-only Deriv direction edge at permitted expiries.

Several impressive results concern contemporaneous explanation, reconstruction, or future-defined groups. The latent-regime paper also contains substantial evaluation inconsistencies. No reviewed evidence establishes a reliable Deriv binary edge or overturns the preference for simple, carefully validated baselines.
=== market-microstructure__06of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__06of19/records.jsonl): **49 validated records**, in shard order.

Relevance counts: **3: 13 · 2: 12 · 1: 24 · 0: 0**. All 25 relevant documents received full readings; 78 findings have verified page quotations.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale realized volatility | 4859707ba9ee | magnitude | moderate | deriv-ticks |
| DST-aware intraday seasonality | 4f3413fc284b | magnitude | moderate | deriv-ticks |
| Jump age and post-jump decay | 48c219189ba8 | magnitude | moderate | deriv-ticks |
| London-fix proximity and month-end | 4bb9b850bd5e | magnitude | moderate | deriv-ticks |
| Common versus pair-specific bursts | 499331474e56 | regime | moderate | deriv-ticks |
| Sampling-scale variance diagnostics | 4fc6db814232 | magnitude | moderate | deriv-ticks |
| Multiscale cross-pair lag features | 4fc6db814232 | features | moderate | deriv-ticks |
| Delayed-entry tick replay | 50d7e7336216 | validation | moderate | deriv-ticks |
| Require improvement over volatility/activity baselines | 4859707ba9ee | validation | strong | deriv-ticks |
| Announcement proximity and age | 4f3413fc284b | selection-gating | moderate | external: release calendar |

**Unreadable files:** none. Truncated source passages are flagged.

**Prior qualifications:** Signed external order flow shows in-sample lagged return information in `5010b4e24fb8`, qualifying the blanket “order flow predicts only size” claim. This establishes no Deriv price-only edge. VPIN redundancy and failed out-of-sample impact models reinforce caution; nothing here robustly validates the reported in-house directional edge.
=== market-microstructure__07of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__07of19/records.jsonl): **49 ordered records**, 52 page-cited findings, and 57 levers. JSON, IDs, and exact quotations verified.

Relevance: **3: 7 · 2: 11 · 1: 30 · 0: 1**. Depth: 14 full, 31 triage, 4 partial.

The ten most promising immediately testable levers all use **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Squared exponentially weighted trends | 6102ca614bc1 | magnitude | moderate |
| Cross-pair covariance surprises | 6102ca614bc1 | magnitude | weak |
| Shared currency-factor/residual model | 6102ca614bc1 | ensemble | weak |
| Signed-return effects on future magnitude | 6102ca614bc1 | magnitude | weak |
| Marked Hawkes extreme-move intensity | 5b7a88c21410 | magnitude | weak |
| Time-rescaled intensity residual checks | 5b7a88c21410 | validation | moderate |
| Disjoint-window lead/lag audits | 5c91bcef4e8b | validation | moderate |
| Time-block inference across pairs | 5c91bcef4e8b | validation | moderate |
| Price-change duration features | 5e2d0cd656f3 | features | weak |
| Post-jump volatility decay | 5a1ea3d75421 | magnitude | moderate |

None were unreadable. **Selective reads remain** for `5999c8972596`, `5c91bcef4e8b`, `5e765db1a10d`, and `5f8cd88f0301`; their records identify the sections read.

The blanket order-flow/sign prior needs qualification: the FX survey reports forecasting power from external customer flow, and equity studies find genuine return autocorrelation. Neither establishes a Deriv direction edge. The shard provides substantially stronger support for magnitude mechanisms than for attainable binary win rates.
=== market-microstructure__08of19
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__08of19/records.jsonl): **49 records**, in shard order.

Relevance counts: **3: 12 · 2: 12 · 1: 25 · 0: 0**. Depth: 23 full, 25 triage, one selective reading (`6a3d1462d726`). **No unreadable documents.** All quotes match their cited pages.

Ten promising test candidates; evidence grades describe source support, not established Deriv performance:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Squared trends alongside realized variance | `6e809e4dd379` | magnitude | Moderate | deriv-ticks |
| Noise-adjusted volatility | `61d598174df4` | magnitude | Weak | deriv-ticks |
| Rolling cross-pair lead–lag features | `683cada9f952` | features | Moderate | deriv-ticks |
| Separate UTC seasonality from activity bursts | `67cb5f2ef4e2` | magnitude | Moderate | deriv-ticks |
| Pooled multi-target Extra Trees | `6889ae74958f` | ensemble | Moderate | deriv-ticks |
| Shared latent volatility states | `6ed326b26d24` | magnitude | Weak | deriv-ticks |
| Time since last price change | `7015694e5b7c` | features | Weak | deriv-ticks |
| Robust heavy-tail likelihoods | `6a3d1462d726` | loss | Weak | deriv-ticks |
| Payout-aware probability gating | `6678bdc3003b` | selection-gating | Moderate | deriv-ticks |
| Option-gamma interactions with recent returns | `6b256ade06bd` | regime | Weak | external: FX option positioning and Greeks |

No convincing contradiction of the magnitude-versus-sign prior emerged. Tree ensembles receive support on a different, contemporaneous prediction task. Options positioning suggests conditional continuation/reversal mechanisms, but requires external data. **No study establishes an executable Deriv direction edge at the required payout hurdle.**
=== market-microstructure__09of19
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__09of19/records.jsonl): **49 records**, in shard order, with 96 findings and 76 levers. All quotations match their cited source pages.

Relevance counts: **3: 11 · 2: 8 · 1: 28 · 0: 2**. Reading depth: 18 full, 30 triage, one unreadable.

The ten most promising levers are below. Transfer to Deriv remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Prior-day, same-session-slot returns | `755b6eda9673` | direction | moderate | deriv-ticks |
| Session-normalized volatility shocks | `771b3e3c60c1` | magnitude | moderate | deriv-ticks |
| Separate signed and unsigned features | `78c418db5dd4` | features | moderate | deriv-ticks |
| Regularized multivariate autoregression | `78c418db5dd4` | ensemble | moderate | deriv-ticks |
| Filtered shared volatility regimes | `753f6e868780` | regime | weak | deriv-ticks |
| Lagged currency factors and pair residuals | `74ebf62a498d` | features | weak | deriv-ticks |
| Causal drift normalized by volatility | `7e69605c25f6` | features | weak | deriv-ticks |
| Partially pooled event-intensity kernels | `73bd0922b89c` | ensemble | weak | deriv-ticks |
| Directional randomization conditional on a fixed gate | `76cf270e5bde` | validation | moderate | deriv-ticks |
| Spread-conditioned queue imbalance | `7b6f6923cb5a` | direction | moderate | external: FX order book/events |

Unreadable: **`7561b4c9db7e` — Makers or Takers: The Economics of the Kalshi Prediction Market**. Its shard entry has no text path; relevance is provisional.

The blanket order-flow/sign prior needs qualification: queue imbalance predicts next-price-change direction, and *Microstructure Modes* reports modest held-out return prediction using order data. These require external data and different targets. Most other evidence supports stronger magnitude than sign predictability; none establishes the reported in-house Deriv-horizon direction edge.
=== market-microstructure__10of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__10of19/records.jsonl): **49 records**, verified in shard order, with 96 source-matched findings and 76 levers.

Relevance counts: **3: 14 · 2: 13 · 1: 21 · 0: 1**.

Ten most promising levers:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Joint sign–size interactions | `875ac0935405` | magnitude | moderate | deriv-ticks |
| Change counts and size moments | `875ac0935405` | features | moderate | deriv-ticks |
| Hawkes change intensity | `89937057f9f5` | magnitude | moderate | deriv-ticks |
| Sparse cross-pair return lags | `8a8559063f7b` | direction | moderate | deriv-ticks |
| Time-at-price first retests | `8546c0a9a950` | features | weak | deriv-ticks |
| Volatility-conditioned reversal | `88f670eafd30` | direction | weak | deriv-ticks |
| Causal filtering; reject smoother leakage | `8706bd32d6ca` | validation | strong | deriv-ticks |
| Joint-return block resampling | `875ac0935405` | validation | moderate | deriv-ticks |
| Matched event-placebo comparisons | `88986620a193` | validation | moderate | deriv-ticks |
| Lagged cross-pair order-flow imbalance | `8a8559063f7b` | data | moderate | external: FX book updates |

No document was wholly unreadable. Four records are partial: selective chapter reading for `8088d779d52e` and `820a1c7f42a5`; damaged text extraction for `87ee72383501` and `88f623b2e84b`.

Signed external order flow shows short-lived directional associations, qualifying the blanket “order flow predicts size only” prior. Hawkes intensity, entropy and Hurst evidence generally supports magnitude rather than sign. Nothing here establishes a validated Deriv direction edge at tradable expiries or directly challenges the trees-versus-deep-net prior.
=== market-microstructure__11of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__11of19/records.jsonl): **49 records**, in shard order. JSON/schema checks passed; all **112 quotations** match their cited source pages.

Relevance: **3: 15 · 2: 18 · 1: 16 · 0: 0**. Coverage: 30 full, 3 partial, 16 triage. None unreadable.

Most promising levers; evidence reflects source support, not proven Deriv profitability:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Price-threshold duration features | `9145364b110f` | magnitude | moderate | deriv-ticks |
| Training-only seasonal normalization | `8cdd1697c4e1` | magnitude | moderate | deriv-ticks |
| Squared trends and cross-pair products | `8d768b2cfd7e` | magnitude | weak | deriv-ticks |
| Shared cross-pair activity factors | `9145364b110f` | magnitude | weak | deriv-ticks |
| Causally filtered activity regimes | `92dbfde83ae5` | regime | weak | deriv-ticks |
| Lagged cross-pair response curves | `94aeede989cf` | features | moderate | deriv-ticks |
| Regularized cross-pair VAR baseline | `95425c765247` | direction | weak | deriv-ticks |
| Calendar-block uncertainty across seeds | `9699372903d0` | validation | moderate | deriv-ticks |
| Timestamp and time-shift audits | `8c1a401e79de` | validation | moderate | deriv-ticks |
| Small symmetric micro-price Markov model | `906b3d99cc38` | direction | moderate | external: bid/ask and queue sizes |

Partial coverage is explicitly recorded for `931163894920`, `947a21929639`, and `95425c765247`.

Nothing establishes a Deriv contract-horizon edge or overturns the magnitude-versus-sign prior. Signed queue imbalance and event-conditioned pressure provide limited directional counterexamples, chiefly using external data. One prior-day-tested Hawkes model loses to simple imbalance for next-price-move direction; synchronization evidence also cautions against expecting cross-market leads to persist to tradable horizons.
=== market-microstructure__12of19
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__12of19/records.jsonl): **49 ordered records, 138 verified page-cited findings, 79 levers**.

Relevance: **3: 15 · 2: 17 · 1: 17 · 0: 0**. Coverage: **23 full, 9 partial, 17 triage**. Partial records identify omitted sections.

Ten promising levers; Deriv transfer remains untested:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Robust pooled realized volatility | `97f91f6a9c4e` | regime | moderate | deriv-ticks |
| Local-clock, DST and month-end interactions | `9dcdb1fe5bb3` | magnitude | moderate | deriv-ticks |
| Seasonal multiscale activity model | `a4dd4a8e65c4` | magnitude | moderate | deriv-ticks |
| Explicit no-move probability | `9efbabe2e8f1` | calibration | weak | deriv-ticks |
| Student-t magnitude losses | `9f29f8854ce3` | loss | weak | deriv-ticks |
| Ridge shrinkage for correlated features | `a4da688fe33e` | loss | moderate | deriv-ticks |
| Simple logistic probability baseline | `a5051285adfe` | calibration | moderate | deriv-ticks |
| Block subsampling and self-normalized inference | `9a1958187db2` | validation | moderate | deriv-ticks |
| Dependence-preserving surrogate checks | `a18432ae0407` | validation | moderate | deriv-ticks |
| Cluster-specific order-flow imbalance | `986b4c766417` | direction | moderate | external: order events and sizes |

No document was entirely unreadable. `99ee6f9b4233` has corrupted results pages; its exact accuracy figures could not be extracted.

External queue/order-flow papers report directional information, qualifying the blanket “order flow predicts only size” prior. Their horizons, inputs and validation do **not** establish a tradable Deriv direction edge.
=== market-microstructure__13of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__13of19/records.jsonl): **49 records**, in shard order.

Relevance counts: **3: 8 · 2: 23 · 1: 17 · 0: 1**. Completed 31 full reviews and 18 triages; none unreadable. JSON, IDs, quotation lengths, and quote/page matching all pass validation.

The ten most promising levers are below. Evidence grades concern transferability; none establishes a Deriv forecasting edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Squared EW trend alongside realized variance | `ad9ac65189b2` | magnitude | moderate | deriv-ticks |
| Low-rank quadratic lag interactions | `ad9ac65189b2` | features | moderate | deriv-ticks |
| Multiscale volatility/activity relationships | `aca1e2763cc9` | magnitude | moderate | deriv-ticks |
| Explicit no-move probability and losing ties | `aa4122190d00` | labels | moderate | deriv-ticks |
| Noise-aware versus raw realized variance | `aa9689aa3f58` | magnitude | moderate | deriv-ticks |
| Intraday baseline before fitting self-excitation | `a76c3a6c23cc` | magnitude | moderate | deriv-ticks |
| Conditional price-change waiting times | `a917be1d027b` | magnitude | weak | deriv-ticks |
| Dependence-preserving nulls and block resampling | `a7974360e5b0` | validation | moderate | deriv-ticks |
| Multiple-testing correction for lead-lag searches | `aca1e2763cc9` | validation | moderate | deriv-ticks |
| Vega-weighted opening option demand | `ae73e9dc7ff6` | magnitude | moderate | external: signed FX option trades, opening flags, Greeks |

Two findings qualify the in-house priors. Identified gilt-investor flows predict signed returns (`a80438888c29`), but require external participant data and concern daily or longer horizons. Theoretical diffusive prices can retain return autocorrelation (`aeb0aa933f6d`), so diffusion alone does not establish unpredictability.

Most usable evidence supports magnitude modeling. Apparent tree-model superiority in the thesis is weakened by random splitting, contemporaneous targets, and clipped adverse returns; it does not substantiate the earlier direction edge.
=== market-microstructure__14of19
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__14of19/records.jsonl): **49 records**, in shard order, with valid JSON and verified source quotes/pages.

Relevance counts: **3: 8 · 2: 14 · 1: 25 · 0: 2**. Depth: 20 full, 2 partial, 27 triage. No unreadable documents.

Ten promising levers; evidence grades concern the recorded mechanism, not proven Deriv profitability:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Local-session FX baseline | `b6c146aa5f0c` | direction | moderate | deriv-ticks |
| Causal latent-state filtering | `b4990fd8e383` | validation | strong | deriv-ticks |
| Timestamp/stale-price audit | `afcb313ee005` | validation | moderate | deriv-ticks |
| Sparse cross-pair logistic model | `b96067498dbc` | direction | weak | deriv-ticks |
| Causal multiscale lag features | `b26676adc500` | features | weak | deriv-ticks |
| Multiplicative volatility baseline | `b7e909bac704` | magnitude | weak | deriv-ticks |
| Separate tie mass from positive magnitude | `b7e909bac704` | calibration | weak | deriv-ticks |
| Price-only transition entropy | `bdd3689374f2` | magnitude | weak | deriv-ticks |
| Matched-coverage gate evaluation | `b5c2b672b1aa` | validation | moderate | deriv-ticks |
| Scheduled-release magnitude gate | `bbd01e5c40eb` | magnitude | moderate | external: macro calendars |

The partial reads are `afcb313ee005` and `b2bf21720261`; their records specify coverage.

No robust contradiction of the in-house priors emerged. Historical FX session directionality merits testing. The entropy paper supports magnitude/sign separation, while the complex herding model’s reconstruction gains largely disappear in forward forecasting. Claims of a universal mathematical separation in `b385eda35903` have substantial flaws, documented in its record.
=== market-microstructure__15of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__15of19/records.jsonl): **49 records**, in shard order, with JSON, IDs and all 101 finding quotes verified.

Relevance: **3: 13 · 2: 10 · 1: 25 · 0: 1**. Depth: 22 full, 1 partial, 26 triaged.

Ten promising candidates:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Separate price-change frequency and size | cb449924ddc2 | magnitude | moderate | deriv-ticks |
| Compare noise-robust volatility estimators | c581218d418c | magnitude | moderate | deriv-ticks |
| Remove intraday volatility seasonality | beb0a0c85cf9 | magnitude | moderate | deriv-ticks |
| Test slow-decay activity kernels | c1814429d8b1 | magnitude | moderate | deriv-ticks |
| Pool soft activity regimes across pairs | c32d52aaecb4 | regime | weak | deriv-ticks |
| Model volatility-excursion duration | c053b0265874 | regime | weak | deriv-ticks |
| Replay filtered states causally | c6f37c050b02 | validation | moderate | deriv-ticks |
| Use dependent bootstrap and testing corrections | c2d90cc95d54 | validation | moderate | deriv-ticks |
| Stress leadership measures against noise and delay | cb47d780ad9e | validation | strong | deriv-ticks |
| Test weighted book-depth imbalance | c34c7a26bff5 | direction | weak | external: order-book depth |

No document was wholly unreadable. **c0831ebcbb44** is marked partial because figures contain corrupted text.

The main qualification to the priors is **c34c7a26bff5**: book imbalance shifts short-horizon sign frequencies in sample. It requires external depth data and does not establish a tradable FX edge. Nothing here validates a tick-only direction edge at Deriv contract horizons.
=== market-microstructure__16of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__16of19/records.jsonl).

All **49 documents** recorded: relevance **3: 7**, **2: 14**, **1: 26**, **0: 2**. No unreadable documents. Verified JSON, shard order, schema and page-cited numerical quotes.

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Threshold-crossing durations | d47a72c9536c | magnitude | moderate | deriv-ticks |
| Equal-weight duration forecasts | d47a72c9536c | ensemble | moderate | deriv-ticks |
| Causal adaptive activity baseline | d1c167d71def | magnitude | moderate | deriv-ticks |
| Round-number touch/break features | d72bc0a020d0 | direction | weak | deriv-ticks |
| Regularized cross-pair factors | d2fdfe05473e | ensemble | weak | deriv-ticks |
| Nested ablations and blocked permutations | d7bb802357a3 | validation | moderate | deriv-ticks |
| Calibration by pair, horizon and session | d37364bff38a | calibration | moderate | deriv-ticks |
| Explicit Rise/Fall/tie outcomes | d7f508a50199 | labels | moderate | deriv-ticks |
| Scheduled-release timing gates | d85676bad0f9 | magnitude | moderate | external: macro calendar |
| Signed flow × depth response | d144fafa19f0 | features | moderate | external: trades and book depth |

The signed-flow thesis qualifies the broad size-only prior at subsecond horizons; it establishes no Deriv-horizon edge. Round-number direction ideas warrant testing, with weak trading evidence. The macro-drift paper finds no significant simple pre-release momentum, and multiple-testing correction reduces its discoveries. Most persistence evidence concerns magnitude; simple-model competitiveness supports the in-house prior.
=== market-microstructure__17of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__17of19/records.jsonl): **49 records**, validated for JSON, shard order, IDs, and numerical quote/page support.

Relevance counts: **3: 8 · 2: 17 · 1: 23 · 0: 1**. Reading depth: **14 full, 11 partial, 24 triage**. None unreadable; partial records explicitly identify coverage gaps.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Threshold-crossing duration forecasts | e4083c19ceac | magnitude | Moderate | Deriv ticks |
| PIT and residual calibration checks | e4083c19ceac | calibration | Moderate | Deriv ticks |
| Noise-robust volatility features | e60ae9a0d92b | features | Moderate | Deriv ticks |
| Multiscale cross-pair covariance | e73da14b23c9 | features | Moderate | Deriv ticks |
| Session variance seasonality | e40ad38db37f | magnitude | Moderate | Deriv ticks |
| Causal multiscale lead-lag features | dba0dbb08d27 | features | Weak | Deriv ticks |
| Self-exciting price-change intensity | db3e2eef847b | magnitude | Weak | Deriv ticks |
| Dependence-preserving nulls and multiple-testing correction | e1819d8dfb59 | validation | Moderate | Deriv ticks |
| Test regime separability before imposing clusters | e6e31d7857b2 | validation | Moderate | Deriv ticks |
| Post-announcement regime conditioning | dfbac11fd234 | regime | Moderate | External: macro-release calendar |

The macro-event studies report conditional directional information in signed flow, qualifying a blanket “order flow predicts only size” claim. They do **not** establish a usable Deriv forecast. The entropy paper’s claimed directional accuracy ceiling has mathematical flaws. Nothing here validates the earlier in-house direction or magnitude performance figures.
=== market-microstructure__18of19
Wrote and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__18of19/records.jsonl): **49 records in shard order**, with 30 full substantive reads and 19 triage reads.

| Relevance | Documents |
|---|---:|
| 3 | 7 |
| 2 | 23 |
| 1 | 18 |
| 0 | 1 |

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Online, shrunk intraday seasonality | ea05b8e99a40 | regime | moderate | deriv-ticks |
| Session-conditioned cross-pair dependence | f52e3d15f2da | features | moderate | deriv-ticks |
| Regularized price-trajectory boosted trees | f3c5b6bc7808 | features | weak | deriv-ticks |
| Pooled power-law volatility kernels | f6a6f73c5c87 | magnitude | weak | deriv-ticks |
| Cumulative volatility-band occupancy | f4078dc12343 | features | weak | deriv-ticks |
| Causal standardized shock detection | f8152092d72c | regime | weak | deriv-ticks |
| Explicit up/down/tie calibration | f751ed14bc35 | calibration | moderate | deriv-ticks |
| Held-out randomized PIT diagnostics | ea05b8e99a40 | validation | moderate | deriv-ticks |
| Audit latent features for future-information leakage | ed0cf9751330 | validation | strong | deriv-ticks |
| Dealer gamma × liquidity × trend | f8152092d72c | direction | weak | external: options positions, Greeks, liquidity |

**Unreadable documents:** none. Missing mathematical expressions in some supplied texts are noted.

**Prior qualifications:** adaptive-liquidity and order-book models report conditional sign effects at very short horizons; dealer-gamma papers report conditional momentum/reversal. These qualify blanket “size only” wording, but do not establish a usable Deriv edge. The Polymarket study supports boosted trees over its CNN, though its target is current trade side. No paper verifies the in-house FX AUCs or contract win-rate claims.
=== market-microstructure__19of19
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/market-microstructure__19of19/records.jsonl): **45 records**, validated JSON, shard order and exact page citations. Extracted **65 levers**.

Relevance: **3: 7 · 2: 14 · 1: 24 · 0: 0**. Reading depth: 11 full, 10 partial, 24 triage.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pair/session volatility with DST | `283e668408bd` | magnitude | moderate | deriv-ticks |
| Autoregressive conditional quantiles | `283e668408bd` | loss | moderate | deriv-ticks |
| Noise-aware realized variance | `ffdaec752d0a` | magnitude | moderate | deriv-ticks |
| Explicit no-move probability | `ffba38901f1b` | labels | moderate | deriv-ticks |
| Exceedance frequency and clustering tests | `283e668408bd` | validation | moderate | deriv-ticks |
| Shrink pair models toward pooled coefficients | `b44b1f8fbedd` | ensemble | weak | deriv-ticks |
| Low-rank pair/session/price interactions | `b44b1f8fbedd` | features | weak | deriv-ticks |
| Compare signals against unconditional direction baselines | `2646380cccc9` | validation | moderate | deriv-ticks |
| Disaggregated customer-flow signals | `fc0795a2f05b` | direction | moderate | external: classified customer flows |
| Queue imbalance, tested at fixed expiry | `fb13304a045e` | direction | moderate | external: quotes and queue sizes |

No files were missing or wholly unreadable. Texts `2c0d51e177cc` and `4953ecd1adea` truncate before their intended ending; limitations are recorded.

The blanket “order flow predicts only magnitude” prior is too broad: observed queue imbalance and classified customer flows contain directional information. These require external data. Conversely, persistence alone often fails to predict returns, and `2646380cccc9` reports disappearing conditional sign separation at longer intraday horizons. Nothing here establishes a profitable Deriv binary edge.
=== ml-deep-learning-finance__01of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__01of15/records.jsonl): **47 records**, in shard order.

Relevance: **3: 16 · 2: 22 · 1: 8 · 0: 1**. Read 38 fully and triaged nine. Validation passed: JSON, IDs, schema, and all 119 quoted passages against their cited pages.

The ten most promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Exact entry/expiry labels and tie handling | `0b8fd8bd673b` | labels | strong | deriv-ticks |
| Date-blocked inference and multiplicity control | `05e4ef8a1c83` | validation | strong | deriv-ticks |
| Nested selection using actual contract utility | `13ee769e9044` | validation | strong | deriv-ticks |
| Monotone quantile forecasts for magnitude gates | `0b8fd8bd673b` | magnitude | moderate | deriv-ticks |
| Shared models across pairs and auxiliary targets | `0025c78b0114` | ensemble | moderate | deriv-ticks |
| Separate magnitude prediction from sign | `029ebd4c3017` | magnitude | moderate | deriv-ticks |
| Small, explicitly regularized model baselines | `05e4ef8a1c83` | features | moderate | deriv-ticks |
| Adaptive aggregation versus uniform averaging | `0d5e4c2260fe` | ensemble | moderate | deriv-ticks |
| Explicit abstention expert | `08f25e21544d` | selection-gating | moderate | deriv-ticks |
| Modest class weighting with recalibration | `10f3d6ee3545` | loss | moderate | deriv-ticks |

No document was wholly unreadable; several had garbled or interleaved figure text, noted in their records.

No convincing contradiction of the Deriv-specific priors emerged. External crypto-book studies report seconds-scale return signals, qualifying the broad “order flow cannot predict sign” claim without establishing an FX-mid edge. Several impressive directional headlines instead measured threshold touches, averaged prices, or stock ranks. Simple-model competitiveness and stronger magnitude predictability received support.
=== ml-deep-learning-finance__02of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__02of15/records.jsonl): **47 records**, matching shard order. All JSON and 181 page-cited finding quotes verified.

Relevance: **3: 15 · 2: 28 · 1: 4 · 0: 0**. Full records: 43; triage records: 4. Long-document selections are documented.

Ten promising levers follow. Evidence describes transferable source support; none is a demonstrated Deriv edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Enforce label maturity at every fitting cutoff | `243bae4a9c1b` | validation | Strong | Deriv ticks |
| Filtered Markov-switching HAR magnitude model | `243bae4a9c1b` | magnitude | Moderate | Deriv ticks |
| Multiscale log-HAR baseline | `1e017652c7f1` | magnitude | Moderate | Deriv ticks |
| Recalibrate using matured forecast errors | `1e017652c7f1` | calibration | Moderate | Deriv ticks |
| Average simple and compact learned volatility forecasts | `1e017652c7f1` | ensemble | Moderate | Deriv ticks |
| Average near-best validation hyperparameters | `1d2a4a998b5f` | ensemble | Moderate | Deriv ticks |
| Small, regularized online adapters | `169763d27bdb` | regime | Moderate | Deriv ticks |
| Narrow shared cross-pair bottleneck | `20466ba8f016` | ensemble | Moderate | Deriv ticks |
| Capped return-weighted auxiliary loss, retaining calibrated sign probabilities | `1f4170991dac` | loss | Moderate | Deriv ticks |
| Compact recurrent residual around a volatility baseline | `205c3baae2da` | magnitude | Moderate | Deriv ticks |

No entire document was unreadable. Extraction damage affects `1c8299949f70`, `1d87121bc950`, `1fd5bbc01ba8` and `21e00996e310`; figure placeholders were unavailable in `2258eb93debc`.

Challenges to the priors are narrow: external book imbalance predicts next-trade **aggressor sign**, and some task-specific neural models outperform trees. Neither establishes fixed-expiry FX direction skill. Overall, this shard supports separating magnitude from sign, benchmarking simple models seriously, and treating ensemble gains cautiously.
=== ml-deep-learning-finance__03of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__03of15/records.jsonl): **47 records in shard order**, with 150 source-verified quotes and 108 levers.

Relevance counts: **3: 14 · 2: 24 · 1: 9 · 0: 0**. Completed 38 detailed readings and nine triages. No unreadable documents or remaining partial records; the long thesis was read by relevant chapters. No evaluation earned grade A.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool cross-pair volatility features | 27d0a00cc9da | Magnitude | Moderate | Deriv ticks |
| Separate intraday dynamics from clock seasonality | 27d0a00cc9da | Features | Moderate | Deriv ticks |
| Rolling log-magnitude Gaussian process | 27cf643cde70 | Magnitude | Moderate | Deriv ticks |
| Compact HAR volatility baseline | 3336acf15661 | Magnitude | Moderate | Deriv ticks |
| Retain all outcomes; gate using causal forecasts | 326addd06736 | Validation | Strong | Deriv ticks |
| Audit actual feature availability times | 2cabd7241ba1 | Validation | Strong | Deriv ticks |
| Pool standardized FX training examples | 34bca8f13277 | Ensemble | Moderate | Deriv ticks |
| Score distributions and conditional coverage | 2813df142d71 | Calibration | Moderate | Deriv ticks |
| Shrink ensemble weights fitted on matured outcomes | 36510a44a718 | Ensemble | Moderate | Deriv ticks |
| Benchmark frozen pretrained forecasting models | 34866f64d75c | Ensemble | Moderate | External weights and provenance; Deriv inputs |

Evidence ratings describe the mechanism or validation lesson, not demonstrated Deriv profitability.

Qualified challenges to the priors: the FX thesis favors neural models over default conventional baselines, but uses smoothed ternary labels. Foundation models outperform simpler methods on monthly commodity forecasts. External order-book generation also shows short event-time return correlations, qualifying blanket claims about order-flow predictability. None establishes a robust fifteen-minute, price-only Deriv direction edge.
=== ml-deep-learning-finance__04of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__04of15/records.jsonl): **47 records**, verified in shard order, with 117 page-checked verbatim quotes and 100 levers.

Relevance counts: **3: 15 · 2: 21 · 1: 11 · 0: 0**. Depth: 32 full, 4 partial, 11 triage. None unreadable.

Ten promising levers follow. “Ticks” means existing Deriv mid-price data; evidence concerns the source results, not proven FX transfer.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool magnitude models; add common volatility | `458f3a679731` | magnitude | moderate | Ticks |
| HAR/HARQ variance, quarticity and jump features | `399e2ff42430` | magnitude | moderate | Ticks |
| Causal time-of-day volatility profiles | `458f3a679731` | features | moderate | Ticks |
| Retain intraday volatility trajectories | `458f3a679731` | magnitude | moderate | Ticks |
| Compare shared and pair-specific model heads | `3f66c557f801` | ensemble | moderate | Ticks |
| Per-window learned normalisation | `4418c9af1a2f` | features | moderate | Ticks |
| Flexible conditional return distributions | `3deabf5bb4cc` | calibration | moderate | Ticks |
| Penalise poor historical windows | `42eead976a3d` | loss | moderate | Ticks |
| Sparse cross-pair probability stacking | `4681e1d4bd43` | ensemble | moderate | Ticks |
| Evaluate directional accuracy against selection coverage | `3dd5b3cccbbd` | selection-gating | moderate | Ticks |

Partial reads: `3e650c82d5e5`, `425053484028`, `43797b9c1306`, `445af9116089`; omissions are documented in their notes.

Qualified contradictions: pooled neural networks beat XGBoost on intraday equity volatility, and complex regularised random features improve monthly macro timing. Neither convincingly overturns the weak-sign/strong-magnitude prior for Deriv FX binaries. Several apparent direction successes instead involve target leakage, stationary-class dominance, price-level regression, or frictionless portfolio returns.
=== ml-deep-learning-finance__05of15
Saved and validated all 47 records in [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__05of15/records.jsonl): relevance **3: 19**, **2: 22**, **1: 6**, **0: 0**. All IDs match shard order; all 158 finding quotes match their cited pages.

The ten most promising levers are candidates for testing, not established Deriv edges.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Jointly select training history and model complexity | `4f7f5c218997` | validation | moderate | Deriv ticks |
| Shared causal return convolutions for magnitude | `5174e4b7c064` | magnitude | moderate | Deriv ticks |
| QLIKE training for positive variance forecasts | `5eec04210d1e` | loss | moderate | Deriv ticks |
| Shallow cross-pair volatility spillovers | `5eec04210d1e` | magnitude | moderate | Deriv ticks |
| Small recurrent adjustment to GARCH | `54ec7095df24` | magnitude | moderate | Deriv ticks |
| Range-scaled OHLC and close-location features | `534c580c875e` | features | moderate | Deriv ticks |
| Pool patterns across pairs and past regimes | `4c9ca4908bd6` | ensemble | moderate | Deriv ticks |
| Frozen pooled model with low-rank pair adapters | `5b589f66dc29` | ensemble | moderate | Deriv ticks |
| Untouched outer tests for adaptive research | `5df0919520ec` | validation | moderate | Deriv ticks |
| Frozen Kronos transfer benchmark | `5d39f93cfaee` | features | moderate | External checkpoint; Deriv OHLC |

No document was wholly unreadable. Corrupted result text required partial records for **`5a60b0410578`** and **`5b589f66dc29`**.

No convincing evidence overturns the short-horizon sign priors. Some neural models outperform simpler baselines in other settings, but strong FX direction claims have timing or evaluation defects. Papers **`56e875a22857`** and **`5c9d9502469b`** also caution that better variance forecasts need not improve tail probabilities or magnitude-gate calibration.
=== ml-deep-learning-finance__06of15
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__06of15/records.jsonl): **47 records**, in shard order.

Relevance: **3: 19 · 2: 22 · 1: 6 · 0: 0**. Coverage: **28 full, 13 partial, 6 triage**. Partial coverage is explicitly marked; no files were unreadable. JSON, ids and all 126 page-cited quotes passed verification.

Ten promising levers are below. “Ticks” means existing Deriv data; evidence grades describe source evidence, not demonstrated Deriv performance.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale HAR volatility baseline | `675924792aca` | magnitude | moderate | Ticks |
| Shrink magnitude forecasts toward GARCH | `6cd5eb3e94e4` | loss | moderate | Ticks |
| Weight samples by training-loss improvement | `6e1c93a4dbac` | loss | moderate | Ticks |
| Diversify ensemble feature subsets | `6e1c93a4dbac` | ensemble | moderate | Ticks |
| Sparse, changing cross-pair lag features | `67bf0e5b20fa` | features | moderate | Ticks |
| Preserve signed lead–lag relations and USD orientation | `6b6ffc0c2db6` | features | moderate | Ticks |
| Wide random Fourier features with strong ridge | `6b4d5ae7fb77` | features | moderate | Ticks |
| Pool normalized sequences across pairs | `6fba95bf63df` | ensemble | moderate | Ticks |
| Compare density heads on identical backbones | `6d5546887081` | calibration | moderate | Ticks |
| Use time-only and no-change controls | `6a4456abaa68` | validation | strong | Ticks |

Qualified challenges to the in-house priors:

- Regularized wide models challenge blanket preference for small models (`6b4d5ae7fb77`).
- Some equity studies favor neural networks over trees; the LSTM study’s recent net profitability nevertheless deteriorates substantially.
- The Hurst paper reports an association with directional-model accuracy, but does not establish an independent sign mechanism.
- Better volatility or density forecasts repeatedly coexist with weak direction or losing strategies. I found no validated Deriv Rise/Fall edge.
=== ml-deep-learning-finance__07of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__07of15/records.jsonl): **47 records**, in shard order, with **131 page-checked findings and 104 levers**. JSON, IDs, order, schema and quote checks passed.

Relevance counts: **3: 14 · 2: 27 · 1: 5 · 0: 1**. Depth: 40 full, 1 partial, 6 triage.

Priority candidates below use existing ticks. Evidence grades concern the source experiment; none establishes a Deriv edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Monotone return CDF with explicit tie mass | `80475c32c0a8` | calibration | moderate | deriv-ticks |
| Lagged pooled-volatility target scaling | `715916807844` | labels | moderate | deriv-ticks |
| Small recurrent correction to GARCH covariance | `70dbc2f8542e` | magnitude | moderate | deriv-ticks |
| Calibrated selection versus coverage curves | `7c27eda40cdf` | selection-gating | moderate | deriv-ticks |
| Currency-factor residual histories alongside raw returns | `8047afe58367` | features | moderate | deriv-ticks |
| Small shared CNN with temporal attention | `8047afe58367` | ensemble | moderate | deriv-ticks |
| Realized semivariances and higher moments | `80475c32c0a8` | features | moderate | deriv-ticks |
| Actual-payoff training with executable labels | `7d003c925092` | loss | moderate | deriv-ticks |
| Bounded-lag DTW cross-pair features | `7ce741cf0c19` | features | weak | deriv-ticks |
| Validate augmentation on real future periods; preserve real-sample uncertainty | `7ea1f83883b7` | validation | strong | deriv-ticks |

No entire document was unreadable. `71a9aabbbd4c` remains partial because of corrupted figure text; several survey figures also have damaged glyphs.

The clearest qualification to the in-house priors is that quantile networks (`715916807844`) and MASTER (`7f535d61deff`) beat tree benchmarks on their equity tasks. Those results concern monthly distributions and multi-day ranking, respectively. No credible result here overturns the magnitude-versus-sign distinction or demonstrates profitable Deriv expiry-direction prediction.
=== ml-deep-learning-finance__08of15
Created [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__08of15/records.jsonl). Verified all 47 records, shard order, JSON parsing, and exact page-cited quotes.

Relevance: **3: 14 · 2: 28 · 1: 5 · 0: 0**. Recorded 152 findings and 152 levers.

Ten promising levers; evidence refers to the paper’s setting, with FX transfer still requiring testing:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Untouched outer periods and temporal embargo | `8510501b8c8f` | validation | strong | Deriv ticks |
| Predict sign probabilities and tie mass directly | `9084ef452378` | calibration | strong | Deriv ticks |
| Combine multiscale realized-volatility measures | `871508255b44` | magnitude | moderate | Deriv ticks |
| Compare classification and regression under identical tuning | `8505d4c0f8bd` | loss | moderate | Deriv ticks |
| Pool pairs and test unseen-pair transfer | `8ae07ac2ae3b` | ensemble | moderate | Deriv ticks |
| Test optimizer diversity beyond seed averaging | `8bb4b1967da2` | ensemble | moderate | Deriv ticks |
| Check calibration within selected signal groups | `89ae6a41583c` | calibration | moderate | Deriv ticks |
| Run the complete pipeline against known-null returns | `927bd0c275bf` | validation | strong | Deriv ticks |
| Stack magnitude models using chronological out-of-fold predictions | `8460573f909a` | ensemble | moderate | Deriv ticks |
| Test asymmetric order-flow information | `8ae07ac2ae3b` | data | moderate | External: order books, trades, cancellations |

None were unreadable. Three oversized documents received selective, explicitly partial reads: *Financial Machine Learning*, the evolutionary-trading thesis, and *Re(Visiting) Time Series Foundation Models in Finance*.

The strongest contradiction is to the blanket claim that order flow predicts only size: the pooled order-book study demonstrates sign information at next-price-change horizons. It requires unavailable microstructure data and establishes no tradable-expiry Deriv edge.

Most evidence supports cautious tree baselines and weak directional predictability. Large FX directional claims are weakened by preprocessing leakage or inadequate validation; impressive price-error and portfolio-return figures frequently fail to establish binary profitability.
=== ml-deep-learning-finance__09of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__09of15/records.jsonl).

Validated **47 records in shard order**, with 159 exact page-cited quotations and 118 levers.

- Relevance **3:** 17 documents
- Relevance **2:** 21
- Relevance **1:** 9
- Relevance **0:** 0
- Depth: 32 full, 6 explicitly partial, 9 triage
- Unreadable: none

Ten promising test candidates:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Select similar historical volatility blocks before pooling | `98648be5008a` | magnitude | moderate | deriv-ticks |
| Compress lag histories with sparse-group regularization | `a69287f5fdce` | features | moderate | deriv-ticks |
| Share model slopes while shrinking pair-specific offsets | `a69287f5fdce` | ensemble | moderate | deriv-ticks |
| Shared echo-state reservoir with ridge readouts | `99e1c5c67fd6` | direction | moderate | deriv-ticks |
| Regularized random Fourier features | `a2ea842a869b` | features | moderate | deriv-ticks |
| Small Student-t return-density head | `95afd71c4a92` | calibration | moderate | deriv-ticks |
| Stronger shrinkage for skewness than volatility | `98da122a5872` | loss | moderate | deriv-ticks |
| Quantile averaging versus density mixtures | `98da122a5872` | ensemble | moderate | deriv-ticks |
| Tune compact volatility-history lengths | `a157fa63e346` | magnitude | moderate | deriv-ticks |
| News-impact scores for delayed post-release drift | `a410e809cfff` | direction | moderate | external: timestamped news and frozen model outputs |

The evidence largely supports the in-house emphasis on magnitude, regularization and strong baselines. Possible qualifications:

- Signed order-book inputs show some immediate sign information, qualifying the blanket order-flow claim; this requires external data and does not establish a tradable FX contract edge.
- Regularized nonlinear complexity improves some monthly portfolios, without showing deep nets beat tuned trees.
- The uncertainty-gating paper contains conflicting results and questionable target alignment, weakening claims of automatic gating benefits.

No document verifies the required Deriv win-rate edge.
=== ml-deep-learning-finance__10of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__10of15/records.jsonl): **47 records**, in shard order, with **164 verified page-cited quotes**. JSON and schema checks pass.

**Full reading remains incomplete:** 8 full, 36 partial, 3 triage. Partial coverage is explicitly marked. No files were missing or unreadable.

Relevance counts: **3: 13 · 2: 31 · 1: 3 · 0: 0**.

Ten promising transfer candidates; evidence describes the source, not proven Deriv performance:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Monotone return CDF for magnitude thresholds | a8bb109c01c7 | magnitude | Moderate | deriv-ticks |
| Log realized-variance forecasts | aa0ee2f43993 | magnitude | Moderate | deriv-ticks |
| Pooled cross-pair graph | a72851e0b903 | direction | Moderate | deriv-ticks |
| Recent data plus historical replay | aff4ae56ebf9 | regime | Moderate | deriv-ticks |
| Student-t likelihood | aeb959eda905 | loss | Moderate | deriv-ticks |
| Cross-fitted expert gate | b644126c4741 | selection-gating | Moderate | deriv-ticks |
| Consensus clustering across seeds | a6e4e3418d2c | ensemble | Moderate | deriv-ticks |
| Nested feature selection | b2d0163386a1 | validation | Moderate | deriv-ticks |
| Evaluate payout utility across gate coverage | b4853f642742 | validation | Strong | deriv-ticks |
| Tabular foundation-model benchmark | b4853f642742 | ensemble | Moderate | external: pretrained weights/runtime |

FinWorld reports daily-equity neural gains over LightGBM, which challenges universal tree superiority but provides weakly comparable evidence for Deriv. No robust contradiction of the magnitude-versus-sign prior emerged. GMADL supplies an untested weighted-loss proposal; near-perfect classification claims elsewhere suffer from future-selected labels or explicit test-set tuning.
=== ml-deep-learning-finance__11of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__11of15/records.jsonl): **47 records in shard order**, with valid JSON and **155 findings checked against exact page quotes**.

Relevance counts: **3: 8 · 2: 28 · 1: 11 · 0: 0**. Completed 36 full reads and 11 triages. None unreadable; one document has corrupted equations but readable prose.

Ten most promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Out-of-time stacking with label-maturity checks | `bf2115053c5a` | validation | strong | deriv-ticks |
| Average event probabilities; audit tail calibration | `c5b6f430d034` | calibration | strong | deriv-ticks |
| Average diverse competent models | `b6ebce175853` | ensemble | moderate | deriv-ticks |
| Route magnitude experts by current regime | `b97572a514a8` | ensemble | moderate | deriv-ticks |
| Penalize magnitude underforecasting asymmetrically | `b97572a514a8` | loss | moderate | deriv-ticks |
| Forecast magnitude residuals around persistence/HAR | `c36460571f97` | magnitude | moderate | deriv-ticks |
| Model positive, negative and zero-return masses jointly | `c5e0f58f7da4` | labels | moderate | deriv-ticks |
| Pool normalized histories across pairs | `c5e0f58f7da4` | features | moderate | deriv-ticks |
| Benchmark a small bar-based LSTM against tuned trees | `c12eb2871218` | direction | moderate | deriv-ticks |
| Gate on agreement across neighboring horizons | `bd4a6fb0f480` | selection-gating | weak | deriv-ticks |

Evidence grades concern source support; FX transfer remains unproven.

Some monthly equity studies favor neural networks over their tree baselines (`bcb88148a943`, `bd2fad765fd2`), and ensemble gains are inconsistent. These qualify universal tree/ensemble claims without overturning the in-house priors. The direct minute-EURUSD study finds majority-class collapse. No result here convincingly establishes a Deriv-ready direction edge; volatility-state evidence remains evidence about magnitude.
=== ml-deep-learning-finance__12of15
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__12of15/records.jsonl): **47 records**, verified in shard order, with exact page-cited quotations.

Relevance: **3: 17 · 2: 27 · 1: 3 · 0: 0**. Read 44 fully and triaged 3. No unreadable documents.

Ten promising levers—all usable with **Deriv ticks**; evidence grades concern the source results, with FX transfer still requiring testing:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool pairs through shared models | cb88a71ac016 | ensemble | moderate | deriv-ticks |
| Cross-pair HAR volatility features | caddb5aa42fa | magnitude | moderate | deriv-ticks |
| Quantile forecasting losses | c8dc23c7e001 | loss | moderate | deriv-ticks |
| Conditional coverage checks | cb8afc9988de | calibration | moderate | deriv-ticks |
| Average independent seeds | c8a366c67372 | ensemble | moderate | deriv-ticks |
| Causal jump-penalized volatility states | d38fe2e52454 | regime | moderate | deriv-ticks |
| Online early stopping | d71670ae8c9b | loss | moderate | deriv-ticks |
| Combine slow and adaptive models | d71670ae8c9b | ensemble | moderate | deriv-ticks |
| Pool normalized training across horizons | d77debe75797 | features | moderate | deriv-ticks |
| Audit smoothed labels against exact settlement | d4bd10b9deed | labels | strong | deriv-ticks |

Qualified contradiction: **cb88a71ac016** and **d523c4e374cc** find next-event directional information in equity book/flow data. This challenges a blanket “order flow predicts only size” claim, but establishes no mid-only FX edge at our tradable horizons. The shard otherwise supports prioritizing magnitude, regularization and honest validation; it does not establish deep-network superiority over tuned trees for our task.
=== ml-deep-learning-finance__13of15
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__13of15/records.jsonl): **47 records in shard order**, 175 page-checked quotations, 110 levers.

Relevance counts: **3: 20 · 2: 15 · 1: 11 · 0: 1**. Full reads: 35; triage: 12. Unreadable: none.

Priority levers to test:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Tiny HARNet magnitude model | ddd9fc3de99c | magnitude | moderate | deriv-ticks |
| Pool magnitude models across pairs | da5e19df7106 | magnitude | moderate | deriv-ticks |
| QLIKE variance-training loss | ddd9fc3de99c | loss | moderate | deriv-ticks |
| Compact temporal and cross-pair filters | dd3afe546dc9 | features | moderate | deriv-ticks |
| Bounded magnitude-weighted directional loss | e72cd27ae7e1 | loss | moderate | deriv-ticks |
| Average forecasts across training seeds | dd3afe546dc9 | ensemble | moderate | deriv-ticks |
| Strongly regularised ridge baseline | e0cfe710f57d | features | moderate | deriv-ticks |
| Audit denoising/decomposition causality | e76ff0aa00b2 | validation | strong | deriv-ticks |
| Rebuild exact forward-expiry labels | e5eaefbbe91e | labels | strong | deriv-ticks |
| Dependence-aware model comparison and multiplicity control | e0cfe710f57d | validation | moderate | deriv-ticks |

No convincing contradiction of the Deriv-specific priors emerged. One dramatic accuracy claim reproduces a **current moving-average rule**, rather than forecasting future direction. The Bitcoin study supports testing weighted losses, but results depend strongly on retraining windows; its quantile-based trading strategy underperforms. None establishes a tradable Deriv FX edge.
=== ml-deep-learning-finance__14of15
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__14of15/records.jsonl): **47 records in shard order**, validated for JSON, required fields, numerical support, and 103 page-cited quotations.

Relevance counts: **3: 18 · 2: 18 · 1: 11 · 0: 0**. Depth: 32 full, 4 partial, 11 triage.

Ten promising levers follow. All use **Deriv ticks**; evidence grades describe the source support, not proven Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized shallow trees for magnitude | `edfb583fa73b` | magnitude | moderate | Deriv ticks |
| Monotone asymmetric return quantiles | `f5c492a612b4` | magnitude | moderate | Deriv ticks |
| Multiscale exponential volatility memory | `ef284130b53b` | magnitude | moderate | Deriv ticks |
| Pool pairs with common calendar splits | `ef284130b53b` | validation | strong | Deriv ticks |
| Separate later probability-calibration block | `ee161d46fcc1` | calibration | moderate | Deriv ticks |
| Causal volatility-of-volatility features | `e99bf724c94a` | magnitude | moderate | Deriv ticks |
| Quantiles from matured out-of-fold residuals | `edfb583fa73b` | calibration | moderate | Deriv ticks |
| Shared model across forecast horizons | `f37c600e478d` | ensemble | moderate | Deriv ticks |
| Predictive disagreement as an abstention feature | `eba514fa27b4` | selection-gating | moderate | Deriv ticks |
| Past-only rolling normalization | `f50d57a80644` | features | moderate | Deriv ticks |

No file was missing or wholly unreadable. Partial coverage is disclosed for `edfb583fa73b`, `ee4e0d6e5da0`, `ee5e463a5255`, and `f47209df014d`; `ee5e463a5255` contains severely garbled pages.

No convincing evidence overturns the weak-direction/strong-magnitude or tuned-tree priors. `f12680a0873f` reports near-chance direction and negligible seed effects, qualifying the earlier direction and seed-ensemble expectations; its direction metric differs from entry-to-expiry sign. Strong neural direction results elsewhere mostly require external order-book data and use smoothed event-time labels.
=== ml-deep-learning-finance__15of15
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-deep-learning-finance__15of15/records.jsonl): **45 records in shard order**, with 142 verified page quotes.

Relevance: **3: 16 · 2: 20 · 1: 9 · 0: 0**. Coverage: 21 full, 15 partial, 9 triage. No unreadable files; partial coverage is documented.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Purge overlapping expiry labels | `49db0568c147` | validation | strong | deriv-ticks |
| Repeat model selection inside dependence-aware null tests | `d65c51595301` | validation | strong | deriv-ticks |
| Pool small volatility models across pairs | `f8001f6e7be5` | magnitude | moderate | deriv-ticks |
| Multiscale variance, semivariance and quarticity | `f8c9c6339041` | features | moderate | deriv-ticks |
| Decaying volatility lags through ordered lasso | `f8cc3e8bbeaa` | magnitude | moderate | deriv-ticks |
| Causal rolling volatility normalization | `fc4e74fa20e5` | features | moderate | deriv-ticks |
| Shared return-mixture probability model | `fef97ec288f0` | calibration | moderate | deriv-ticks |
| Acceptance model trained on out-of-fold predictions | `49db0568c147` | selection-gating | moderate | deriv-ticks |
| Small causal dilated volatility network | `eefed88f76f2` | magnitude | moderate | deriv-ticks |
| Ensemble forecasts across expiry horizons | `f15bb8395bf4` | ensemble | moderate | deriv-ticks |

Neural volatility gains qualify universal tree dominance, but depend on inputs and horizons. `ff4ba008f324` claims Hurst/entropy direction predictability with weak evidence; `6d1ad2ee270e` describes immediate order-flow direction signals requiring external microstructure data. Neither establishes a mid-only FX edge at tradable expiries. Several sources reinforce the magnitude-versus-sign distinction and show attractive gross results disappearing after costs or final holdouts.
=== ml-stats-foundations__01of38
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__01of38/records.jsonl): **50 records in shard order**, with valid JSON and all finding quotes checked against their cited pages.

Relevance counts: **3: 4 · 2: 17 · 1: 22 · 0: 7**. Reading depth: 19 full, 2 partial, 29 triage.

The ten most promising levers to test:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Ridge and small L2 neural-net baselines | `05d7e51e064e` | loss | Moderate | Deriv ticks |
| Random forests versus boosted trees under weak signals | `05d7e51e064e` | ensemble | Moderate | Deriv ticks |
| Fixed-budget random hyperparameter search | `01e88a175a36` | validation | Strong | Deriv ticks |
| Pooled score with pair/recent-period recalibration | `003b83685a85` | calibration | Moderate | Deriv ticks |
| Nested Brier-weighted probability stacking | `05bb2a1f1c84` | ensemble | Moderate | Deriv ticks |
| Brier training versus log-loss plus calibration | `08c3dbab5345` | calibration | Moderate | Deriv ticks |
| Separate payoff-aware trade/wait gate | `08e8af202a24` | selection-gating | Weak | Deriv ticks |
| Common-factor and residual cross-pair features | `05933dd0123b` | features | Weak | Deriv ticks |
| Simultaneous uncertainty across model comparisons | `039bccd60a7d` | validation | Moderate | Deriv ticks |
| Joint direction/magnitude probability-coherence checks | `090cb47ae7c6` | validation | Moderate | Deriv ticks |

Evidence grades concern the source methods, not demonstrated FX profitability.

No document was wholly unreadable. Partial records cover selected filtering/stopping book chapters and corrupted variable-importance graphics in *Can Machines Learn Weak Signals?* The CVXPY item contains a repository README capture instead of the catalogued paper.

The main challenge to the in-house priors is *Weak Signals*: it favors ridge, L2 neural nets and random forests over sparse methods and boosted trees. Its financial tests concern annual/monthly equities with external predictors, so they do not refute the FX-specific results. Nothing here establishes a tradable Deriv sign edge or overturns the size-versus-sign prior.
=== ml-stats-foundations__02of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__02of38/records.jsonl): **50 records**, in shard order, with all quotations verified against cited pages.

Relevance counts: **3: 4 · 2: 17 · 1: 26 · 0: 3**. Depth: 18 full readings, 3 selective chapter readings, 29 triages. Unreadable documents: **none**.

The ten strongest candidates are below. Evidence describes methodological support; none establishes Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Predict before updating; reveal labels at expiry | `0a05134f9a11` | validation | strong | deriv-ticks |
| Sequential evidence against payout break-even | `0a8e156a6b39` | validation | strong | deriv-ticks |
| Audit clocks, missingness and cleaning filters | `0cd762fdea3f` | validation | strong | deriv-ticks |
| Predeclare seeds and report every run | `0fc34bc1fb56` | validation | strong | deriv-ticks |
| Challenge Hurst features with short-memory and trend nulls | `0fd4118529e9` | validation | strong | deriv-ticks |
| Regularized pooled linear/logistic baselines | `092769a67d7b` | loss | moderate | deriv-ticks |
| Shrink covariance for whitening or LDA | `0b690dcb174f` | features | moderate | deriv-ticks |
| Block median-of-means for heavy-tailed summaries | `0a05134f9a11` | validation | moderate | deriv-ticks |
| Learn bounded historical sample weights | `0ba9ce778b4f` | regime | moderate | deriv-ticks |
| Calibrate component probabilities before combining | `0d9f10a3ed71` | calibration | moderate | deriv-ticks |

No direct empirical FX result contradicts the in-house priors. Daily-stock validation favors LightGBM, while some fusion experiments worsen calibration. The long-memory review qualifies the blanket sign-impossibility claim through correlated Gaussian models, but supplies no Deriv direction evidence.
=== ml-stats-foundations__03of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__03of38/records.jsonl): **50 records**, in shard order, with verified quotes and page references.

Relevance counts: **3: 5 · 2: 21 · 1: 19 · 0: 5**. Reading depth: 24 full, 2 partial, 24 triage. None unreadable. Partial reads: `12adbaac16e6`, `15d925a6b42c`.

The ten most promising levers are below. Evidence grades concern the method; they do not establish Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Studentized block-bootstrap uncertainty | `11c294cc46b1` | validation | moderate | Deriv ticks |
| Anytime payout-aware win-rate evidence | `19dfc4e96857` | validation | strong, theoretical | Deriv ticks |
| e-BH across declared model hypotheses | `19dfc4e96857` | validation | strong, theoretical | Deriv ticks |
| Audit coverage separately by pair/session/gate | `1a238d265fd5` | validation | moderate | Deriv ticks |
| Independent seeds before nearby checkpoints | `1811161af170` | ensemble | moderate | Deriv ticks |
| Regularized mixtures of regime specialists | `15be41fd1683` | ensemble | moderate | Deriv ticks |
| Shrink sparse gate win rates with pseudocounts | `150fc4f03366` | calibration | moderate | Deriv ticks |
| Regularized monotone probability calibration | `12adbaac16e6` | calibration | moderate | Deriv ticks |
| Shared features with separate mean/magnitude heads | `15799512688d` | magnitude | moderate | Deriv ticks |
| Low-order return-path signatures | `161f142a3408` | features | weak | Deriv ticks |

No convincing FX result overturns the in-house priors. Qualifications: ensemble Brier improvements need not improve calibration; hierarchical pooling can undercover individual groups; daily lead–lag gains fail consistently in futures. Bounded-loss results favor downweighting contaminated extremes, but their inconsistent metrics provide weak grounds for challenging return-weighted losses.
=== ml-stats-foundations__04of38
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__04of38/records.jsonl): **50 records**, in shard order, with valid JSON and **108 verified page-cited quotes**.

Relevance counts: **3: 4 · 2: 26 · 1: 14 · 0: 6**. Reading depth: 29 full, 20 triage, one partial—the long econometrics slide deck, whose relevant sections were read. **None unreadable.**

The ten most promising levers are below. Evidence is moderate for each source method; none establishes FX profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Dependence-aware uncertainty for held-out performance | `1c18e4c5d3db` | validation | Moderate | deriv-ticks |
| Natural-prior training with validated magnitude gates | `204f71ba8ec9` | selection-gating | Moderate | deriv-ticks |
| Tune exponential recency weights against window baselines | `1e2fd6e5e572` | loss | Moderate | deriv-ticks |
| Compare adaptive lasso, ordinary lasso and ridge | `1f23df1fb0df` | features | Moderate | deriv-ticks |
| Shrink covariance estimates for large feature panels | `1de15f67265b` | features | Moderate | deriv-ticks |
| Benchmark frozen TabPFN against tuned boosting | `21f3cb0e28e5` | direction | Moderate | deriv-ticks |
| Benchmark frozen TabICL with settled historical contexts | `22b3b112d8e2` | direction | Moderate | deriv-ticks |
| Add regularized piecewise-linear numerical embeddings | `22b97677fec3` | features | Moderate | deriv-ticks |
| Audit calibration by action and rolling period | `22781442fd74` | validation | Moderate | deriv-ticks |
| Cluster trailing windows using compact structural features | `237c494cb291` | regime | Moderate | deriv-ticks |

Foundation-model experiments additionally require model weights and compute; TabPFN licensing caveats are recorded.

The main qualifications to the priors: neural tabular methods challenge universal tree dominance on nonfinancial benchmarks, without overturning the in-house FX result. The fractional-process paper claims theoretical sign persistence, without demonstrating Hurst-based FX prediction. Imbalance treatments can also worsen calibration, supporting natural-prevalence checks of weighted losses and resampling.
=== ml-stats-foundations__05of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__05of38/records.jsonl). Validation passed: **50 records**, correct shard order, valid JSON, **92 page-matched quotes**, and **59 levers**.

Relevance counts: **3: 5 · 2: 18 · 1: 20 · 0: 7**.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Joint stepdown correction for model searches | `2623c4335cda` | validation | strong | deriv-ticks |
| Stationary-block uncertainty estimates | `269f5437920a` | validation | strong | deriv-ticks |
| Partially pooled pair/session calibrators | `2901392afb0b` | calibration | moderate | deriv-ticks |
| Proper probability scores alongside ranking | `247497bb5223` | calibration | moderate | deriv-ticks |
| Evaluate confidence through risk versus coverage | `27c2c7c673a1` | selection-gating | moderate | deriv-ticks |
| Intraday seasonality baseline for magnitude | `256c1c0af4ef` | magnitude | moderate | deriv-ticks |
| Shared multiscale contrastive encoder | `247839920802` | features | weak | deriv-ticks |
| Compact reservoirs with regularized readouts | `23e7bca03832` | features | weak | deriv-ticks |
| Low-rank interactions through factorization machines | `27cc21a36095` | features | weak | deriv-ticks |
| Recurrence-image descriptors for magnitude | `2945947ee5c4` | magnitude | weak | deriv-ticks |

No document was unreadable. The long network review (`284d6eed8ae6`) is explicitly marked **partial**, with selected sections and limitations recorded.

No direct contradiction of the in-house FX performance priors was established. The scaling evidence supports the size-versus-sign caution. Calibration benefits need qualification: uncertainty aggregation sometimes worsens performance, and the hierarchical image paper’s fine-level calibration claims conflict with its reported results.
=== ml-stats-foundations__06of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__06of38/records.jsonl): **50 records**, in shard order.

Relevance counts: **3: 4 · 2: 23 · 1: 19 · 0: 4**. Completed 27 full reads and 23 triages. Verified JSON, schemas, IDs, order and **111 verbatim page-cited quotes**.

Ten promising levers to test:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Romano–Wolf search correction | 2d27aa4f498c | validation | strong | deriv-ticks |
| Uncertainty-penalized model selection | 2edbfd8e9a97 | validation | moderate | deriv-ticks |
| Joint regularization search for MLPs | 30cd23399242 | validation | moderate | deriv-ticks |
| Snapshot/weight averaging | 30cd23399242 | ensemble | moderate | deriv-ticks |
| Pooled empirical-Bayes calibration | 2b88b5182327 | calibration | moderate | deriv-ticks |
| Identity-shrinkage covariance | 2cad8a6e5673 | features | moderate | deriv-ticks |
| Sparse cross-pair partial correlations | 307b9bc8bdee | features | moderate | deriv-ticks |
| Sparse baseline with complexity monitoring | 2c4256dbb749 | features | moderate | deriv-ticks |
| Focal loss for rare magnitude exceedances | 2e6f45b97007 | loss | moderate | deriv-ticks |
| Model rankings across pair-period blocks | 306468a3ab1b | validation | moderate | deriv-ticks |

No whole document was unreadable. Missing seismology figures and extraction defects are flagged.

Two findings qualify the priors: transfer entropy detects brief equity **sign dependence**, although the authors reject profitability after costs; well-regularized MLPs outperform boosted trees on a broad tabular benchmark using single splits. Neither establishes a tradable Deriv direction edge.
=== ml-stats-foundations__07of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__07of38/records.jsonl): **50 records**, in shard order. All JSON parses; numerical findings have verified verbatim quotes and page references.

Relevance counts: **3: 2 · 2: 19 · 1: 26 · 0: 3**. Coverage: **19 full, 2 partial, 29 triage**.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiplicity control plus fresh-period confirmation | `38af8ce0cff0` | validation | strong | Deriv ticks |
| Dependence-aware learning curves and uncertainty | `36d85bb97f47` | validation | moderate | Deriv ticks |
| Explicit up/down/unchanged probabilities | `34a721213789` | labels | moderate | Deriv ticks |
| Out-of-fold Brier-optimized ensemble weights | `32c9a5ae4e85` | ensemble | moderate | Deriv ticks |
| Shrunk pair/group prediction heads | `38af940dc5ca` | ensemble | moderate | Deriv ticks |
| Regularized histogram boosting | `32ddfe0c7a8e` | ensemble | moderate | Deriv ticks |
| Sparse cross-pair lag features | `31ea50275de7` | features | moderate | Deriv ticks |
| Shared causal contrastive representations | `34d47d2c34ed` | features | moderate | Deriv ticks |
| Coherent ordinal direction/magnitude labels | `3506dd03a44d` | labels | weak | Deriv ticks |
| Trailing distribution-drift gating | `320267f2368f` | selection-gating | weak | Deriv ticks |

Evidence grades concern the source mechanism, not demonstrated FX profitability.

No document was wholly unreadable. Partial coverage remains for **`320267f2368f`**, a long transport tutorial with a truncated extraction, and **`3376c295b4f8`**, whose extraction contains corrupted and empty pages.

Nothing directly refutes the in-house FX priors. Relevant qualifications: ensembles do not win universally; marginal entropy is an unreliable proxy for predictor quality; and neural advantages in non-financial benchmarks do not establish an advantage over trees on FX.
=== ml-stats-foundations__08of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__08of38/records.jsonl). Verified all **50 records**, shard order, JSON parsing, quotation text, page citations and quote lengths.

Relevance: **3: 4 · 2: 18 · 1: 22 · 0: 6**. Reading depth: 20 full, 2 chapter-focused partial, 28 triage. Recorded 62 levers.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Tuned boosted-tree baseline | `3baeb241e4f5` | direction | moderate | Deriv ticks |
| Knockoff-controlled feature pruning | `39c0dc6085dd` | features | moderate | Deriv ticks |
| Feature-family and ridge-penalty ensembles | `3aead7e400c4` | ensemble | moderate | Deriv ticks |
| Chronological temperature calibration | `3aba3ea35dde` | calibration | moderate | Deriv ticks |
| Partially pooled pair/session calibration | `3de97afc02bc` | calibration | moderate | Deriv ticks |
| Regularized covariance estimates | `3eb0ebad56b8` | features | moderate | Deriv ticks |
| Brownian null tests with overlapping labels | `3a96822c1938` | validation | moderate | Deriv ticks |
| Explicit up/down/tie probabilities | `40090140f81f` | calibration | weak | Deriv ticks |
| Fixed-expiry prefix supervision | `3b221d95fa2c` | loss | weak | Deriv ticks |
| Heavy-tail-capable magnitude models | `4087e6891a8c` | magnitude | weak | Deriv ticks |

No files were unreadable. The vehicle-diagnostics thesis and APOLLO paper received focused partial reads; extraction gaps are flagged where present.

Nothing directly contradicts the stated FX priors. Relevant qualifications: label smoothing can harm distillation and likelihood scores; better tail fitting can worsen central distribution fit. No document establishes a validated short-horizon FX direction edge.
=== ml-stats-foundations__09of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__09of38/records.jsonl): **50 records in shard order**, with **93 quotations checked against source pages**.

Relevance counts: **3: 7 · 2: 22 · 1: 20 · 0: 1**. Unreadable documents: **none**. Both long decks received targeted chapter reads.

The ten most promising levers are below. Evidence strength concerns the method, not a demonstrated Deriv trading edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Evaluate frozen gates at actual payout and settlement rules | `48912bb4386a` | selection-gating | strong | deriv-ticks |
| Holm correction across logged hypotheses | `4317a0d1555d` | validation | strong | deriv-ticks |
| Romano–Wolf correction across the complete search | `41e18a42dabf` | validation | strong | deriv-ticks |
| Nest preprocessing, selection and tuning inside temporal evaluation | `49c4b5e4fae8` | validation | strong | deriv-ticks |
| Time-uniform monitoring under justified conditional assumptions | `486ef7fab26a` | validation | strong | deriv-ticks |
| Sparse cross-pair, multiscale volatility regression | `4650f1bb9799` | magnitude | moderate | deriv-ticks |
| Modest seed ensembles with probability-quality checks | `46ec8e603e84` | ensemble | moderate | deriv-ticks |
| Regularized feature-conditional forecast averaging | `455addab52f5` | ensemble | moderate | deriv-ticks |
| Sparse persistent regimes from trailing volatility | `441a2e7bf873` | regime | moderate | deriv-ticks |
| Compare Platt and isotonic calibration with scarce data | `48912bb4386a` | calibration | moderate | deriv-ticks |

No convincing evidence overturns the magnitude-versus-sign prior or establishes a tradable Deriv direction edge. Ensemble findings support seed averaging; nothing relevant overturns the boosted-tree prior. Caveats recorded include generic AUC “failure” bands without payout analysis, unsafe stock-forecast CV guidance, and a regime paper describing volatility forecasting while actually testing daily levels.
=== ml-stats-foundations__10of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__10of38/records.jsonl): **50 records**, in shard order. Verified JSON, schemas, IDs, and all **78 page-cited quotes**.

Readable documents by relevance: **3: 6 · 2: 18 · 1: 20 · 0: 5**. Of these, 24 received full reads and 25 were triaged.

Ten promising levers—all use **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Anytime-valid prospective evidence | `4f0de769eeda` | validation | strong |
| Dependent-test FDR correction | `4bfbec2b1099` | validation | strong |
| Past-only change monitoring | `4b659dcef2f3` | regime | moderate |
| Block-bootstrap probability averaging | `4a324699d065` | ensemble | moderate |
| Small-support probability shrinkage | `4aa899fba1cb` | calibration | moderate |
| Contamination-robust losses | `4e1e44c3dc9a` | loss | moderate |
| Pair/session reweighting audits | `4b6b0a725383` | validation | moderate |
| Synchronized cross-pair patches | `4b8dd874b961` | features | weak |
| Threshold-event Hawkes intensities | `4ebf643adf78` | magnitude | weak |
| Perturbation-stability gate | `4ed9bd1e3937` | selection-gating | weak |

Evidence grades describe source support; FX transfer remains untested.

**Unreadable:** `51e319ebc53b`, *Long Short-Term Memory*. The supplied body text is garbled; its provisional relevance is 2.

No shard result directly contradicts or validates the in-house FX AUC claims. Qualifications include bagging hurting stable learners and robust losses potentially conflicting with return-weighted objectives. Competitive tuned forests support the existing tree-model prior.
=== ml-stats-foundations__11of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__11of38/records.jsonl): **50 records in shard order**, with valid JSON and 106 verified quote/page matches.

Relevance counts: **3: 5 · 2: 29 · 1: 14 · 0: 2**. Coverage: 30 full, 3 partial, 16 triage, 1 unreadable.

The ten most promising levers below all use **deriv-ticks**. Evidence ratings concern the underlying method, not demonstrated FX profitability.

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Account for shared training data when estimating CV uncertainty | `537095165dba` | validation | strong |
| Monitor a fixed strategy against break-even using confidence sequences | `53cd708168fd` | validation | moderate |
| Calibrate combined cross-pair evidence for dependence | `53eeeddb5580` | validation | strong |
| Retain regularized boosted trees as the tabular baseline | `52bc282c922a` | direction | moderate |
| Test a small tree–neural probability blend | `59db02f2323b` | ensemble | moderate |
| Select source pairs before pooling, then shrink target corrections | `585810967277` | calibration | moderate |
| Cross-fit a correctness model for trade gating | `58961470feb4` | selection-gating | moderate |
| Use finite-sample-corrected nonlinear-dependence diagnostics | `52c21ebc3a62` | validation | strong |
| Fit simple magnitude quantiles with UTC seasonality | `52f5458538ee` | magnitude | weak |
| Compare ordinal magnitude bins with separate threshold classifiers | `5234b2f5e701` | magnitude | weak |

Unreadable: **`580690c56c43`**, *Greedy Function Approximation*: the supplied text contains only cover material. Partial coverage is explicitly marked for the regression slides and two theses.

The shard supports the tree-baseline prior. Qualifications: larger ensembles can worsen performance, smoothing can worsen calibration, and agreement does not establish correctness. No document establishes a realistic Deriv FX direction edge or overturns the size-versus-sign caution.
=== ml-stats-foundations__12of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__12of38/records.jsonl): **50 records**, in shard order.

- Relevance **3: 4**, **2: 14**, **1: 29**, **0: 3**.
- **18 full reads**, 32 triages; no unreadable documents.
- Validated JSON, IDs, schema, and 55 verbatim page-cited findings, including every recorded numerical finding.

Ten most promising levers—all usable with **Deriv ticks**:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Corrected dependence-adaptive bootstrap | `5ec74ea3d71e` | validation | moderate | deriv-ticks |
| Anytime bounds on frozen-strategy payout | `5bd09161af75` | validation | moderate | deriv-ticks |
| Calibration audits within trading strata | `5dfd00ddc247` | calibration | moderate | deriv-ticks |
| Separate sign and magnitude dependence tests | `5fa927328b63` | validation | moderate | deriv-ticks |
| Coherent probabilities across magnitude thresholds | `5d244b05f355` | magnitude | weak | deriv-ticks |
| Stress-test regime-weighted estimates | `60c46a42fafd` | validation | moderate | deriv-ticks |
| Preserve a small bank of regime experts | `5f51883a4c21` | ensemble | weak | deriv-ticks |
| Target replay toward update-damaged examples | `5fcdeb68a5ee` | ensemble | weak | deriv-ticks |
| Historical-only masked and tail pretraining | `60bed06fb5e5` | features | weak | deriv-ticks |
| Variational weight averaging for probability quality | `6200d69bbaf9` | calibration | weak | deriv-ticks |

**No direct contradiction of the in-house FX priors.** Predictive gains come from other domains. Important caveats: the bootstrap correction invalidates the original constant and simulations; SEPT pretraining includes held-out inputs; Bayesian averaging does not uniformly improve calibration.
=== ml-stats-foundations__13of38
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__13of38/records.jsonl): **50 records**, in shard order. Validation passed for JSON, required fields, page citations and verbatim quotes.

Relevance: **3 → 3 documents; 2 → 17; 1 → 22; 0 → 8.** Twenty full reads and thirty triages. **None unreadable.**

The ten most promising levers are below. Evidence grades describe source support, not demonstrated FX profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Contiguous-block uncertainty estimates | 646f87db347e | validation | strong | Deriv ticks |
| Monotone magnitude-exceedance probabilities | 667a1af606d9 | magnitude | strong | Deriv ticks |
| Partially pooled calibration offsets | 66d0f16d05f1 | calibration | moderate | Deriv ticks |
| Compare log loss and Brier fine-tuning | 6313da7e8c9f | loss | moderate | Deriv ticks |
| Multiscale absolute-return persistence | 6a170aed2914 | magnitude | moderate | Deriv ticks |
| Explicit gap masks and staleness features | 6a5b8145639c | data | moderate | Deriv ticks |
| Tuned trees with matched search budgets | 67f3fb7a9ec2 | validation | moderate | Deriv ticks |
| Preserve probability vectors through ensembles | 69174a19fdb4 | ensemble | moderate | Deriv ticks |
| Temporal-neighborhood representation learning | 643a2c9f43f6 | features | moderate | Deriv ticks |
| Time-augmented path signatures | 682aa7a34ea5 | features | moderate | Deriv ticks |

No directly comparable FX experiment contradicts the in-house results. The tabular survey supports strong tree baselines, and the long-memory chapter supports separating magnitude persistence from direction. That chapter also permits constructed conditional-mean-memory models, so the size-versus-sign claim should not be treated as a universal theorem. Neither it nor SigMA demonstrates a tradable FX direction edge.
=== ml-stats-foundations__14of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__14of38/records.jsonl): **50 records in shard order**, with 84 exact page-cited quotes and 49 levers.

Relevance counts: **3: 8 · 2: 12 · 1: 22 · 0: 8**. No unreadable documents; extraction gaps are noted.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Trial ledger and untouched final period | `6e9532a978ae` | validation | Strong | Deriv ticks |
| Joint block-bootstrap step-down testing | `72b90a93ed08` | validation | Moderate | Deriv ticks |
| Joint prediction and abstention training | `70c911da4c62` | selection-gating | Moderate | Deriv ticks |
| Rolling gate-coverage recalibration | `70c911da4c62` | calibration | Moderate | Deriv ticks |
| TabPFN against tuned trees | `6b5ce3dba2ef` | direction | Moderate | Deriv ticks |
| Train-only standardized sparse regression | `71f7f8dd14c4` | features | Moderate | Deriv ticks |
| Separate ensemble disagreement from variance | `704d93105ca9` | ensemble | Moderate | Deriv ticks |
| Sparse ensembles of preprocessing variants | `6b5ce3dba2ef` | ensemble | Moderate | Deriv ticks |
| Joint covariance forecasts for magnitude | `729912f556eb` | magnitude | Moderate | Deriv ticks |
| Delay-sensitive settlement replay | `73d5c6cbaa52` | validation | Moderate | Deriv ticks |

Evidence ratings concern the documented method, **not demonstrated Deriv profitability**.

No robust contradiction of the in-house FX priors emerged. TabPFN challenges blanket tree superiority on generic small tables, but does not overturn the FX result. Entropy and covariance papers establish no sign edge; the daily FX covariance improvement is not statistically significant.
=== ml-stats-foundations__15of38
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__15of38/records.jsonl): **50 records**, in shard order, with valid JSON and verified page-cited quotations.

Relevance counts: **3: 8 · 2: 16 · 1: 25 · 0: 1**. Completed 24 full reads and 26 triages. No unreadable files.

The ten most promising candidates to test are below. Evidence describes the source method; none establishes a Deriv trading edge.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Quantile forests for magnitude-exceedance probabilities | `781a07fea0fa` | magnitude | moderate | deriv-ticks |
| Anytime-valid forward win-rate monitoring | `7d0a6788b11f` | validation | moderate | deriv-ticks |
| Explicit error budgets across searched strategies and gates | `77998951a041` | validation | moderate | deriv-ticks |
| Bias-corrected forest instability as a gating feature | `7ee909fec04f` | selection-gating | moderate | deriv-ticks |
| Robust, shrunk cross-pair covariance | `7688686869f8` | features | moderate | deriv-ticks |
| Include parameter uncertainty in forecast intervals | `76ee5f37e1cf` | calibration | moderate | deriv-ticks |
| Normalize jump statistics by trailing local volatility | `75d3332f8959` | regime | moderate | deriv-ticks |
| Wasserstein-robust loss regularization | `7d755c4a3b49` | loss | moderate | deriv-ticks |
| Strongly shrunk pair-specific calibration offsets | `7d9af4acdfd9` | calibration | weak | deriv-ticks |
| Average forecasts across uncertain cointegration ranks | `7f3751681aa4` | ensemble | weak | deriv-ticks |

No credible direct contradiction to the in-house sign/magnitude or tree-versus-neural priors emerged. Important qualifications: calibration gains failed to transfer to the next month in TuneJury; forest sampling uncertainty differs from seed disagreement; and several impressive results relied on interpolation, oracle selection, restrictive assumptions or retrospective residuals.
=== ml-stats-foundations__16of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__16of38/records.jsonl): **50 validated records**, in shard order, with 101 page-matched quotations.

Read 49 documents: relevance **3: 10 · 2: 14 · 1: 21 · 0: 4**. Three long documents have explicitly recorded partial coverage.

Ten promising levers—all use **deriv-ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Whole-period and whole-pair holdouts | `7f9719489738` | validation | moderate |
| Limited causal time-series feature catalog | `825c44f07eec` | features | moderate |
| Mixed tree/neural ensemble | `8853fd1a1eb0` | ensemble | moderate |
| Sequential monitoring of frozen-model gains | `849a1093c30a` | validation | moderate |
| Online ensemble weights from matured Brier losses | `87660b1910bd` | ensemble | moderate |
| Separate calibration period and multiple diagnostics | `80827f422d4f` | calibration | moderate |
| Huber loss with sparse regularization | `88591681ff04` | loss | moderate |
| Successive halving within purged validation | `81b7aa7f62d5` | selection-gating | moderate |
| Local versus fixed normalization | `85223f907af5` | features | weak |
| Causal wavelet shrinkage features | `8034c670374b` | features | weak |

Unreadable: **`844c6be23fab`**, *Probability in Finance: Homework*—the shard supplies no text path.

TabArena qualifies the tree-superiority prior: neural ensembles can outperform trees on IID tasks with larger budgets. It also documents validation overfitting. No convincing evidence here overturns the magnitude-versus-sign caution or establishes a profitable Deriv direction edge.
=== ml-stats-foundations__17of38
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__17of38/records.jsonl): **50 records**, matching shard order. All JSON, required fields and 112 page-cited quotations passed validation.

Relevance counts: **3: 6 · 2: 24 · 1: 16 · 0: 4**. Reading depth: 27 full, 3 partial, 20 triage. No unreadable documents.

The ten most promising levers follow. Evidence grades concern the method, not demonstrated FX profitability.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Correct model-search significance using synchronized time blocks | `8d5ac02081d8` | validation | strong | deriv-ticks |
| Score frozen predictions sequentially after labels mature | `8d8baca08767` | validation | strong | deriv-ticks |
| Check uncertainty with dependent block subsampling | `896a783d0e99` | validation | moderate | deriv-ticks |
| Deduplicate compact price-feature libraries within training folds | `8a0911630c89` | features | moderate | deriv-ticks |
| Shrink covariance estimates for cross-pair residual features | `8f7e0d76f61d` | features | moderate | deriv-ticks |
| Regularize rank-based cross-pair partial correlations | `8cd5bc91dbc8` | features | moderate | deriv-ticks |
| Share tree partitions across horizon-specific Brier losses | `8fe82bfd98b7` | loss | moderate | deriv-ticks |
| Evaluate gates through conditional risk–coverage curves | `8d6e0ce2d61e` | selection-gating | moderate | deriv-ticks |
| Benchmark magnitude gates with parsimonious QMLE volatility models | `88ad53cc0d9a` | magnitude | moderate | deriv-ticks |
| Audit entropy features for gaps, stale ticks and resampling artifacts | `8dfa3f360c68` | validation | moderate | deriv-ticks |

The three partial readings are explicitly documented: *Introduction to Data Mining*, *Consistent Causal Inference for High-Dimensional Time Series*, and *Correlation Cleaning and Random Matrices*.

**No direct contradiction of the in-house FX priors emerged.** No document establishes a comparable short-horizon FX direction edge. Useful counterevidence concerns broader assumptions: ensemble diversity does not guarantee calibrated uncertainty, and domain alignment can worsen transfer.
=== ml-stats-foundations__18of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__18of38/records.jsonl). Validation passed: 50 valid JSON records, matching shard order, with exact page-cited quotes for numerical findings.

Relevance counts: **3: 5 · 2: 23 · 1: 19 · 0: 3**. Reading depth: 22 full, 6 partial, 22 triage.

Ten promising levers; evidence supports the method, not an established FX edge:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Anytime-valid win-rate monitoring | `909b76d56536` | validation | strong | deriv-ticks |
| Dependence-aware multiple-testing correction | `91e032c28c91` | validation | strong | deriv-ticks |
| Audit filters for future-data leakage | `93579ff2ac40` | validation | strong | deriv-ticks |
| Pool calibration across pairs and sessions | `922cdd39255e` | calibration | moderate | deriv-ticks |
| catch22 features alongside raw scale | `9260d83697cb` | features | moderate | deriv-ticks |
| Separate distribution body and magnitude tails | `923f3f2a5725` | magnitude | moderate | deriv-ticks |
| Fit forecast pools using proper scores | `974e1e1bbe5c` | ensemble | moderate | deriv-ticks |
| Test isoelastic probability pooling | `915d14f3b414` | ensemble | moderate | deriv-ticks |
| Benchmark frozen TabPFN | `97796b6e6b13` | calibration | moderate | external: checkpoint; Deriv ticks |
| Masked historical-window pretraining | `92330a1e7244` | features | moderate | deriv-ticks |

No files were missing or wholly unreadable. `907df5d5bd6c` contains only a publisher preview. Truncated or sparse extractions affect `905d9ef113c6`, `93579ff2ac40`, `9396f8ed24b3`, and `96f4ae445500`; limitations and selected chapter coverage are recorded.

SAINT and TabPFN challenge a blanket claim that trees always outperform neural models, but neither overturns the in-house FX comparison. Several papers show that calibration or ensemble improvements can worsen other probability scores. Nothing here independently establishes or refutes the reported in-house direction edge; volatility and complexity methods chiefly support magnitude experiments.
=== ml-stats-foundations__19of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__19of38/records.jsonl): **50 records**, in shard order, with verified page quotations.

Relevance counts: **3: 4 · 2: 23 · 1: 18 · 0: 5**. Reading depth: 23 full, 3 partial, 23 triaged, 1 unreadable.

The ten most promising levers are below. Evidence grades concern the method; none establishes a tradable FX edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Payout-aware Rise/Fall/abstain decisions, charging ties | `9f36651fc4d7` | selection-gating | Strong | deriv-ticks |
| Account for correlated CV errors; compare paired losses | `9d9342f8bb5e` | validation | Strong | deriv-ticks |
| Anytime-valid performance monitoring, subject to assumptions | `9d4b3f89835b` | validation | Strong | deriv-ticks |
| Small Brier-trained correctness head | `9baa0c6f3f27` | calibration | Moderate | deriv-ticks |
| Compare ridge with sparse regularization | `9cc66d9b0297` | loss | Moderate | deriv-ticks |
| Reduced-rank pooling across pairs and horizons | `99eea6e33a04` | ensemble | Moderate | deriv-ticks |
| Compact feature selection using distributional loss | `a016ed2ecac2` | features | Moderate | deriv-ticks |
| Strongly shrunk time-varying regression | `9b06afc2ed5f` | regime | Moderate | deriv-ticks |
| Dynamic ensemble selection using matured labels | `9c83fc821ced` | ensemble | Moderate | deriv-ticks |
| Conditional tests for incremental cross-pair information | `a0386c4546f9` | features | Moderate | deriv-ticks |

**Unreadable:** `9bb7d43ab71a`, *Regression Quantiles*. The supplied text contains a cover and linked references, without the article.

**Prior qualification:** `a0c12359e028` challenges the blanket claim that HMMs can predict only magnitude: an HMM can predict asymmetric observable-symbol distributions. It supplies no FX direction evidence. Nothing here validates the earlier in-house performance figures or overturns the trees-versus-deep-nets prior.
=== ml-stats-foundations__20of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__20of38/records.jsonl): **50 valid records in shard order**, with 102 verified quotations and 82 levers.

Relevance counts: **3: 7 · 2: 18 · 1: 23 · 0: 2**.

Ten promising candidates—all use **Deriv ticks only**. Evidence grades reflect the source domain; FX transfer remains unproved.

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Fit preprocessing and selection inside folds | `a37f480901a4` | validation | strong |
| Anytime-valid monitoring of live evidence | `a579ae1e3303` | validation | strong |
| Regularized elastic-net baseline | `a24c0b97235c` | loss | moderate |
| Parameter-sharing TabM ensembles | `a6988aa10d72` | ensemble | moderate |
| Cyclic snapshot averaging | `a2d750f97f39` | ensemble | moderate |
| Robust scaling and smooth clipping | `a4fb4e2cd821` | features | moderate |
| Last-layer Laplace probability correction | `a79243234edc` | calibration | moderate |
| Direct horizon-specific proper losses | `a71bd2ebcb98` | loss | moderate |
| Parsimonious conditional return distributions | `a307be335ade` | calibration | weak |
| Hawkes price-event intensity gate | `a72119448dad` | magnitude | weak |

No unreadable files. Coverage comprises **25 triage, 23 full and 2 partial** records. Partial appendix coverage is explicitly recorded for GNNRank (`a1eef1dcd9a8`) and Better by Default (`a4fb4e2cd821`).

RealMLP and TabM qualify the tree-first prior by showing competitive compact neural models. Nothing here establishes a Deriv direction edge or refutes the caution that activity and complexity statistics chiefly inform move size.
=== ml-stats-foundations__21of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__21of38/records.jsonl): **50 records**, in shard order. Validation passed for JSON, IDs, schema and **94 page-cited quotes**.

Relevance counts: **3: 5 · 2: 22 · 1: 19 · 0: 4**. Depth: 24 full, 23 triage, 3 partial.

The ten most promising levers are below. Evidence concerns the method; FX transfer remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Evaluate actual payout at frozen thresholds | a9454d523efc | validation | strong | deriv-ticks |
| Compare paired losses using time-block uncertainty | b1e6c659370c | validation | moderate | deriv-ticks |
| Stress-test winners by removing influential time blocks | ae9f20722161 | validation | moderate | deriv-ticks |
| Preserve natural prevalence and audit calibration after weighting | a9f578158866 | calibration | moderate | deriv-ticks |
| Shrink ensemble weights toward sparse, nearly equal combinations | aa3af9f55e96 | ensemble | moderate | deriv-ticks |
| Measure member skill and error correlation | aaa9bc464d1d | ensemble | moderate | deriv-ticks |
| Estimate diminishing ensemble benefits before adding members | aec3f5e38bb3 | ensemble | moderate | deriv-ticks |
| Let specialized experts abstain outside their domains | ad3283683544 | selection-gating | moderate | deriv-ticks |
| Use justified temporal randomization and positive permutation p-values | a961e45b7469 | validation | moderate | deriv-ticks |
| Test excursion waiting times as magnitude-gating features | b2573718e706 | magnitude | weak | deriv-ticks |

No document was wholly unreadable. Partial coverage is explicitly recorded for **aa1e5c30eb19**, **ac8437008f6c** and **ae357eaad366**, with omissions identified.

No credible FX result overturns the in-house priors. The main qualifications are that class balancing can harm probability calibration, ensemble benefits have limits, and structured moving-average excursions can arise without return-sign predictability.
=== ml-stats-foundations__22of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__22of38/records.jsonl): **50 records**, with IDs and order verified, valid JSON, and **81 page-cited quotes checked**.

Relevance counts: **3: 7 · 2: 16 · 1: 22 · 0: 5**.

Ten promising levers; evidence describes source support, not demonstrated Deriv profitability:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Selected-trade precision versus coverage | b613c3e135a6 | validation | strong | Deriv ticks |
| Modest CatBoost tuning before architecture expansion | b2c765b3bc4b | validation | moderate | Deriv ticks |
| Joint noncrossing return quantiles | b443d948443a | magnitude | weak | Deriv ticks |
| Learning-rate and seed ensembles | b458ce29bfd3 | ensemble | moderate | Deriv ticks |
| Past-only rolling probability adjustment | baff457a57df | calibration | moderate | Deriv ticks |
| Causal, persistent jump regimes | ba9da410e051 | regime | moderate | Deriv ticks |
| Feature-selection stability across purged periods | bcec268bc792 | validation | moderate | Deriv ticks |
| Simultaneous uncertainty across comparisons | b7abc9e8b126 | validation | moderate | Deriv ticks |
| Causal wavelet-modulus summaries | bc2f041e6bb4 | features | weak | Deriv ticks |
| Dependence-shrinkage volatility baseline | bb7f452b78a3 | magnitude | weak | Deriv ticks |

No document was wholly unreadable. **b62588987090** is partially unreadable because of corrupted text; **bc2f041e6bb4** contains truncated derivations.

No decisive contradiction of the in-house priors emerged. The tabular benchmark shows neural exceptions to tree dominance. The HMM and Kalman trading examples do not establish an out-of-sample FX sign edge; their records flag forward-looking inputs, in-sample results, or selection of parameters using reported results.
=== ml-stats-foundations__23of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__23of38/records.jsonl): **50 records**, validated for JSON, shard order, and page-matched quotations.

Relevance counts: **3: 2 · 2: 21 · 1: 23 · 0: 4**. Reading depth: 21 full, 2 partial, 27 triage. No unreadable documents.

The most promising levers are below. Evidence reflects support in the paper’s original domain; FX transfer remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Learn an explicit abstention output | c681a53e7c90 | selection-gating | moderate | deriv-ticks |
| Sparse ARCH with spaced historical lags | c37c96fb47b2 | magnitude | moderate | deriv-ticks |
| Pool models with penalized pair-specific deviations | c1e7ce310e3e | features | moderate | deriv-ticks |
| Robust covariance and whitening features | c0a0566fdae2 | features | moderate | deriv-ticks |
| Select PCA dimensions using future captured variance | c5a7f1958f56 | validation | moderate | deriv-ticks |
| Calibrate ensemble disagreement and vote summaries | c18fc951c09e | calibration | weak | deriv-ticks |
| Elastic-net and grouped feature penalties | c261d62dab18 | loss | weak | deriv-ticks |
| Separate ranking and probability heads | c82cab225b46 | calibration | weak | deriv-ticks |
| Stress-test regime alarms against volatility-only nulls | c4b934bd9c66 | validation | moderate | deriv-ticks |
| Masked historical-window pretraining | c436706a3445 | loss | weak | deriv-ticks |

No credible result contradicts the in-house FX priors or establishes a profitable direction edge at our horizons. Covariance, ARCH, Hurst, and regime results concern magnitude or estimation. Nonmarket neural-network wins do not overturn the boosted-tree prior; smoothing and continual-learning benefits vary by task.
=== ml-stats-foundations__24of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__24of38/records.jsonl): **50 records**, in shard order.

Relevance counts: **3: 5 · 2: 22 · 1: 18 · 0: 5**. Completed 27 full reviews and 23 triages. No unreadable documents.

The ten most promising levers are below. Evidence describes the source method; FX transfer remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Dependence-aware uncertainty for win rates and model comparisons | c93e71c778d5 | validation | moderate | deriv-ticks |
| Precommitted sequential evidence boundaries | ca2cdac00c33 | validation | moderate | deriv-ticks |
| Monotone calibration using matured, out-of-fold outcomes | cd8f90e84c83 | calibration | moderate | deriv-ticks |
| Average small feature-family models, including a null model | ca3413f52cfe | ensemble | moderate | deriv-ticks |
| Preserve small feature groups during selection | d02fa4d381b7 | features | moderate | deriv-ticks |
| Replay stateful forecasts with historically available labels | d1a5d2609342 | validation | moderate | deriv-ticks |
| Test cross-pair variance information separately from mean information | d28d4e9ace77 | magnitude | moderate | deriv-ticks |
| Pretrain compact encoders on masked historical segments | ceaa1ab1e6fa | features | weak | deriv-ticks |
| Test stable cross-pair error-correction terms | cba7e868c875 | direction | weak | deriv-ticks |
| Test ensemble disagreement as a distribution-shift gate | d1d1ec91b648 | selection-gating | weak | deriv-ticks |

No direct FX result overturns the in-house priors. Nonfinancial Transformer results challenge a universal tree advantage, while ensemble experiments qualify confidence in seed-only uncertainty estimates. The equity paper’s written directional-accuracy formula measures position orientation, so its reported direction results cannot substantiate an edge without clarification.
=== ml-stats-foundations__25of38
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__25of38/records.jsonl): **50 records in shard order**, validated JSON and **86 exact page-cited quotes**.

Relevance counts: **3: 7 · 2: 14 · 1: 25 · 0: 4**. Depth: 16 full reads, 5 partial/chapter-level reads, 29 triages. No unreadable documents.

The ten most promising levers are below. Evidence strength concerns the method; none establishes tradable Deriv FX alpha.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Anytime-valid monitoring of win rates | d783b1200025 | validation | strong | deriv-ticks |
| Correct inference after feature selection | d2c874d5f577 | validation | strong | deriv-ticks |
| Audit stale-price and sampling-induced lead–lag | d3f70950a832 | validation | strong | deriv-ticks |
| Use forward-filtered HMM states | d5cb7e282741 | validation | strong | deriv-ticks |
| Nested temporal selection and untouched final test | da0607a96fa5 | validation | strong | deriv-ticks |
| Evaluate every candidate in shadow mode | d366c2b3e618 | validation | strong | deriv-ticks |
| Detect historical-to-recent feature shift | d4d462745b6d | validation | moderate | deriv-ticks |
| Measure direction, magnitude and calibration separately | d45f69d19e9f | loss | moderate | deriv-ticks |
| Model exact ties and apply tie-loss settlement | d2b19122b5d3 | labels | weak | deriv-ticks |
| Shrinkage-weighted exponential volatility filters | d700de793ec2 | magnitude | weak | deriv-ticks |

No credible empirical result overturns the in-house priors. One theoretical qualification: **d46c570ee4a8** shows conditional directional persistence/reversal in a specified fractional Gaussian model. That challenges a universal “Hurst can never inform sign” assertion, but supplies no FX evidence.

Major caveats recorded include outcome-dependent mixture-component selection in **d7bc95544054**, outcome-revealing retrieval in **d96170dd775e**, and weak absolute calibration baselines in **d8cb0451adeb**.
=== ml-stats-foundations__26of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__26of38/records.jsonl): **50 records**, in shard order. All 87 finding quotes match their cited pages.

Relevance counts: **3: 6 · 2: 15 · 1: 20 · 0: 9**. Reading depth: 19 full, 2 selected-section, 28 triage, 1 unreadable.

The ten most promising levers follow. All use **deriv-ticks**; evidence supports the method, with transfer to Deriv still untested.

| Lever | Document ID | Kind | Evidence | Data |
|---|---|---|---|---|
| Evaluate payout near break-even | e28ce50f3793 | selection-gating | Moderate | deriv-ticks |
| Dependence-aware validation intervals | e0da3adbf6db | validation | Moderate | deriv-ticks |
| Correct dependent multiple comparisons | e01a6c556d0c | validation | Moderate | deriv-ticks |
| Average seeds; stabilize forest probabilities | dcefa0a113c5 | ensemble | Moderate | deriv-ticks |
| Mix fast/slow volatility averages | dde5d5781326 | magnitude | Moderate | deriv-ticks |
| Sparse Lasso baseline | dba187def422 | loss | Moderate | deriv-ticks |
| Smooth confidence-to-win-rate gates | df5d35bd01dd | selection-gating | Moderate | deriv-ticks |
| Balance training across pairs/sessions | df0dcdc762ac | loss | Moderate | deriv-ticks |
| Shrink magnitude histograms toward smooth shapes | e15b79084cfa | magnitude | Moderate | deriv-ticks |
| Compare Brier skill against base rates | da74454fc709 | validation | Moderate | deriv-ticks |

Unreadable: **debb3ab6fb77 — Linear Regression Practice Questions**, because its text path was empty.

Qualified challenges to the priors: NODE beats tuned boosting on several nonfinancial benchmarks, and larger forests can worsen hard accuracy despite improving probability scores. Neither overturns the specific in-house FX findings. No document establishes a tradable Deriv sign edge; the apparent stochastic-path forecasting result supplies future noise, while entropy and coupling results do not demonstrate price-sign prediction.
=== ml-stats-foundations__27of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__27of38/records.jsonl): **50 records**, matching shard order, with 95 verified page quotes and 61 levers.

Relevance counts: **3: 8 · 2: 18 · 1: 19 · 0: 5**. Counts include one unreadable document.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit clock, gaps and settlement labels | e59ebd225de6 | data | moderate | deriv-ticks |
| Block-bootstrap correction across research trials | e5847347b9a1 | validation | strong | deriv-ticks |
| Anytime-valid monitoring of settled performance | eb3efd547349 | validation | strong | deriv-ticks |
| Decompose AUC within and across pairs/regimes | e67e86dfec93 | validation | strong | deriv-ticks |
| Past-only target statistics using matured labels | e682f177e241 | features | moderate | deriv-ticks |
| Separate temperature calibration near payout threshold | e7d0d97d9912 | calibration | moderate | deriv-ticks |
| Standardized sparse logistic benchmark | e8b418db8c20 | loss | moderate | deriv-ticks |
| Constrained stacking from purged predictions | eac6054885b6 | ensemble | moderate | deriv-ticks |
| Shared tree partitions across horizon losses | e354a66d9db1 | loss | moderate | deriv-ticks |
| Account for CV tuning in significance claims | eaf1ea3b01d9 | validation | strong | deriv-ticks |

Evidence describes methodological support, not demonstrated FX profitability.

**Unreadable:** `ed24a597da38`, *Model Quantization Notes*—severely corrupted handwritten OCR.

No direct contradiction of the in-house FX priors emerged. Relevant qualifications: Laplace uncertainty can worsen calibration, strict feature-stability filtering can hurt prediction, and the Hurst study demonstrates exponent estimation only—not return-sign prediction.
=== ml-stats-foundations__28of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__28of38/records.jsonl): **50 records, 80 levers**. Validation passed for JSON parsing, shard order, unique IDs, required fields, and exact page quotations.

Relevance counts: **3: 7 · 2: 17 · 1: 19 · 0: 7**. Coverage: 23 full reads, 26 triages, one partial textbook read covering its complete martingale chapter. **No unreadable documents.**

The ten most promising levers are below. Evidence ratings concern the source mechanism; none establishes profitable FX prediction.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized logistic/ridge baselines | `ede2da1b80f9` | loss | moderate | deriv-ticks |
| Purged out-of-fold stacking | `ede2da1b80f9` | ensemble | moderate | deriv-ticks |
| Shared effects with sparse pair deviations | `f0bc88a0cc26` | loss | moderate | deriv-ticks |
| Efficient MLP ensembles such as TabM | `f300d492cbff` | ensemble | moderate | deriv-ticks |
| Historical nearest-neighbor context | `f336b271ffe3` | regime | moderate | deriv-ticks |
| Proper-score probability training | `f393de472349` | calibration | moderate | deriv-ticks |
| Out-of-fold correctness selector | `f48e5bd888e5` | selection-gating | moderate | deriv-ticks |
| Correlation-aware feature-significance controls | `ef7d8890de58` | validation | strong | deriv-ticks |
| Joint energy/variogram forecast scoring | `f060e4472889` | validation | moderate | deriv-ticks |
| Conditional-null sequential monitoring | `f4389d49e5d7` | validation | strong | deriv-ticks |

Two qualifications to the priors stand out: modern tabular benchmarks challenge universal tree superiority, without overturning the specific in-house FX result. Fractional-Brownian theory permits model-dependent sign predictability, qualifying an absolute “Hurst only predicts size” claim; estimating Hurst on FX does not establish that model. No document verifies the reported in-house direction or magnitude figures.
=== ml-stats-foundations__29of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__29of38/records.jsonl): **50 records**, 100 levers and 99 verified page quotations. JSON, shard order and citation checks pass.

Relevance counts: **3: 4 · 2: 24 · 1: 14 · 0: 8**. None unreadable; two long works received selective reading.

Ten most promising levers follow. Evidence describes the underlying method, not a demonstrated Deriv edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Nested chronological evaluation with purging and dependence gaps | fb52bfeee748 | validation | strong | Deriv ticks |
| Causal TabR retrieval using only matured labels | f6855570a0d9 | direction | weak | Deriv ticks |
| Audit coverage and win rate within selected trades | f796c87f28be | selection-gating | moderate | Deriv ticks |
| Shrink rolling cross-pair covariance estimates | f6a653d3c4ec | features | moderate | Deriv ticks |
| Average predictions across seeds | f6855570a0d9 | ensemble | moderate | Deriv ticks |
| Model terminal absolute returns with conditional mixtures | fa7af105b952 | magnitude | weak | Deriv ticks |
| Estimate convex ensemble weights using joint error covariance | fbc9c4744e72 | ensemble | moderate | Deriv ticks |
| Recalibrate after balancing on natural-prevalence holdouts | f969d1fca7f2 | calibration | moderate | Deriv ticks |
| Separate magnitude-event onset from episode continuation | fbde33fee836 | validation | moderate | Deriv ticks |
| Check whether averaging creates apparent persistence | fc2c0c0f4492 | validation | moderate | Deriv ticks |

No convincing price-only FX result overturns the in-house priors. TabR supports testing retrieval-based deep models alongside trees. The Hurst paper asserts model-conditional sign persistence without an FX direction backtest; the strong oversampling result uses external order-book information.
=== ml-stats-foundations__30of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__30of38/records.jsonl): **50 records**, validated for shard order, JSON/schema, and exact page-cited quotations.

Coverage: relevance **3: 7 · 2: 21 · 1: 18 · 0: 4**. Depth: 12 full reads, 16 partial/selected-section reads, 22 triages.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Adaptive return/magnitude quantiles | fc7ea224d6a9 | magnitude | moderate | deriv-ticks |
| Joint time-block bootstrap across pairs | 008e15e8be04 | validation | strong | deriv-ticks |
| Separate model selection from inference | 089a48a7a3d0 | validation | strong | deriv-ticks |
| E-BH across valid dependent hypotheses | ffe79e5f5eb0 | validation | strong | deriv-ticks |
| Ridge/elastic-net regularisation | 018902e5ac0c | loss | moderate | deriv-ticks |
| Fixed Share predictor aggregation | 0c0678244a56 | ensemble | moderate | deriv-ticks |
| Causally filtered switching regimes | fd9d6c36f9ec | regime | moderate | deriv-ticks |
| Block-shifted shadow-feature screening | 079b8f13b94c | features | moderate | deriv-ticks |
| Shallow, slow-learning boosted trees | 119ead2e73c5 | ensemble | moderate | deriv-ticks |
| ARCH-style magnitude baseline | 0fd5850636cc | magnitude | moderate | deriv-ticks |

Evidence labels describe methodological support, not a demonstrated Deriv trading edge.

No files were missing. **05981e6b7b5c** lacks substantive textbook chapters; **feabe1c33d2f** has corrupted figure text. Other extraction and partial-reading limits are recorded individually.

No robust contradiction of the in-house priors emerged. Long-memory reproduction did not establish useful forecasts, and the daily-stock direction claims relied on thin, reused holdouts.
=== ml-stats-foundations__31of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__31of38/records.jsonl).

Validated all **50 records**: correct shard order, valid JSON, required fields, and exact page-matched quotes.

Relevance: **3: 14 · 2: 20 · 1: 14 · 0: 2**. Coverage: 6 full reads, 28 partial reads, 16 triages.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit entry/expiry label alignment | `31d5e98850db` | labels | strong | deriv-ticks |
| Purged chronological validation | `254738c8763f` | validation | strong | deriv-ticks |
| Separate selection from final evaluation | `1a560401dbad` | validation | strong | deriv-ticks |
| Correct for searched models and gates | `23d0700680c4` | validation | strong | deriv-ticks |
| Partially pool pair calibration | `246f7d34daad` | calibration | moderate | deriv-ticks |
| Calibrated payoff-based abstention | `20355ed64b3d` | selection-gating | moderate | deriv-ticks |
| Less aggressive noisy-label boosting | `1a986e004028` | loss | moderate | deriv-ticks |
| Update ensembles from settled outcomes | `1a986e004028` | ensemble | moderate | deriv-ticks |
| Ridge autoregression for magnitude | `254738c8763f` | magnitude | moderate | deriv-ticks |
| Robust conditional-variance modeling | `20355ed64b3d` | magnitude | weak | deriv-ticks |

These grades describe methodological support, not demonstrated Deriv profitability.

No files were missing. **“Deep Learning” (`1f6f329f9525`) contains only contents and bibliography**, so its substantive chapters could not be read.

No robust empirical result contradicts the in-house priors. Fractional Brownian theory qualifies the blanket Hurst/no-sign claim under assumed nonmartingale dynamics, without establishing an FX edge. The cookbook’s apparent stock-prediction result is compromised by backward target alignment and hard-label scoring.
=== ml-stats-foundations__32of38
Wrote and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__32of38/records.jsonl): **50 records in shard order**, 70 source-matched quotations and 48 levers.

Relevance counts: **3: 5 · 2: 19 · 1: 21 · 0: 5**. Depth: 3 full, 21 partial, 26 triage. No unreadable files; truncated extracts and reading limits are documented.

The ten most promising levers follow. Evidence describes methodological support, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Nested temporal model and gate selection | 3c2de4acd57c | validation | strong | deriv-ticks |
| Temporal-cluster uncertainty estimates | 450b8ecc21e0 | validation | strong | deriv-ticks |
| Partial pooling across pairs and horizons | 54d6bfa8cc4a | calibration | moderate | deriv-ticks |
| Payoff-aware abstention, charging ties | 4ee767e0a6b0 | selection-gating | moderate | deriv-ticks |
| Separate calibration from fitting and testing | 3f87b70c64a3 | calibration | moderate | deriv-ticks |
| Posterior predictive averaging | 54d6bfa8cc4a | ensemble | moderate | deriv-ticks |
| Stable ridge baselines for correlated lags | 3774e13e6ba0 | features | moderate | deriv-ticks |
| Shrunk or low-rank cross-pair covariance | 4e8c5b3684f9 | features | moderate | deriv-ticks |
| Fractional-memory volatility features | 3a28106da8f4 | magnitude | weak | deriv-ticks |
| Robust losses for magnitude estimation | 40d976c83c18 | loss | weak | deriv-ticks |

No direct evidence contradicts the in-house priors. High toy-classification scores and contemporaneous currency fits do not establish future FX direction skill. Information-theoretic and Kalman material supplies no demonstrated sign edge.
=== ml-stats-foundations__33of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__33of38/records.jsonl): **50 records**, validated for JSON, shard order, IDs and verbatim page-cited quotes.

Relevance: **3: 7 · 2: 15 · 1: 23 · 0: 5**. Depth: 9 full, 13 partial, 27 triage, 1 unreadable.

The most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Nested chronological model selection | `5ad0c69c922e` | validation | moderate | deriv-ticks |
| Dependence-aware uncertainty estimates | `6099f99fdf41` | validation | moderate | deriv-ticks |
| Multiplicity and discarded-model ledger | `5595af3416db` | validation | moderate | deriv-ticks |
| Assess probability calibration separately | `5e7840c545d2` | calibration | moderate | deriv-ticks |
| Win-rate bounds against economic break-even | `66238130e84b` | validation | moderate | deriv-ticks |
| Causal filtered volatility states | `6b57f19aedb3` | magnitude | weak | deriv-ticks |
| Conservative regularized baselines | `5ad0c69c922e` | loss | moderate | deriv-ticks |
| Bagged shallow trees or rules | `5ac6adee00a9` | ensemble | weak | deriv-ticks |
| Joint signed-magnitude categories | `64212034d972` | labels | weak | deriv-ticks |
| Concentrate noisy tuning evaluations | `6c1be81cfecf` | validation | moderate | deriv-ticks |

Unreadable: **Numerical Analysis** (`5e55a7c2bf30`), whose text contains only front matter. Incomplete source extracts and partial book coverage are flagged.

No credible contradiction to the in-house priors emerged. The XIV tutorial tentatively favors direction over magnitude, but its tiny, tuned experiment is weak evidence. Ethereum’s headline accuracy concerns price-level forecasts, not binary-contract wins.
=== ml-stats-foundations__34of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__34of38/records.jsonl): **50 records, 49 levers**.

Relevance: **3: 11 · 2: 14 · 1: 22 · 0: 3**. Reading depth: 6 full short documents, 19 partial book/proceedings reviews, 25 triages. Partial scopes are documented. No unreadable files.

All JSON, shard-order, quote-length, exact-quote and numeric-citation checks passed.

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Fit every selection step inside purged folds | `8d098d65cf53` | validation | strong | deriv-ticks |
| Estimate uncertainty with aligned time blocks | `88b4a9946416` | validation | moderate | deriv-ticks |
| Evaluate probabilities with log loss and Brier score | `89749245bc80` | calibration | moderate | deriv-ticks |
| Model rise, fall and ties explicitly | `89749245bc80` | labels | moderate | deriv-ticks |
| Regularize boosting with shrinkage, stopping and subsampling | `8d098d65cf53` | loss | moderate | deriv-ticks |
| Average probabilities rather than hard votes | `8d098d65cf53` | ensemble | moderate | deriv-ticks |
| Fit forecast stacks on historical validation predictions | `7381c92706d1` | ensemble | moderate | deriv-ticks |
| Partially pool parameters across pairs | `89749245bc80` | ensemble | weak | deriv-ticks |
| Correct comparisons across the full model search | `83ab9ec704de` | validation | moderate | deriv-ticks |
| Separate zero/nonzero occurrence from magnitude | `8d098d65cf53` | magnitude | weak | deriv-ticks |

No convincing empirical contradiction of the in-house priors emerged in the reviewed material. Financial examples chiefly concern daily price-level errors, not tradable intraday direction. Proper-scoring theory also cautions that magnitude-weighted training gains do not establish calibrated contract-win probabilities.
=== ml-stats-foundations__35of38
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__35of38/records.jsonl): **50 records**, in shard order.

Relevance: **3: 3 · 2: 20 · 1: 22 · 0: 5**. Depth: 10 full, 13 partial, 27 triage.

The ten most promising levers all use existing **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Preserve an untouched final period | `93316e525a03` | validation | moderate |
| Nest feature selection inside training folds | `998c820f8b9d` | validation | moderate |
| Account for dependence in validation uncertainty | `9ef39f9467d9` | validation | moderate |
| Partially pool subgroup calibration | `a779c2f0c9e3` | calibration | weak |
| Share parameters across related tasks | `93fe92a4ed73` | ensemble | weak |
| Propagate parameter uncertainty into magnitude forecasts | `a779c2f0c9e3` | magnitude | weak |
| Benchmark magnitude gates against ARCH/GARCH | `96d26722a70d` | magnitude | weak |
| Monitor residual drift with CUSUM/EWMA | `9fc3c5109111` | regime | weak |
| Fit sparse classifiers under feature uncertainty | `906c5d087b40` | loss | weak |
| Test clipped covariate-shift weighting | `93316e525a03` | loss | weak |

No files were unreadable. Three book extracts end early; these limitations and selective reading are recorded.

No direct contradiction of the in-house FX results emerged. However, `9d51ea54f134` found alternative losses did **not** significantly improve top-ranked decisions, and `93fe92a4ed73` warns that unrelated tasks can hurt pooled models. No shard result independently validates the reported FX direction edge.
=== ml-stats-foundations__36of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__36of38/records.jsonl): **50 records**, verified JSON, shard order, IDs, and verbatim quotes against cited page markers.

Relevance counts: **3: 4 · 2: 13 · 1: 32 · 0: 1**. Seventeen records document partial book/chapter reading.

The ten most promising levers are below. Evidence grades concern methodological support, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Forward-separated validation | b9452a7e6480 | validation | moderate | Deriv ticks |
| Pool pair/session calibration estimates | b9452a7e6480 | calibration | moderate | Deriv ticks |
| Correct for multiple model searches | b9452a7e6480 | validation | moderate | Deriv ticks |
| Budget error across repeated tests | b2e98af4442a | validation | moderate | Deriv ticks |
| Update Hedge weights after expiry | af7dd519cdf2 | ensemble | moderate | Deriv ticks |
| Compare fixed-share ensemble weighting | b71acb03034d | ensemble | moderate | Deriv ticks |
| Check PIT shape and serial dependence | bd7b26e886df | validation | moderate | Deriv ticks |
| Freeze preprocessing within each fold | bce0fcbefd72 | validation | moderate | Deriv ticks |
| Recalibrate return distributions | bd7b26e886df | calibration | weak | Deriv ticks |
| Pool latent volatility across pairs | c4ff4ece66ae | magnitude | weak | Deriv ticks |

**Unreadable:** `ae3aaf1e8def`, *Cambridge A Level Statistics 1: Topical Past Papers*. Extraction omitted substantive questions and solutions.

No direct contradiction of the in-house FX results emerged. Those results remain unverified here: filtering, spectral structure and regime reconstruction do not establish sign predictability, and most numerical demonstrations concern toy or nonfinancial data.
=== ml-stats-foundations__37of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__37of38/records.jsonl): **50 records**, validated for JSON, shard order, required fields, and verbatim page-cited quotations.

Relevance counts: **3: 8 · 2: 12 · 1: 27 · 0: 3**. Coverage comprises 30 triage records, 19 partial book/chapter reads, and one unreadable document. Extracted 62 findings and 52 levers.

Ten promising levers follow. All use **Deriv ticks**; evidence grades concern the method, not demonstrated trading profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Elastic-net logistic baselines | ca567cf47789 | loss | moderate | Deriv ticks |
| Shared sparse models across pairs | ca567cf47789 | ensemble | weak | Deriv ticks |
| Purged leave-future-out validation | cee61f2bf2ef | validation | strong | Deriv ticks |
| Forward log-loss and Brier scoring | cee61f2bf2ef | calibration | moderate | Deriv ticks |
| Feature selection inside every fold | ca567cf47789 | validation | strong | Deriv ticks |
| Freeze choices before the final test | cc66e666e354 | validation | strong | Deriv ticks |
| Update expert mixtures using matured losses | cef4edfa97a6 | ensemble | moderate | Deriv ticks |
| Causal FD4 volatility diagnostics | c8ba286e7878 | magnitude | weak | Deriv ticks |
| MMD distribution-drift monitoring | d7f38aea7ddc | regime | weak | Deriv ticks |
| Integrate parameter uncertainty into gates | e397a764badb | selection-gating | weak | Deriv ticks |

Unreadable: **c67605bc4455**, *Probabilistic Inference Using Markov Chain Monte Carlo Methods*—corrupted text encoding.

No credible contradiction of the in-house priors emerged. The anthology’s deep-learning superiority claim has weak validation and inconsistent data descriptions. A cookbook’s perfect linear-model score includes the response among its predictors. The Hurst material supports volatility clustering rather than signed-return prediction.
=== ml-stats-foundations__38of38
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/ml-stats-foundations__38of38/records.jsonl): **47 records**, in shard order. JSON parsing, IDs, quote fidelity and numeric citations passed verification.

Relevance counts: **3: 5 · 2: 8 · 1: 31 · 0: 3**. Coverage comprises 34 triage records and 13 explicitly partial book records. No files were missing or unreadable; extraction gaps are noted.

The ten most promising levers are below. All need **`deriv-ticks` only**. Strong evidence here generally supports validation principles, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Group simultaneous pairs and overlapping labels in time-based validation | f185bd18c1a4 | validation | strong |
| Bootstrap synchronized blocks of held-out losses and payoffs | f9606475a0de | validation | strong |
| Repeat model/gate selection inside nested evaluation | f9606475a0de | validation | strong |
| Monitor strategies with conditional no-profit e-processes | f7b503de8218 | validation | strong |
| Control model-search false discoveries with valid e-BH evidence | f7b503de8218 | validation | strong |
| Audit smoothed and hidden-state features for future conditioning | e49dddbf23d8 | validation | strong |
| Select gates using payout utility, calibration and coverage | f59bbfc22d4f | selection-gating | moderate |
| Average calibrated probabilities across seeds/model families | f8237d393163 | ensemble | moderate |
| Pool training across pairs while evaluating target-pair periods | f185bd18c1a4 | ensemble | weak |
| Compare joint conditional mean/scale with separate prediction heads | f8237d393163 | magnitude | weak |

No convincing result contradicts the in-house priors. This shard establishes neither a tradable FX sign edge nor neural superiority over tuned trees. Its HMM and entropy material supplies no demonstrated sign-prediction result.
=== momentum-trend-following__01of03
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/momentum-trend-following__01of03/records.jsonl): **42 records**, verified in shard order. All JSON parses; finding quotes match their cited pages.

Relevance counts: **0: 0 · 1: 19 · 2: 19 · 3: 4**. Completed 23 full reads and 19 triages.

The ten most promising levers are below. Evidence describes the source finding; transfer to Deriv FX remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Reduce redundant indicators to distinct lag-weight shapes | `414473e72c0e` | features | Strong | deriv-ticks |
| Pool normalized features across pairs | `116ee831386f` | features | Moderate | deriv-ticks |
| Shrink fast/slow trend mixtures by correction/rebound state | `3fef67e171ab` | ensemble | Moderate | deriv-ticks |
| Add causal changepoint severity and recency | `2b1906296d29` | regime | Moderate | deriv-ticks |
| Condition momentum on smooth paths versus isolated jumps | `39add97e355b` | features | Moderate | deriv-ticks |
| Test session-opening continuation into later windows | `39add97e355b` | direction | Moderate | deriv-ticks |
| Fit compact nonlinear signed-momentum responses | `2167c5181476` | features | Moderate | deriv-ticks |
| Compare tick-realized and range volatility | `282118f1dbaa` | magnitude | Moderate | deriv-ticks |
| Isolate direction using identical magnitude gates and fixed-sign controls | `16e9b7b79e36` | validation | Strong | deriv-ticks |
| Re-evaluate imported strategies under fixed-expiry binary payoffs | `4445bf71f7ca` | validation | Strong | deriv-ticks |

**Unreadable documents:** none. `2d89f9ff66ec` contains missing figure placeholders, recorded in its notes.

**Tensions with the priors:** LSTM and transformer studies outperform classical strategies, but do not test tuned boosted trees; transformer FX results are considerably weaker than portfolio headlines. `42e8c3c5552f` cites a volatility-to-sign connection, flagged as an unverified reference-level counterclaim. No document establishes a profitable Deriv binary edge, and several demonstrate why portfolio Sharpe or large trend winners cannot establish binary accuracy.
=== momentum-trend-following__02of03
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/momentum-trend-following__02of03/records.jsonl): **42 records**, matching shard order, with 147 findings and 94 levers.

Relevance counts: **3: 8 · 2: 18 · 1: 15 · 0: 1**. Reading depth: 24 full, 2 partial, 16 triage. None unreadable.

The ten most promising levers are below. All need **Deriv ticks only**. “Moderate” describes source support, not validation on Deriv.

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Session-end continuation from elapsed-day returns | `623ba82490ac` | direction | Moderate |
| Time-of-day normalized breakout distance | `865010dfd938` | features | Moderate |
| Fast/slow trend agreement and strength | `519e261c158c` | features | Moderate |
| Sign consistency conditioned on cumulative return | `7202cb813e00` | features | Moderate |
| Regularized logistic momentum baseline | `635da97a5626` | direction | Moderate |
| Nonlinear trend response across lookbacks | `9b40ea4bd160` | direction | Moderate |
| Cross-pair network momentum features | `a375a7370900` | features | Moderate |
| Elapsed-session latent-volatility updates | `8fbd5ea2d54e` | calibration | Moderate |
| Joint bootstrap correction across all strategies tested | `7ec54082a5be` | validation | Moderate |
| Test magnitude gates jointly with direction models | `b13145a7fb78` | selection-gating | Moderate |

The shard broadly supports the size-versus-sign caution. It also challenges assumptions of stable momentum: FX results often weaken, and historical fast-trend performance decays. One study finds deterioration concentrated in large moves, cautioning against assuming magnitude gating or magnitude-weighted losses automatically improve direction.

No document establishes a robust payout-beating, fixed-expiry edge on the target FX contracts. Nothing directly resolves the boosted-tree versus deep-net prior.
=== momentum-trend-following__03of03
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/momentum-trend-following__03of03/records.jsonl): **40 records**, validated for shard order, JSON/schema correctness, and verbatim page-cited quotes.

Relevance counts: **0: 0 · 1: 14 · 2: 19 · 3: 7**. Reading depth: 24 full, 14 triage, 2 partial. Nothing unreadable; partial coverage is documented for the technical-analysis review and moving-average book.

The ten most promising levers below all require only **`deriv-ticks`**. Evidence grades describe source support, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Compact return-filter basis replacing redundant indicators | cd8bf6240f07 | features | moderate |
| Shallow shared models across pairs | da438bab1807 | direction | moderate |
| Auxiliary volatility tasks alongside return learning | ba972a78bee9 | loss | moderate |
| Lagged realized-variance forecasting | dac3efe8a31c | magnitude | moderate |
| Sparse cross-pair momentum features | c2f4fdce8495 | features | moderate |
| Partial pooling with pair-specific baselines | ec8209bd179e | direction | moderate |
| Correct for the complete strategy search | b8d48ad34879 | validation | strong |
| Preserve dependence and audit bootstrap nulls | d14087ac9d9f | validation | strong |
| Charge ties and reproduce settlement endpoints | bc943325781d | labels | strong |
| Separate relative-return profits from absolute sign skill | faa9de99da65 | validation | strong |

**No convincing Deriv-specific contradiction of the in-house priors emerged.** Kalshi continuation evidence weakens on midquotes; shallow-model results support regularisation; volatility-based portfolio improvements do not establish sign prediction. The evolutionary paper’s broad trend-superiority claim rests on an inadequately evaluated, survivor-selected simulation.
=== news-nlp-alt-data__01of11
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__01of11/records.jsonl): **50 records**, validated for shard order, JSON, numerical support, quote lengths and source-page matches.

Relevance counts: **3: 8 · 2: 24 · 1: 15 · 0: 3**. Reading depth: 31 full, 18 triage, one partial. None unreadable; `02dec5dbed1a` received a partial long-document read.

The ten most promising levers are below. Evidence describes methodological support, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Shared cross-pair volatility state | `1536b373fcd4` | magnitude | Moderate | Deriv ticks |
| Retrieve similar historical return windows | `0d50461fa1e6` | regime | Moderate | Deriv ticks |
| Compare Brier loss with cross-entropy | `068b8097bfca` | loss | Moderate | Deriv ticks |
| Dependence-preserving surrogate tests | `04674022933f` | validation | Strong | Deriv ticks |
| Preserve first-seen timestamps and revisions | `0abe9ae3ae4f` | validation | Strong | Deriv ticks |
| Test multiple sampling frames, retaining missing cases | `15cd42fdc4c0` | validation | Strong | Deriv ticks |
| Frozen text embeddings with ridge regression | `000ba42f4131` | features | Moderate | External: timestamped financial text |
| News novelty × observed price reaction | `0a743854ff33` | direction | Moderate | External: news archive |
| Context-aware policy stance features | `11e14be669b6` | features | Moderate | External: central-bank communications |
| Currency-specific impact labels | `134b58f2bb02` | labels | Moderate | External: annotated macro news |

Nothing robustly overturns the in-house price-only priors. Important qualifications: search fear added no future volatility signal after persistence controls; public earnings text explained announcement returns without profitable subsequent trading. Some neural/LLM models beat tree baselines on text or revenue tasks, but those comparisons do not establish superiority for tabular FX prediction.
=== news-nlp-alt-data__02of11
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__02of11/records.jsonl): **50 records**, verified for shard order, JSON validity, schema, verbatim quotes and numerical citations.

Relevance counts: **3: 6 · 2: 28 · 1: 15 · 0: 1**. Reading depth: 33 full, one thesis with relevant-section coverage, 16 triage. No unreadable documents.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized temperature/intercept calibration | `15cd4367a89b` | calibration | Moderate | Deriv ticks |
| Model return tails separately from direction | `17c68646ee2b` | magnitude | Moderate | Deriv ticks |
| Small training-only feature perturbations | `209a46b2ecae` | features | Weak | Deriv ticks |
| Pool pairs with pair identifiers | `22c1701216dd` | ensemble | Weak | Deriv ticks |
| Seasonal, guarded volatility-anomaly scores | `2b28feff466e` | magnitude | Weak | Deriv ticks |
| Separate news coverage, neutrality and polarity | `1bba428e2222` | features | Moderate | External: timestamped news |
| Condition sentiment on the exact currency pair | `2553726d337d` | features | Moderate | External: FX headlines |
| Compact, regularized supervised news scores | `2986a88dfe3c` | features | Moderate | External: archived news |
| Correct dependent tests across pairs and lags | `2986a88dfe3c` | validation | Moderate | Deriv ticks |
| Compare models using identical frozen feature panels | `2cb9fa6f4ebe` | validation | Moderate | Deriv ticks |

Evidence grades describe source support, not demonstrated Deriv profitability.

**No convincing contradiction to the in-house priors.** Strong-looking direction claims often depend on same-day alignment, price-level metrics, weak splits or selected episodes. The transfer-entropy evidence does not independently establish sign prediction. Several papers reinforce compact models, separate magnitude targets and careful validation.
=== news-nlp-alt-data__03of11
Created [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__03of11/records.jsonl): **50 validated records**, 69 levers and 130 page-cited findings.

Relevance counts: **3: 7 · 2: 32 · 1: 9 · 0: 2**. Coverage: **12 full, 27 partial, 11 triage**. No unreadable files. **The full-reading requirement remains incomplete for the 27 partial records.**

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale variance, jumps and quarticity | `479ed603188d` | magnitude | Moderate | Deriv ticks |
| Average complementary magnitude forecasts | `479ed603188d` | ensemble | Moderate | Deriv ticks |
| Evaluate calibration near the trade threshold | `44bc861d92c2` | calibration | Moderate | Deriv ticks |
| Compact probability bottlenecks for fusion | `4725b9af1e8b` | ensemble | Weak | Deriv ticks |
| Pool pairs; test negative transfer | `4a8983c81d14` | ensemble | Weak | Deriv ticks |
| Fit representations strictly historically | `45e3a4c92d37` | validation | Moderate | Deriv ticks |
| Use historically bounded news encoders | `303833a86996` | validation | Moderate | External: news/checkpoints |
| Condition magnitude on preannouncement attention | `3437ef0aff98` | magnitude | Moderate | External: clickstream/calendar |
| Model speech surprises and speaker identity | `452bbf557e36` | magnitude | Moderate | External: speeches/forecast vintages |
| Encode asset-specific economic sentiment | `3af495cbb846` | features | Weak | External: timestamped news |

No persuasive contradiction of the in-house priors emerged. Large direction claims generally involve external data, longer horizons, selected outcomes or weak validation. The strongest volatility study finds news-only models lose to price-history benchmarks, while combinations improve them.
=== news-nlp-alt-data__04of11
Saved and validated all **50 records** in [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__04of11/records.jsonl). IDs match shard order; all findings’ quotes match their cited pages and satisfy the word limit.

Relevance counts: **3: 12 · 2: 23 · 1: 13 · 0: 2**.

Ten promising levers; evidence refers to the original study’s task, not demonstrated Deriv performance:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Retain stable feature effects across periods/pairs | `515d7e5a8ed5` | features | Moderate | Deriv ticks |
| Select probabilities with proper scores and reliability checks | `584d70a8b232` | calibration | Moderate | Deriv ticks |
| Tune gates against contract payoff and coverage | `600040b5e5f0` | selection-gating | Moderate | Deriv ticks |
| Independently train experts; learn gate from out-of-fold errors | `4bed60431502` | ensemble | Weak | Deriv ticks |
| Benchmark strongly regularized simple models | `4b9fcc1e3ecc` | validation | Moderate | Deriv ticks |
| Add auxiliary move-presence supervision | `63a21afabff9` | loss | Weak | Deriv ticks |
| Preserve publication/receipt times and revisions | `58a9759a05f2` | data | Strong | External data vintages |
| Weight sentiment by observed readership | `5e9a616a67aa` | direction | Moderate | External news/clicks |
| Separate attention from sentiment | `5690eed1c9ed` | features | Moderate | External social text/counts |
| Separate geopolitical threats from realized acts | `61b51d1133e0` | magnitude | Moderate | External news indices |

No document was wholly unreadable. Long paper `52bf2f8611aa` was partially read; extraction gaps elsewhere are noted.

**No robust contradiction of the in-house priors emerged.** Several impressive direction claims rely on in-sample fitting, sentiment-label accuracy, majority-class effects or problematic timing. None establishes a tradable Deriv edge.
=== news-nlp-alt-data__05of11
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__05of11/records.jsonl): **50 records**, in shard order. Validation passed for JSON, IDs, schema and **142 page-cited quotes**.

Relevance counts: **3: 7 · 2: 30 · 1: 11 · 0: 2**. Completed 37 full readings and 13 triages; none unreadable. Image-only limitations are noted in the records.

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Test the entire selection pipeline against placebos | `66086a16902a` | validation | moderate | deriv-ticks |
| Hold out periods; refit transformations within folds | `7668b190b3ea` | validation | moderate | deriv-ticks |
| Benchmark regularized linear models | `681bb6add392` | features | moderate | deriv-ticks |
| Use multiscale realized volatility for magnitude | `6a5457610c50` | magnitude | moderate | deriv-ticks |
| Evaluate Brier scores and conditional reliability | `6795ee8618e0` | calibration | moderate | deriv-ticks |
| Separate first mentions from repetition | `7668b190b3ea` | features | moderate | external: timestamped news |
| Estimate horizon-specific continuation/reversal | `71c7a2473391` | direction | moderate | external: sentiment |
| Preserve negation, speculation and attribution | `6e0129387497` | features | moderate | external: annotated news |
| Track story novelty and independent confirmations | `7945e1856315` | features | weak | external: news provenance |
| Separate global, country and related-market news | `8037f427f64e` | features | moderate | external: relevant news |

These grades concern the source evidence; none establishes a Deriv FX edge.

**No credible contradiction of the in-house priors emerged.** Attention evidence favors magnitude over direction. Apparent strong directional results have unclear holdouts, timing problems or explicit label-leakage concerns. Simple models remain competitive.
=== news-nlp-alt-data__06of11
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__06of11/records.jsonl): **50 records**, in shard order. Validation passed for JSON, schema, exact quotes, pages and numeric support.

Relevance counts: **3: 9 · 2: 18 · 1: 18 · 0: 5**. Read fully: 27; triaged: 23. No unreadable documents.

The ten most promising test candidates are below. Evidence grades describe the source evidence; transfer to Deriv remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Benchmark SVR/GARCH magnitude gates | `9b271813636d` | magnitude | Moderate | Deriv ticks |
| Compare signed-return regression with classification | `843df34c84b9` | loss | Moderate | Deriv ticks |
| Pool regularized models across pairs | `843df34c84b9` | ensemble | Weak | Deriv ticks |
| Regularize session-specific responses | `9ac5796c2952` | regime | Weak | Deriv ticks |
| Test cross-pair shock propagation | `938c935c88cd` | magnitude | Weak | Deriv ticks |
| Run clock and lag/lead placebos | `93be4f0ef03b` | validation | Moderate | Deriv ticks |
| Freeze graphs before each test period | `938c935c88cd` | validation | Moderate | Deriv ticks |
| Fit simple heads on frozen news embeddings | `843df34c84b9` | features | Moderate | External: timestamped news |
| Separate first alerts from duplicate updates | `843df34c84b9` | data | Moderate | External: timestamped news |
| Preserve separate macroeconomic sentiment aspects | `9a46e5c7167c` | features | Weak | External: central-bank releases |

No credible result overturns the magnitude-versus-sign prior or establishes a tradable Deriv direction edge. Neural heads outperform some simpler heads in `843df34c84b9`, qualifying any universal preference for trees, but tuned boosted trees were not tested. Several papers also show that lower regression error or better sentiment classification need not improve direction.

Source limitations are recorded: missing extracted equations/figure values in `948edc2b9e55`, and an unavailable supplementary appendix in `9ac5796c2952`.
=== news-nlp-alt-data__07of11
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__07of11/records.jsonl): **50 records**, in shard order. JSON, schemas and all 132 finding quotes passed validation.

Relevance counts: **3: 8 · 2: 28 · 1: 11 · 0: 3**. Reading depth: 35 full, 14 triage, 1 partial.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Group-regularized cross-pair lags | `a612106974da` | features | moderate | deriv-ticks |
| Joint horizon and abstention selection | `a829ecec93df` | selection-gating | moderate | deriv-ticks |
| Activity-transition training filter | `a8dd01b90a3b` | selection-gating | weak | deriv-ticks |
| Low-parameter score calibration | `9fb07bc114f5` | calibration | weak | deriv-ticks |
| Auxiliary direction/magnitude training | `a37108470ea0` | loss | weak | deriv-ticks |
| Structured event and numerical roles | `a37108470ea0` | features | moderate | external: timestamped news |
| Separate numerical/narrative decay | `a829ecec93df` | features | moderate | external: news and macro surprises |
| Financial-domain sentiment vocabulary | `9d631018cf48` | features | moderate | external: financial text |
| Source-composition adjustment | `a612106974da` | features | moderate | external: source-tagged news |
| Immutable historical event snapshots | `adb692ad935c` | validation | strong | external: versioned event arrivals |

Evidence grades concern the documented mechanism; transfers to Deriv remain unproven.

No supplied file was unreadable. **`ab55c8df5895` contained only a catalog abstract**, so the underlying paper could not be assessed.

There is **no convincing contradiction of the in-house priors**. Simpler predictors remain competitive, and state models do not demonstrate sign prediction. Several large direction claims suffer from tiny tests, timing leakage or inconsistent metrics. No document establishes a Deriv payout edge.
=== news-nlp-alt-data__08of11
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__08of11/records.jsonl): **50 records**, with IDs/order, JSON, schema and page-cited quotations validated.

Relevance: **3: 3 · 2: 22 · 1: 22 · 0: 3**. Read fully: 25; triaged: 25. Unreadable: none.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool multiscale return features across pairs | bbd55d51b6b1 | features | Moderate | Deriv ticks |
| Compare sparse and dense shrinkage | b77b816b0ded | features | Moderate | Deriv ticks |
| Purge labels unavailable at forecast time | bc556c6fcc6c | validation | Moderate | Deriv ticks |
| Select gates using payout, ties and coverage | ba9fd39f7853 | selection-gating | Moderate | Deriv ticks |
| Measure incremental skill within regimes | ba9fd39f7853 | validation | Moderate | Deriv ticks |
| Check calibration at the trading threshold | ba9fd39f7853 | calibration | Moderate | Deriv ticks |
| Measure residual dependence before ensembling | aff61020f2bf | ensemble | Moderate | Deriv ticks |
| Compare pooled and pair-specific magnitude models | bc556c6fcc6c | magnitude | Moderate | Deriv ticks |
| Measure news novelty against prior related stories | b48ca4a6ce1f | features | Moderate | External: timestamped news |
| Measure policy surprise against prior expectations | af853b338081 | features | Weak | External: statements and prior news |

Evidence grades describe source support; transfer to our FX task remains untested.

No clean short-horizon FX result contradicts the in-house priors. However, one news-model voting ensemble produced no improvement, challenging automatic assumptions about ensemble gains. Several impressive “direction” results instead measure sentiment classification or relative stock rankings; others use future inputs or test-set tuning. Topic and Kalman results principally concern magnitude.
=== news-nlp-alt-data__09of11
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__09of11/records.jsonl): **50 records**, validated for JSON, shard order, schema and exact page-cited numerical quotes.

Relevance: **3: 10 · 2: 24 · 1: 11 · 0: 5**. Reading depth: 33 full, one partial thesis, 16 triage. No unreadable documents.

The ten most promising tests follow. Evidence grades describe the recorded mechanism or validation lesson, not a proven Deriv edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Joint horizon-magnitude and local-volatility targets | cb8cae7cbaa7 | loss | moderate | Deriv ticks |
| Combine small volatility regressions | d2b99540be3c | ensemble | moderate | Deriv ticks |
| Semivariance, jump and multiscale variation features | d2b99540be3c | magnitude | moderate | Deriv ticks |
| Keep every outcome; learn an observable magnitude gate | c8647cf7469e | validation | strong | Deriv ticks |
| Compare models across prespecified seeds | d42ef270055f | validation | strong | Deriv ticks |
| Pool pairs through a small currency-exposure graph | c8647cf7469e | ensemble | weak | Deriv ticks |
| Select models using binary-payout utility | c7f4b3b2982b | validation | moderate | Deriv ticks |
| Freeze features before an untouched calendar period | c861aca9486f | validation | strong | Deriv ticks |
| Add macro-topic attention and sentiment | d2b99540be3c | magnitude | moderate | External: timestamped news/social text |
| Test fresh, fundamental-topic news signals | c92a3694db77 | direction | weak | External: point-in-time news |

No convincing contradiction of the magnitude-over-sign prior emerged: the news-network entropy result predicts volatility stress and is entirely in-sample. Some neural models beat tree baselines on other assets, qualifying the tree prior, but mismatched features, timing concerns and thin validation prevent a strong conclusion for our FX contracts. No study establishes the required Deriv win rate.
=== news-nlp-alt-data__10of11
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__10of11/records.jsonl): **50 records in shard order**, all validated.

| Relevance | Documents |
|---|---:|
| 3 — direct | 6 |
| 2 — transferable | 27 |
| 1 — tangential | 11 |
| 0 — irrelevant | 6 |

**33 full reads, 17 triages; none unreadable or partial.** Records contain 90 levers and 132 verified page-cited quotations.

The ten most promising levers:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Proper scores against causal base rates | `e5f27881d19d` | validation | Strong | deriv-ticks |
| Affine-logit probability calibration | `e5f27881d19d` | calibration | Moderate | deriv-ticks |
| Contract-exact settlement labels | `e44c457dd546` | labels | Moderate | deriv-ticks |
| Strong nonlinear price-only benchmarks | `e828488e5a0e` | validation | Moderate | deriv-ticks |
| Evaluate gating at the payout threshold | `e828488e5a0e` | selection-gating | Moderate | deriv-ticks |
| Heavy-tailed magnitude baselines | `dd11eddddb54` | magnitude | Moderate | deriv-ticks |
| Block-bootstrap model confidence sets | `dd11eddddb54` | validation | Moderate | deriv-ticks |
| Shared training across magnitude horizons | `de0a3c42eae4` | loss | Moderate | deriv-ticks |
| Return-supervised sparse sentiment | `e1c47b1a7962` | features | Moderate | external: timestamped news |
| News novelty versus repeated coverage | `e1c47b1a7962` | selection-gating | Moderate | external: historical news text |

No robust result directly contradicts the in-house FX priors. SSESTM provides credible external-news equity return evidence, but FX transfer remains unproven. Other findings generally support strong price baselines, magnitude forecasting and calibration; several headline direction claims weaken under timing, leakage or target-definition scrutiny.
=== news-nlp-alt-data__11of11
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/news-nlp-alt-data__11of11/records.jsonl): **42 records**, in shard order, with **124 verified page quotes** and **63 levers**.

Relevance counts: **3: 8 · 2: 17 · 1: 12 · 0: 5**. No unreadable documents. Book `4fe3950a7644` is marked partial; three relevant chapters were read completely.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Absolute-return gates using recent moves and clock features | `f656a5dd49fd` | magnitude | Moderate | deriv-ticks |
| Multiscale variance, semivariance and jump features | `4fe3950a7644` | magnitude | Moderate | deriv-ticks |
| Purge overlapping labels; fit transforms only on past observations | `4fe3950a7644` | validation | Strong | deriv-ticks |
| Stress measured latency and next-tick entry | `e9f23e25f5f3` | validation | Strong | deriv-ticks |
| Replace realized-move filtering with an ex-ante gate | `eda5e35bcecc` | validation | Strong | deriv-ticks |
| Shared classifier with compact pair embeddings | `fb6e876dd80e` | features | Weak | deriv-ticks |
| Joint direction and magnitude prediction heads | `f9273d692d7c` | loss | Weak | deriv-ticks |
| Retain a bounded replay sample of earlier regimes | `f05a333fa6c4` | regime | Weak | deriv-ticks |
| Preserve numerical units, signs and relative magnitudes | `f9273d692d7c` | features | Moderate | external: timestamped macro/FX text |
| Test news attention and topic innovation for magnitude gating | `4fe3950a7644` | magnitude | Moderate | external: point-in-time news |

Strong validation evidence concerns evaluation design, not a demonstrated FX edge.

There is **no robust contradiction** of the magnitude-over-sign or tree-baseline priors. NumHTML reports direction improvements from an auxiliary volatility loss, but uses external earnings-call data and a single split. Several apparent direction successes instead use future information, contemporaneous classification, or filtering on realized moves; these weaknesses are recorded explicitly.
=== portfolio-construction-risk__01of08
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__01of08/records.jsonl): **84 records**, in shard order. All JSON and 121 page-cited quotes passed validation.

Relevance counts: **3: 9 · 2: 24 · 1: 50 · 0: 1**.

**Reading remains incomplete:** 15 full reads, 18 relevant partial reads and 51 triages. The `depth`, `pages_read` and `notes` fields identify the gaps.

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Exact settlement and tie-loss labels | `0a0713d60228` | labels | strong | deriv-ticks |
| Matured-residual quantile calibration | `0a0713d60228` | calibration | moderate | deriv-ticks |
| Quantile forests for magnitude | `189071c0e185` | magnitude | moderate | deriv-ticks |
| Pooled multiscale HAR baseline | `1bd829b5af07` | magnitude | moderate | deriv-ticks |
| OHLC/realized-variance innovations | `157f75f74eba` | magnitude | moderate | deriv-ticks |
| Evaluate regimes with deployment delay | `141e48bd5cca` | validation | strong | deriv-ticks |
| Separate model selection from evaluation | `088f38edbe86` | validation | strong | deriv-ticks |
| Block-bootstrap payoff gate selection | `23216395e5c8` | selection-gating | moderate | deriv-ticks |
| Shrink covariance and ensemble weights | `188bc22d3ef1` | ensemble | moderate | deriv-ticks |
| Seasonality-preserving surrogate controls | `21dd6db5c48c` | validation | moderate | deriv-ticks |

Evidence grades concern the documented mechanism, not demonstrated Deriv profitability.

No document was wholly unreadable. Course Slides (`02ee54b20867`) supplies only pages 1–400 against 1,264 catalogued; some extracted tables remain garbled.

No credible contradiction of the size-versus-sign or boosted-tree priors emerged. Currency volatility targeting showed negligible Sharpe improvement; conformal average coverage could coexist with clustered failures. No validated comparable short-horizon FX direction edge was established.
=== portfolio-construction-risk__02of08
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__02of08/records.jsonl): **84 records**, in shard order. JSON, IDs, quotation wording, page citations and numeric-field support all validate.

Relevance counts: **3: 8 · 2: 20 · 1: 52 · 0: 4**.

Reading depth is incomplete: **11 full, 17 partial, 56 triage**, with many triages based on excerpts. No files were unreadable.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Parsimonious HAR volatility baseline | `43776ac440c7` | magnitude | moderate | deriv-ticks |
| Shrink noisy cross-pair covariance | `2861aac6a002` | features | moderate | deriv-ticks |
| Next-period whitening diagnostics | `3dd688b149e9` | validation | moderate | deriv-ticks |
| Calendar/dependence-aware sample size | `38092d9cfe40` | validation | moderate | deriv-ticks |
| Tail-aware ensemble shrinkage | `462752491d4f` | ensemble | moderate | deriv-ticks |
| Causal regime targets plus boosted trees | `3001ae9c1be6` | regime | moderate | deriv-ticks |
| Uncertainty-aware payout gating | `4277698b87d2` | selection-gating | weak | deriv-ticks |
| Exit-time and price-staleness features | `2953cb6fbe29` | magnitude | weak | deriv-ticks |
| Fast/slow volatility disagreement | `4637c01fc5d4` | magnitude | weak | deriv-ticks |
| Dependent model-confidence comparisons | `43776ac440c7` | validation | moderate | deriv-ticks |

No robust contradiction of the in-house priors emerged from the material read. Apparent counterexamples weaken under inspection: crash precursors are retrospective, the Sortino paper injects predictive accuracy, and transient-factor return reconstruction uses other assets’ contemporaneous future returns. The strongest transferable evidence concerns magnitude, regularization and evaluation—not an established FX sign edge.
=== portfolio-construction-risk__03of08
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__03of08/records.jsonl): **84 records**, validated for JSON, shard order, schema and exact page-quote matches.

Relevance counts: **0: 3 · 1: 40 · 2: 32 · 3: 9**. Reading depth: 38 full, 3 partial, 43 triage. None unreadable.

The ten most promising transfer tests are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool normalized magnitude dynamics across pairs | 4f2f9d2e790d | magnitude | strong | deriv-ticks |
| Use a compact multiscale EWMA variance bank | 4f2f9d2e790d | features | strong | deriv-ticks |
| Add causal cross-pair volatility factors | 4f2f9d2e790d | magnitude | moderate | deriv-ticks |
| Fit simple HAR quantile baselines | 61ef78bb1926 | magnitude | moderate | deriv-ticks |
| Test positive/negative semivariances separately | 61ef78bb1926 | features | moderate | deriv-ticks |
| Tune volatility scaling of calibration residuals | 58fe5b66b9f5 | calibration | moderate | deriv-ticks |
| Evaluate calibration separately during stress | 58fe5b66b9f5 | validation | strong | deriv-ticks |
| Constrain ensemble weights and gross exposure | 637401f826c0 | ensemble | moderate | deriv-ticks |
| Require magnitude gates to improve binary payout utility | 5f82689700a3 | selection-gating | strong | deriv-ticks |
| Account for overlapping outcomes in inference | 61ef78bb1926 | validation | strong | deriv-ticks |

Evidence grades concern the source settings; Deriv intraday transfer remains untested.

The main challenge to the in-house priors concerns **automatic gains from volatility timing and adaptive combinations**: historical improvements often disappear under causal evaluation. The LSTM paper offers weak contrary evidence on model choice, with substantial methodological gaps. Nothing convincingly refutes the reported in-house AUCs or establishes a tick-only FX direction edge.
=== portfolio-construction-risk__04of08
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__04of08/records.jsonl). Verified **84 records**, shard order, valid JSON, required fields, and every finding’s quote against its cited page.

Relevance counts: **3: 4 · 2: 34 · 1: 42 · 0: 4**.

Ten most promising levers—all usable with **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Shrunk cross-pair lagged-return prediction | `81d519d3b311` | direction | moderate |
| Realized-volatility conditional quantiles | `7cda46b2f4a8` | magnitude | moderate |
| Hierarchical pooling across pairs | `7297f72d617c` | calibration | moderate |
| Group-favoring forecast-combination weights | `86128bb6f250` | ensemble | moderate |
| Ridge weights centered on equal averaging | `704cbcf46258` | ensemble | moderate |
| Adaptive volatility HMM | `721477da0c8b` | magnitude | moderate |
| Variance aggregated over actual expiry | `6f963f3733dd` | magnitude | moderate |
| Chronological Brier scores and reliability curves | `725a64022381` | calibration | moderate |
| Precision-weighted versus magnitude-weighted losses | `7e3308500222` | loss | moderate |
| Causal pre-averaged volatility features | `81760e4af78a` | magnitude | moderate |

None provides direct evidence of profitability for our FX binary contracts.

No document was wholly unreadable. Six records explicitly report partial depth: damaged extraction in `6e3d35829064`, `6fcaefb3243a`, `82c8adc89c71`; selected or incomplete sections in `721477da0c8b`, `741831da870b`, `8491fd5cab30`.

The main challenges to the in-house priors are qualified: `7e3308500222` motivates precision weighting, which may conflict with magnitude-weighted losses; `82842bd7e9e7` claims Hurst-based crash anticipation, but its selected episode does not establish sign prediction. The Kalman paper assumes predictive drift rather than demonstrating it.
=== portfolio-construction-risk__05of08
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__05of08/records.jsonl): **84 records**, verified for JSON validity, shard order, schema, and exact page-cited quotations.

Relevance counts: **3: 4 · 2: 20 · 1: 59 · 0: 1**. Reading depth: 21 full, 60 triage, 3 partial.

The ten most promising levers all need only **deriv-ticks**:

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| Multiscale EWMA variance | `a9418fdfb8e9` | magnitude | moderate |
| Absolute-return realized variation | `91597ef13a90` | magnitude | moderate |
| Training-only UTC seasonality adjustment | `a9418fdfb8e9` | features | moderate |
| Filtered cross-pair correlations | `89af5932b449` | magnitude | moderate |
| Pooled return factors | `97d7d95219e7` | features | moderate |
| Standardized-residual tail calibration | `a9418fdfb8e9` | calibration | moderate |
| Causal smoothing of magnitude gates | `9355d5b10c01` | selection-gating | moderate |
| Nested chronological model selection | `a093fdaea1d0` | validation | moderate |
| Timestamp and staleness audits | `9ae51e8f9bbf` | validation | moderate |
| Regularized low-order path signatures | `a30d9df769c5` | features | weak |

No files were wholly unreadable. Three long documents remain explicitly partial: *Quantitative Risk Management* (`97d7d95219e7`), *RiskMetrics Technical Document* (`9ae51e8f9bbf`), and *Risk Management & Trading Psychology* (`a7ccf74c421d`). OCR limitations are recorded.

**No reliable contradiction of the in-house priors emerged.** Magnitude evidence is stronger than sign evidence. Apparent crypto order-flow and HMM counterclaims lack sufficiently clean forward-sign validation; no reviewed result establishes the required binary-contract win rate.
=== portfolio-construction-risk__06of08
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__06of08/records.jsonl): **84 records in shard order**, with JSON, schema, and source quote/page checks passed.

Relevance counts: **3: 6 · 2: 34 · 1: 42 · 0: 2**.  
Depth: **40 full reads, 44 triages**. Unreadable documents: **none**.

Ten most promising levers:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Purge overlapping labels; fit transforms within temporal folds | b04c86f6ff4b | validation | moderate | deriv-ticks |
| Multiscale HAR magnitude baseline | adcd1aa1ff17 | magnitude | moderate | deriv-ticks |
| FACI/SF-OGD magnitude-quantile calibration | b5a311079af7 | calibration | moderate | deriv-ticks |
| Check conditional coverage, sharpness and violation clustering | b5a311079af7 | validation | strong | deriv-ticks |
| Adapt calibration windows using bootstrap stability | ba4ba0e7396b | regime | moderate | deriv-ticks |
| Block-bootstrap the complete fitting and selection pipeline | bae5a45f111c | validation | moderate | deriv-ticks |
| Shrink ensemble covariance and weights | b47f53be6ce3 | ensemble | moderate | deriv-ticks |
| Robust quantile scale and cross-scatter features | c047a5454459 | features | moderate | deriv-ticks |
| Shrink forecasts using parameter-estimation uncertainty | c3fb0b9f9d6e | calibration | moderate | deriv-ticks |
| Sequential predictive-likelihood model averaging | b3d69bf97d91 | ensemble | moderate | deriv-ticks |

No clear, credible contradiction of the in-house priors emerged. Several papers reinforce the distinction between predicting magnitude and predicting sign. Better volatility forecasts do not consistently improve trading utility; `bf0310297247` qualifies broad volatility-timing claims. The “directional accuracy” in `c65e90fd13a1` concerns volatility changes, not price direction. None establishes the reported in-house FX win-rate edge on Deriv.
=== portfolio-construction-risk__07of08
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__07of08/records.jsonl): **84 records**, containing **73 levers**.

Documents by relevance: **3: 11 · 2: 26 · 1: 45 · 0: 2**.

The ten most promising levers all use existing Deriv ticks:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Score-weighted multiscale covariance ensemble | e08d08edd7f9 | ensemble | moderate | deriv-ticks |
| Parsimonious multiscale realized-volatility model | de17ea082129 | magnitude | moderate | deriv-ticks |
| Online ensemble across lookback lengths | dcf65099c1d2 | ensemble | moderate | deriv-ticks |
| Realized-GARCH threshold probabilities | e873a95efb4d | magnitude | moderate | deriv-ticks |
| Shrink stakes with probability uncertainty | cc8f11450c45 | sizing | moderate | deriv-ticks |
| Reconcile univariate and cross-pair variance forecasts | d21778acc958 | ensemble | moderate | deriv-ticks |
| Noise-aware variance scoring with QLIKE | d21778acc958 | validation | strong | deriv-ticks |
| Persistence-matched placebo features | daf42f60f27e | validation | strong | deriv-ticks |
| Block-bootstrap simultaneous model comparisons | c90e0d2a5b5b | validation | moderate | deriv-ticks |
| Check conformal coverage after selection | e5be418e49dd | validation | moderate | deriv-ticks |

No document was wholly unreadable. Two records are partial: **d21778acc958** omits repetitive supplement tables; **ea1d9b71674f** has damaged methodology extraction and omits bulk taxonomy appendices.

No convincing contradiction of the in-house priors emerged. Evidence favors magnitude and dependence modeling over sign prediction. Conformal selection guarantees and stop-loss profitability require particular caution.
=== portfolio-construction-risk__08of08
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/portfolio-construction-risk__08of08/records.jsonl). Verified 80 records in shard order, valid JSON, and 92 verbatim page quotations.

Relevance counts: **3: 8 · 2: 24 · 1: 47 · 0: 1**. Coverage: **13 full, 19 partial, 48 triage**. Partial records identify reading gaps.

The strongest candidates are below. Strong evidence concerns validation principles; predictive transfers remain untested on Deriv.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Share estimates across neighboring regimes | `47a2740b0fac` | regime | moderate | deriv-ticks |
| Shrink ensemble weights toward equal weights | `ffc0bf5ae43b` | ensemble | moderate | deriv-ticks |
| Pool fast and slow volatility distributions | `f00fd2afd422` | ensemble | moderate | deriv-ticks |
| Adapt volatility windows using homogeneity tests | `1ddd9b38d900` | regime | moderate | deriv-ticks |
| Separate observation noise from price innovations | `f9348c93af65` | magnitude | moderate | deriv-ticks |
| Shrink cross-pair/error covariance | `efcb8ee1365d` | features | moderate | deriv-ticks |
| Check quantiles and predictive-distribution calibration | `f400813efc72` | calibration | strong | deriv-ticks |
| Test clustering of magnitude-forecast failures | `cf322edc4af2` | calibration | strong | deriv-ticks |
| Audit regime correlations against selection-induced changes | `f70113bb0713` | validation | strong | deriv-ticks |
| Track research trials and reserve untouched periods | `976deb3a9f33` | validation | strong | deriv-ticks |

No file was wholly unreadable. Extracts `2c5169d5169b` and `976deb3a9f33` end before their advertised contents finish.

The Hurst-as-sign claim in `1ddd9b38d900` conflicts with the supplied prior, but rests on a retrospective selected-spread illustration. No convincing evidence found overturns the in-house priors.
=== practitioner-guides__01of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__01of07/records.jsonl): **86 records**, in shard order. JSON, IDs, quote lengths, page citations and numerical coverage checks passed.

Relevance: **0: 0 · 1: 39 · 2: 37 · 3: 10**. No unreadable files; ten long documents have explicitly marked partial reads.

The ten most promising candidates all use **`deriv-ticks`**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Multi-scale ATR features | `107279612dc9` | magnitude | moderate |
| Nested chronological optimization | `1af353520295` | validation | moderate |
| Feature-prefix invariance checks | `269d38a1579b` | validation | moderate |
| Deterministic entry/expiry replay | `2d9b08b924c2` | validation | moderate |
| Realized-probability/Brier ledger | `020ae81d72a4` | calibration | weak |
| Return distribution to binary probabilities | `118b106de2de` | calibration | weak |
| Model-disagreement abstention gate | `118b106de2de` | selection-gating | weak |
| Continuous candle geometry | `295bbcf6bea7` | features | weak |
| Prior-extrema sweep and reentry | `19ddae22dcda` | direction | weak |
| Regularized rolling ensemble weights | `020ae81d72a4` | ensemble | weak |

**No robust evidence contradicts the FX priors.** A weather transformer beats XGBoost on one test set, but that does not establish the FX ranking. High directional hit-rate claims are poorly validated; ATR-to-sign claims are unsupported. One Ichimoku presentation explicitly discourages intraday use.
=== practitioner-guides__02of07
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__02of07/records.jsonl): **86 records**, matching shard order, with exact quotes and page references checked.

Readable documents: relevance **3: 14; 2: 33; 1: 37; 0: 0**. Depth: 38 full, 9 partial, 37 triaged.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Purged, embargoed period validation | `5cb208ef911e` | validation | moderate | deriv-ticks |
| Complete trial ledger and independent replication | `38ddbf7e705d` | validation | moderate | deriv-ticks |
| As-of reads and future-data injection checks | `426a7dd1aad8` | validation | moderate | deriv-ticks |
| Predictive-spread recalibration | `3e4bb2ce4f38` | calibration | moderate | deriv-ticks |
| Volatility-compression magnitude features | `3dcc1663329b` | magnitude | weak | deriv-ticks |
| ATR-contraction Keltner reentry | `357d4350d5ac` | direction | weak | deriv-ticks |
| Common-currency residual features | `4edc5b52d177` | features | weak | deriv-ticks |
| Tabular entry meta-filter | `419cc9ea2f22` | selection-gating | weak | deriv-ticks |
| Ensemble-disagreement abstention | `3e1526f3b4ae` | selection-gating | weak | deriv-ticks |
| Session-extreme sweep and reclaim | `51f087f16021` | direction | weak | deriv-ticks |

Unreadable because the shard supplied no text path:

- `47842ef0917a` — *Foundational Candlesticks*
- `4b01f75c1cdc` — *Will ETH H1 Trading Strategy*

No credible result overturns the in-house priors. Several guides claim directional order-flow skill or high hit rates, but provide no controlled evidence. No shard document establishes the reported FX AUC levels or a tree-versus-deep-network advantage.
=== practitioner-guides__03of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__03of07/records.jsonl): **86 records**, in shard order. All JSON, schema and citation checks passed: **186 verified quotations**, **211 levers**.

Read/triaged by relevance: **3: 14 · 2: 30 · 1: 41 · 0: 0**. Four large compilations were partially read and explicitly marked.

Most promising candidates; none has strong trading evidence here:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiple-testing controls and block-bootstrap uncertainty | `61a429aab687` | validation | moderate | Deriv ticks |
| Gap-aware replay and exact tie handling | `7c85b491c77e` | labels | moderate | Deriv ticks |
| Separate up/down calibration audits | `8155d203349d` | calibration | moderate | Deriv ticks |
| Uncertainty-discounted payout gating | `8155d203349d` | selection-gating | moderate | Deriv ticks |
| Low-parameter models and stable parameter plateaus | `682f2f6bd82d` | validation | moderate | Deriv ticks |
| Intrabar paths hidden by coarse OHLC | `63d3a6aa33ec` | features | weak | Deriv ticks |
| Moving-average compression before expansion | `7f2506fde5c2` | magnitude | weak | Deriv ticks |
| ATR scaling and magnitude prediction | `8802cb7e0668` | magnitude | weak | Deriv ticks |
| Currency-normalized cross-pair agreement | `62531fa3717d` | selection-gating | weak | Deriv ticks |
| Currency-specific release-time features | `8bfa8d408551` | magnitude | weak | **External:** historical release calendar |

**Unreadable:** `6728dfb12bf2`, *Ichimoku Buy and Sell Rules*—the shard supplies an empty text path. Its provisional relevance is 2.

Partial compilations: `682f2f6bd82d`, `6ff0c32c04ac`, `70d82a00bbad`, `754aba5fd0f3`.

**Contradictions:** No credible empirical evidence overturns the in-house priors. Several sources claim directional value from Hurst, order flow or ATR without validating sign prediction; these are flagged. Large win-rate and return claims were promotional, anecdotal, seeded or hypothetical. Every evaluated document received grade **C or D**.
=== practitioner-guides__04of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__04of07/records.jsonl).

Verified **86 ordered records**, valid JSON, matching IDs, and exact source quotations for all 42 numerical findings.

Read **84 documents**: relevance **3: 17**, **2: 36**, **1: 31**. Five long documents are marked partial. Two unreadable entries are provisionally relevance 0.

The ten most promising levers are hypotheses or validation improvements; none has strong predictive evidence here.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit all clocks against UTC | `a7a8d643234d` | validation | moderate | deriv-ticks |
| Deterministic replay with explicit gaps | `9a8a131598b1` | validation | moderate | deriv-ticks |
| Freeze discovered cohorts; test fresh periods | `a394998827d1` | validation | moderate | deriv-ticks |
| Require lower-confidence-bound net expectancy | `a394998827d1` | validation | moderate | deriv-ticks |
| Calibrate using previously resolved labels | `ad0ffdf4d1b3` | calibration | weak | deriv-ticks |
| Compare volatility across timescales | `a7c371699483` | magnitude | weak | deriv-ticks |
| Test contraction followed by channel expansion | `b0dfb848592f` | magnitude | weak | deriv-ticks |
| Test USD-oriented cross-pair agreement | `97c0c2e4fadb` | features | weak | deriv-ticks |
| Compare regularized signal ensembles | `b41154d632ec` | ensemble | weak | deriv-ticks |
| Use compact candle geometry with trend context | `b425ae6ff744` | features | weak | deriv-ticks |

Unreadable because no text path was supplied:

- `9e88b7c99836` — *RSI BTC M15 Trading Strategy*
- `b4a6e229eaf9` — *Candlestick Charts: Open, High, Low and Close*

**No credible contradiction of the in-house priors emerged.** Large accuracy and fractal/order-flow direction claims lack adequate validation. No source supplies a convincing tree-versus-deep-net comparison. The guides also contradict one another about whether repeated support/resistance tests strengthen or weaken a level.
=== practitioner-guides__05of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__05of07/records.jsonl): **86 records**, verified JSON, shard order and exact page-quoted citations.

Relevance: **3: 15 · 2: 27 · 1: 44 · 0: 0**. Depth: 31 full, 11 partial, 43 triage, 1 unreadable. Recorded 125 levers.

The most promising tests are below. All have **weak evidence in this shard**.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Match labels to actual settlement and losing ties | c2c53595acaa | labels | weak | deriv-ticks |
| Use completed higher-timeframe bars | cf3ecba16f4b | validation | weak | deriv-ticks |
| Delay fractal features until confirmation | dd11c86c4b91 | validation | weak | deriv-ticks |
| Calibrate probabilities separately by event/side | bca11082ab82 | calibration | weak | deriv-ticks |
| Limit redundant features and inspect parameter stability | cea084b76426 | validation | weak | deriv-ticks |
| Preserve synchronized tapes and detect gaps/duplicates | c8b212a32d3f | data | weak | deriv-ticks |
| Benchmark parsimonious GARCH magnitude forecasts | ed65984798ad | magnitude | weak | deriv-ticks |
| Test narrow-range states for subsequent expansion | c536888d3fd8 | magnitude | weak | deriv-ticks |
| Test currency-oriented cross-pair agreement | e477072f9a16 | features | weak | deriv-ticks |
| Test confirmed pin bars at relevant expiries | d06efe7d97eb | direction | weak | deriv-ticks |

**Unreadable:** `eb4ae622f15d` contains figure titles and boilerplate, but lacks the actual charts/explanations. `db0ec904c1a6` is partly corrupted and was read partially.

**Contradictions with in-house priors:** none supported by credible empirical evidence. Exceptional directional-accuracy claims are untested. The compression material explicitly cautions that its statistic alone does not identify direction. No controlled boosted-tree versus deep-net comparison appears here.
=== practitioner-guides__06of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__06of07/records.jsonl): **86 records**, validated for shard order, JSON parsing and exact finding quotations.

Relevance: **3: 32 · 2: 27 · 1: 27 · 0: 0**. Reading depth: 9 full, 50 partial, 27 triage. No files were missing or wholly unreadable; partial coverage and OCR limitations are recorded.

Ten most promising levers—all require only **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Repeat complete strategy searches under null simulations | `1066318fd294` | validation | moderate |
| Nest training-window and refit selection | `22655b4ea37e` | validation | moderate |
| Require stability around nearby parameters | `22655b4ea37e` | validation | moderate |
| Delay fractals until confirming bars arrive | `5f49f4286d07` | validation | moderate |
| Aggregate bars using UTC feed timestamps | `710308479e24` | validation | moderate |
| Audit explicitly future forecast targets | `673942ac04ef` | labels | moderate |
| Separate terminal direction from barrier hits | `61a22389f33f` | labels | moderate |
| Encode causal congestion and immediate failures | `3f2854d39951` | features | weak |
| Test compression for magnitude expansion | `61a22389f33f` | magnitude | weak |
| Combine diverse signals with shrinkage | `1bc54915eb27` | ensemble | weak |

No credible contradiction of the in-house priors emerged. High directional-success claims generally lacked independent validation or measured different outcomes. The shard also contains conflicting RSI advice, reinforcing the need to test market and horizon transfer.
=== practitioner-guides__07of07
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/practitioner-guides__07of07/records.jsonl): **85 valid records in shard order**. All **105 quotes**, including numerical findings, match their cited source pages.

Relevance counts: **3: 37 · 2: 38 · 1: 9 · 0: 1**. Reading depth: **3 full, 72 partial, 9 triage, 1 unreadable**; the full-reading requirement remains incomplete for the partial records.

The strongest candidates to test are below. All use **Deriv ticks**; none establishes a Deriv edge.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Meta-label a fixed baseline strategy | `7e90505b44e3` | selection-gating | Weak | Deriv ticks |
| Normalize compression within each pair | `dd00c4664e0b` | regime | Weak | Deriv ticks |
| Test impulse–pullback continuation | `dd00c4664e0b` | direction | Moderate, daily | Deriv ticks |
| Condition magnitude gates on session | `a4ae98ac4bdf` | selection-gating | Weak | Deriv ticks |
| Encode confirmed failed breakouts | `7228d507e0d7` | direction | Weak | Deriv ticks |
| Test relative-currency momentum | `d2031023e348` | features | Weak | Deriv ticks |
| Delay pivots until confirmation | `73fa0d71197f` | validation | Moderate | Deriv ticks |
| Preserve an untouched final holdout | `cef68ed59b07` | validation | Moderate | Deriv ticks |
| Compare chart effects with random nulls | `dd00c4664e0b` | validation | Moderate | Deriv ticks |
| Require stability across nearby parameters | `e56dd94b53eb` | validation | Moderate | Deriv ticks |

Unreadable: `aa5ca797f5fd`—no text path supplied. `7e90505b44e3` becomes heavily corrupted after its readable prefaces; other incomplete extracts are flagged individually.

No credible result overturns the in-house priors. Grimes reports conditional daily continuation tendencies, with material validation limitations, and finds no special predictive role for Fibonacci ratios or particular moving-average levels. Promotional accuracy claims remain unverified; no convincing boosted-tree versus deep-network comparison emerged.
=== prediction-markets__01of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__01of10/records.jsonl): **48 records**, in shard order. JSON, IDs, quote wording, quote lengths and numerical citations pass validation.

Relevance counts: **3: 5 · 2: 11 · 1: 29 · 0: 3**. Depth: 14 full, 31 triage, 2 partial, 1 unreadable.

The ten most promising transfers all use **Deriv ticks**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Validate exact settlement and losing-tie labels | `1a5cacd76887` | labels | moderate |
| Score actual trade selections separately | `1a5cacd76887` | validation | moderate |
| Freeze policies before fresh chronological tests | `1a5cacd76887` | validation | moderate |
| Remove best clusters to test concentration | `1a5cacd76887` | validation | moderate |
| Calibrate for the deployment selection | `1a5cacd76887` | calibration | moderate |
| Enforce coherent magnitude-threshold probabilities | `147b147530e4` | calibration | weak |
| Check magnitude distributions with randomized PIT | `2338e93b9d05` | calibration | moderate |
| Model volatility-normalized cross-pair innovations | `1f93e695f3e0` | features | weak |
| Compare regularized geometric and arithmetic pools | `2321ff89d2b7` | ensemble | weak |
| Use proper probability losses alongside payout evaluation | `1eacd1c1eda9` | loss | moderate |

**Reading limits:** `24135e1624e6` contains only a publisher preview; the paper’s body is unavailable. `07af7c113ef5` and `2321ff89d2b7` have partial records: main text read, technical appendices omitted.

Nothing directly refutes the supplied FX AUC or tree-versus-deep-net priors. The strongest counterevidence concerns calibration: `brti-edge` reports that recalibration and heavy tails failed to rescue selected-trade skill. Its crypto contract results do not transfer directly to Deriv’s fresh-entry, point-settled contracts.
=== prediction-markets__02of10
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__02of10/records.jsonl): **48 records**, in shard order, with **94 page-verified findings**.

Relevance counts: **3: 7 · 2: 21 · 1: 17 · 0: 3**. Reading depth: 26 full, 20 triaged, 2 partial.

The ten most promising transferable levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale absolute-return features | `36cf15c446ab` | magnitude | Moderate | Deriv ticks |
| Normalize returns using past-only local scale | `36cf15c446ab` | features | Moderate | Deriv ticks |
| Horizon-specific calibration pooled across pairs | `2d2ac6268e27` | calibration | Moderate | Deriv ticks |
| Coherent up/down/tie and magnitude probabilities | `264d724c845a` | calibration | Moderate | Deriv ticks |
| Shrink flexible predictions toward a strong baseline | `30a6c7bb40b9` | ensemble | Moderate | Deriv ticks |
| Include parameter uncertainty in magnitude gates | `2e45e1644019` | selection-gating | Moderate | Deriv ticks |
| Audit magnitude-weighted loss against unweighted calibration | `325da737fc43` | loss | Moderate | Deriv ticks |
| Joint time-block resampling across pairs | `2d2ac6268e27` | validation | Strong | Deriv ticks |
| Select models using repeated held-out periods | `325da737fc43` | validation | Strong | Deriv ticks |
| Compare Brier skill, reliability and discrimination separately | `3cd04fe85095` | validation | Moderate | Deriv ticks |

Evidence strength concerns the mechanism; none establishes a profitable Deriv FX direction edge.

No files were wholly unreadable. `2a99f58cf3fd` was read selectively as a long thesis. `39d9d965474d` contains only a publisher preview; its article body and results tables are unavailable.

No reliable contradiction to the magnitude-versus-sign prior emerged. `36cf15c446ab` supports that distinction. `325da737fc43` qualifies the weighted-loss prior: outcome-dependent weighting can distort probability targets, requiring separate calibration checks. No meaningful deep-net versus boosted-tree comparison appeared.
=== prediction-markets__03of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__03of10/records.jsonl): **48 records in shard order**, with valid JSON and verified page-matched quotes.

Relevance counts: **3: 10 · 2: 14 · 1: 23 · 0: 1**. Depth: 21 full, 3 partial, 22 triage, 2 unreadable.

The ten most promising levers are below. Evidence grades concern the recorded mechanism; FX transfer remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Adaptive convex forecast weights | `529361df8746` | ensemble | moderate | deriv-ticks |
| Variance normalization plus residual GARCH | `4e5c354b4e5f` | magnitude | moderate | deriv-ticks |
| Exact feed, entry, expiry and tie labels | `4f982f3b7958` | labels | strong | deriv-ticks |
| Past-only model and calibration fitting | `4ae328f77d2f` | validation | strong | deriv-ticks |
| Dependence-aware inference for overlapping outcomes | `457f86eee631` | validation | strong | deriv-ticks |
| Calibration checks near trading thresholds | `457f86eee631` | calibration | moderate | deriv-ticks |
| Regularized offset-probit recalibration | `42da8e595729` | calibration | weak | deriv-ticks |
| Coherent direction/magnitude threshold forecasts | `486083e3ca03` | labels | weak | deriv-ticks |
| Cross-pair shock-response gaps | `4fc5367e0e29` | direction | weak | deriv-ticks |
| Availability-aware ensemble corrections | `529361df8746` | ensemble | moderate | deriv-ticks |

Unusable body OCR prevented substantive reading of `4157a2730764` (Shuugi.in election experiment) and `4f4f0e3ce077` (Prediction Markets and the Location of Bias). Abstract-, preview- and README-only limitations are flagged in the records; the duplicate pricing package is identified.

**No document directly refutes the in-house FX estimates.** The volatility paper supports the magnitude/sign distinction. OpenMarket and the NBA study show that apparent predictive strength or midpoint drift can disappear after execution costs. The election-overreaction thesis recommends reversal trading despite explicitly not testing reversals.
=== prediction-markets__04of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__04of10/records.jsonl): **48 records in shard order**, with **101 page-exact quotations** checked.

Relevance counts: **3: 15 · 2: 11 · 1: 21 · 0: 1**.

Ten promising levers—all usable with `deriv-ticks`; evidence grades do not establish FX profitability:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Preserve exact settlement ticks, ties and label provenance | `6b8e110135b1` | labels | strong |
| Measure uncertainty by independent expiry blocks | `59cb79593a86` | validation | strong |
| Check predictions remain unchanged when future rows change | `69976ae7f859` | validation | moderate |
| Gate on calibrated expected payout after losses and ties | `584e2378c28f` | selection-gating | moderate |
| Fit horizon-specific calibration intercepts and slopes | `6b679e2230b4` | calibration | moderate |
| Preserve proper-score error magnitudes during training | `58f9afb5650e` | loss | moderate |
| Train return distributions with CRPS or ranked probability scores | `601bc7ef4aee` | loss | moderate |
| Monitor ensemble weight concentration and correlated errors | `6f81fa835f79` | ensemble | moderate |
| Compare adaptive weights against fixed, regularized weights | `6d26814b8f59` | ensemble | moderate |
| Test likelihood-triggered volatility resets | `6bbb19982993` | regime | weak |

None were unreadable. Two long documents received selected-section readings, recorded as partial: `5dc7e9b48622` and `6ce74dd84344`.

No convincing evidence overturns the in-house FX priors. Short-horizon reversal findings concern other market structures. The shard cautions that adaptive weighting can hurt under noisy outcomes and that calibration corrections vary by venue and horizon.
=== prediction-markets__05of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__05of10/records.jsonl): **48 records**, in shard order. Validation checked JSON, schema, and all **108 page-cited finding quotes**.

Relevance counts: **3: 10 · 2: 15 · 1: 23 · 0: 0**.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized horizon-specific calibration | `839c60d1480b` | calibration | Moderate | Deriv ticks |
| Calendar-block inference across pairs | `8e5e7ff849ee` | validation | Moderate | Deriv ticks |
| Audit timestamps and aggregation conventions | `8533d736079a` | validation | Moderate | Deriv ticks |
| HAR-style multiscale magnitude baseline | `8188a9671b92` | magnitude | Moderate | Deriv ticks |
| Assess reliability and resolution separately | `8e5e7ff849ee` | calibration | Moderate | Deriv ticks |
| Payout-aware abstention thresholds | `7e6e87aff81c` | selection-gating | Moderate | Deriv ticks |
| Explicit tie-state settlement labels | `84f937727c76` | labels | Moderate | Deriv ticks |
| Require incremental ensemble improvement | `8a409fa16bc4` | ensemble | Moderate | Deriv ticks |
| Shared-dollar factor and pair residuals | `871fe4564463` | features | Weak | Deriv ticks |
| Macro-odds repricing for magnitude | `8188a9671b92` | magnitude | Moderate | External: Kalshi odds/volume |

Evidence grades concern transfer rationale; none establishes Deriv FX alpha.

Unreadable: `7b3bd1ddd09f` has severely corrupted OCR. Incomplete sources: `7750f9962d5f` lacks its article body; `8188a9671b92` has corrupted sections.

Nothing convincingly overturns the in-house priors. Tree baselines receive support. High near-expiry crypto accuracy uses partly elapsed return windows and does not demonstrate fresh-entry direction skill.
=== prediction-markets__06of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__06of10/records.jsonl): **48 records**, validated for JSON, shard order, schema, exact quotes, pages, and numeric support.

Relevance counts: **3: 10 · 2: 16 · 1: 18 · 0: 4**. Recorded 65 testable levers.

The 10 most promising tests are below. Evidence grades describe the source evidence, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Partially pooled pair/horizon calibration | a4d8d2de341a | calibration | moderate | deriv-ticks |
| Shrink common-currency and model-error dependence | 98b8a530f9bf | ensemble | moderate | deriv-ticks |
| Fit a single logit-pooling parameter | 9baa7651603f | calibration | weak | deriv-ticks |
| Benchmark magnitude against past-volatility distributions | 9ac9ef6f5b2a | magnitude | weak | deriv-ticks |
| Stress-test causal cross-pair synchronization | a4902793cf55 | validation | moderate | deriv-ticks |
| Gate on conservative win-probability bounds | 985eb0e2dee0 | selection-gating | weak | deriv-ticks |
| Enforce direction/tie/magnitude probability coherence | 9b55dcf818ff | calibration | weak | deriv-ticks |
| Maintain a prospective entry/expiry/payout ledger | 9346bc149de6 | validation | moderate | deriv-ticks |
| Require incremental value over calibrated baselines | 9416eb6bc798 | validation | moderate | deriv-ticks |
| Test event-result surprises as FX predictors | 9c660b2adaf1 | direction | weak | external: announcements, priors, betting quotes, timestamps |

**Unavailable body:** a0b09aa37563, *Participating in a Climate Prediction Market Increases Concern about Global Warming*, contains a publisher preview only. The long ML thesis was selectively read and marked partial.

No robust result contradicts the price-only FX priors. The Brexit paper claims directional opportunities using external information, but its hedge uses future endpoint calibration. The switching-volatility paper supports the magnitude/sign distinction. Complex aggregation also shows weak gains against simpler pooling.
=== prediction-markets__07of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__07of10/records.jsonl). All 48 records validate, match shard order, and include verified page quotes for numerical findings.

Relevance: **3: 7 · 2: 13 · 1: 27 · 0: 1**. Reading depth: 16 full, 4 partial, 28 triaged.

| Promising lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Parsimonious probit/logit calibration | b56b6bf2208d | calibration | Moderate | Deriv ticks |
| Equal-weight model-family ensembles | c27568ad76da | ensemble | Moderate | Deriv ticks |
| Shrink lagged cross-pair covariance | a8b1b709ec3b | features | Moderate | Deriv ticks |
| Trailing-volatility magnitude baseline | a6c4141f8326 | magnitude | Weak | Deriv ticks |
| Conditional return CDF with tie mass | b85528e63ba1 | calibration | Weak | Deriv ticks |
| Uncertainty-adjusted minimum-edge gate | b0f9adce206c | selection-gating | Weak | Deriv ticks |
| Replay policies against frozen forecasts | b438166573da | validation | Moderate | Deriv ticks |
| Calibration uncertainty by independent blocks | bf8c235264a4 | validation | Moderate | Deriv ticks |
| Audit feature and label availability times | c42821d96d31 | labels | Moderate | Deriv ticks |
| Cross-pair dispersion magnitude gate | c540f9739f1e | magnitude | Weak | Deriv ticks |

No supplied file was unreadable. Full paper text was absent for **aa37d7edbb59**, **bc2599c16ac1**, and **bd82c45ef913**; their records identify the limited material available.

Nothing robustly overturns the in-house FX priors. Relevant cautions: additional calibration sometimes fails to improve held-out scores, edge-proportional sizing can worsen returns, and prediction-market profits frequently reflect execution advantages rather than direction forecasting.
=== prediction-markets__08of10
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__08of10/records.jsonl): **48 records**, in shard order. JSON, IDs and all 55 numerical findings’ page-cited quotes pass validation.

Relevance counts: **3: 10 · 2: 16 · 1: 20 · 0: 2**. Depth: 26 full reads, 21 triages, one unreadable main text.

Ten promising levers follow. Evidence grades concern the source setting, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Compare time-block/event weighting with clustered uncertainty | c7c51e2e0f05 | validation | strong | deriv-ticks |
| Compare horizons on common cohorts using exact expiry payoffs | c7c51e2e0f05 | validation | strong | deriv-ticks |
| Use proper log/Brier losses | c7a0d161851c | loss | moderate | deriv-ticks |
| Test multiscale absolute/squared returns for magnitude | d48e17e1661c | magnitude | moderate | deriv-ticks |
| Select compact feature groups by incremental held-out log score | d0280897c168 | features | weak | deriv-ticks |
| Derive direction and magnitude from one coherent return CDF | ccf14b1ed829 | labels | weak | deriv-ticks |
| Test regularized probit-shift calibration | d896ec700d42 | calibration | moderate | deriv-ticks |
| Pool calibration across pairs/horizons with shrinkage | d896ec700d42 | calibration | weak | deriv-ticks |
| Compare robust log-odds pooling with probability averaging | d672a32153dd | ensemble | weak | deriv-ticks |
| Test event-probability changes and release surprises | d79bd9f3b6d1 | features | moderate | external: event probabilities, consensus and releases |

Unreadable main text: **d794a2325250**, *Decentralized Prediction Market Without Arbiters*—only a publisher preview was supplied.

No credible result contradicts the weak-direction/strong-magnitude or tree-model priors. Ensemble disagreement is not reliably equivalent to outcome uncertainty. The CPI paper **d9114530957d** contains incompatible outcome tables; its claimed calibration bias should not become a trading rule.
=== prediction-markets__09of10
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__09of10/records.jsonl). Validated all 48 records, shard order, JSON, and 81 page-cited findings.

Relevance: **3: 11 · 2: 11 · 1: 26 · 0: 0**.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Reproduce entry, expiry and tie-loss labels exactly | dc8f2c792b3b | labels | strong | Deriv ticks |
| Cluster uncertainty by time and currency exposure | dc37afff36f0 | validation | strong | Deriv ticks |
| Fit preprocessing exclusively within training periods | e7198dbfa4c0 | validation | strong | Deriv ticks |
| Regularize calibration by pair, session and volatility | e0ab9c286dc0 | calibration | moderate | Deriv ticks |
| Shrink sparse estimates toward pooled priors | dfa8a8d7bfc8 | calibration | moderate | Deriv ticks |
| Weight ensembles using only matured outcomes | e86dcf281e9a | ensemble | moderate | Deriv ticks |
| Learn whether probabilities need shrinking or extremizing | e86dcf281e9a | calibration | moderate | Deriv ticks |
| Gate on calibrated confidence and model disagreement | e490d0c54582 | selection-gating | moderate | Deriv ticks |
| Check calibration within the selected trading subset | e55925f89c41 | calibration | moderate | Deriv ticks |
| Enforce monotone magnitude-threshold probabilities | ea3a1fdc4a5e | magnitude | moderate | Deriv ticks |

Evidence grades concern these methods; none establishes a Deriv FX direction edge.

No files were missing. Full articles were absent from the supplied extracts for **e255a7e840f9, e45571cc8317 and eec9e3b3d378**. The long **e99ba3701337** received selective chapter reading; limitations are recorded.

No direct contradiction of the in-house FX AUC or tree-versus-network priors emerged. **ea88f3ce379d** reports conditional direction continuation from signed trades, qualifying the blanket order-flow claim, but requires unavailable external data and does not establish net FX profitability.
=== prediction-markets__10of10
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/prediction-markets__10of10/records.jsonl): **43 records**, correct shard order, valid JSON, and verified page-matched quotations.

Relevance counts: **3: 11 · 2: 10 · 1: 19 · 0: 3**. Level 1 includes one unreadable body. No evaluation earned grade A.

Ten leading levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pooled boosted return quantiles | fc70e8ea9707 | magnitude | moderate | Deriv ticks |
| Past-only conformal calibration and quantile repair | fc70e8ea9707 | calibration | moderate | Deriv ticks |
| Explicit zero-return probability and tie losses | fc70e8ea9707 | labels | moderate | Deriv ticks |
| Audit outcome-weighted losses | f6f4fcdd534c | loss | moderate | Deriv ticks |
| Evaluate first threshold crossings | f7fa45f06e9c | selection-gating | moderate | Deriv ticks |
| Purged future-period and held-pair tests | fc70e8ea9707 | validation | moderate | Deriv ticks |
| Stress clock alignment and stale-price effects | fc7d827da7c6 | validation | moderate | Deriv ticks |
| Shrink logistic forecast stacking | fe19f96c2cee | ensemble | moderate | Deriv ticks |
| Firth logistic regression for sparse exceedances | f0a7711ab1c0 | loss | weak | Deriv ticks |
| Pre-release implied-dispersion magnitude gate | f0a7711ab1c0 | magnitude | weak | External: Kalshi ladders, release timestamps, consensus |

**Reading limitations:** `fed58f427c79` has corrupted Chinese OCR. `f3fe21c7e19f` remains partial, with its proof appendix unfinished. The two long works were read by relevant chapter.

**Challenges to the priors:** signed skilled-trader flow predicts event direction in `f1be2c8e391f`, using external data and random splits. `f6f4fcdd534c` cautions that weighted scoring and extremization can distort calibration. Neither establishes a tick-only FX direction edge meeting Deriv’s payout threshold.
=== reinforcement-learning-trading__01of05
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/reinforcement-learning-trading__01of05/records.jsonl): **45 records in shard order**, 121 verified page-cited quotes, and 79 levers.

Relevance counts: **3: 10 · 2: 23 · 1: 12 · 0: 0**. Reading depth: 32 full, one partial thesis, 12 triaged. No unreadable documents. Thesis `24f1359643f4` covers relevant chapters; omissions are documented.

The ten most promising transfer candidates are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Adapt expert weights using settled outcomes | `2db9ff85672f` | ensemble | moderate | deriv-ticks |
| Weight training toward larger absolute returns | `1d78e8b53218` | loss | moderate | deriv-ticks |
| Reject unfamiliar feature states before trading | `0e25cb3b9da5` | selection-gating | moderate | deriv-ticks |
| Stack cross-fitted direction and magnitude forecasts | `0c1f8704e3e8` | ensemble | moderate | deriv-ticks |
| Pool pair histories in a compact shared model | `32e3da042aa2` | ensemble | moderate | deriv-ticks |
| Prefer additive, low-dimensional feature groups | `1f653c9b625f` | features | moderate | deriv-ticks |
| Measure performance decay since fitting | `28bac43b974c` | validation | moderate | deriv-ticks |
| Add causal price-event histories with elapsed time | `34583d6b7f58` | features | weak | deriv-ticks |
| Freeze development before an untouched final period | `36b8f6784661` | validation | moderate | deriv-ticks |
| Test lagged sentiment beyond price-history controls | `3791fe9a350b` | features | moderate | external: timestamped news and sentiment |

No convincing contradiction overturns the in-house priors. Apparent strong direction results concern crypto or weakly validated trading policies; simulated regime gains often assume conditional drift. Several studies support compact models. None establishes a deployable fixed-expiry Deriv FX edge.
=== reinforcement-learning-trading__02of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/reinforcement-learning-trading__02of05/records.jsonl): **45 records**, in shard order. Validation passed, including 110 exact page-cited quotations.

Relevance counts: **3: 12 · 2: 20 · 1: 13 · 0: 0**. Reading depth: **26 full, 13 triage, six partial**. No unreadable files. Partial readings are explicitly marked: `3cbdcb812d2d`, `4c764e9e6880`, `4e51ac6c2451`, `56c29a77e990`, `676613ba3077`, `6781e2dcbd1c`.

The ten most promising experiments follow. **All require only `deriv-ticks`**; evidence grades describe support for testing the idea, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Shared direction and magnitude heads | `605c75b2c404` | magnitude | Moderate |
| Volatility-normalized pooled features | `5738aaa63252` | features | Moderate |
| Conditional return quantiles | `539f3c0b0100` | magnitude | Weak |
| Online expert weighting | `51179782ebed` | ensemble | Weak |
| Recency-weighted retraining | `4f0ea4bac868` | regime | Weak |
| Shared cross-pair representations | `537b6a388c72` | features | Weak |
| Uniform replay versus hard-example weighting | `6828bcc85355` | loss | Moderate |
| Explicit expected-payout abstention | `6828bcc85355` | selection-gating | Moderate |
| Cross-fitted forecasts for downstream gates | `6911092f0c10` | validation | Strong |
| Replay latency and exact settlement ticks | `6911092f0c10` | validation | Moderate |

No credible fixed-expiry FX result overturns the in-house priors. Apparent RL advantages often involve variable exits, external order flow, or oracle inputs. DeepScalper supports volatility auxiliary training and finds boosted trees competitive; the execution study cautions that emphasizing difficult examples can amplify irreducible noise.
=== reinforcement-learning-trading__03of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/reinforcement-learning-trading__03of05/records.jsonl): **45 records**, validated for JSON, shard order, quote length and page correspondence.

Relevance: **3: 15 · 2: 14 · 1: 16 · 0: 0**. Completed 29 full reads and 16 triages, yielding 152 cited findings and 89 levers.

Ten promising levers—all use **`deriv-ticks`**:

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Compact encoder supervised on future return and magnitude | `9249c06b8f6a` | features | moderate |
| Learn matured Rise/Fall/abstain payoffs together | `946e7979db0f` | loss | moderate |
| Share a small encoder across normalized pairs | `77bb80866c02` | features | moderate |
| Search formulas for incremental ensemble value | `95d334214a2d` | features | moderate |
| Average stable model checkpoints | `803d59524e1f` | ensemble | moderate |
| Gate trades using seed agreement | `87e6279f193a` | ensemble | moderate |
| Compare anchored and rolling training windows | `87e6279f193a` | regime | moderate |
| Bootstrap synchronized multi-pair return blocks | `7cf80fe6d7c3` | loss | moderate |
| Model magnitude with separate central and extreme tails | `7fea90b3bc5f` | magnitude | weak |
| Estimate uncertainty with time blocks, beyond seed variation | `7af26fd6743f` | validation | strong |

Unreadable documents: **none**. Document `807052eca38a` contains a truncated passage, flagged in its record.

No robust contradiction to the in-house priors emerged. Tree baselines remain competitive. Some FX studies report weaker hit rates, while portfolio profits depend on winner size or position scaling. Directional order-flow claims require external signed book data at much shorter horizons. None establishes a validated Deriv fixed-payout edge.
=== reinforcement-learning-trading__04of05
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/reinforcement-learning-trading__04of05/records.jsonl): **45 records**, matching shard order. All numerical findings have page-cited quotes.

Relevance counts: **3: 9 · 2: 23 · 1: 13 · 0: 0**. No unreadable documents. The thesis was read by relevant chapters and marked partial.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Match temporal splits, tuning budgets and settlement rules | `a650b87ff43d` | validation | Moderate | Deriv ticks |
| Add volatility/magnitude auxiliary prediction | `c2cc40ce2818` | loss | Moderate | Deriv ticks |
| Compact ensembles with shared weights and diverse experts | `c2cc40ce2818` | ensemble | Moderate | Deriv ticks |
| Cross-pair Gaussian-mixture/RBF features | `b9e46865da15` | features | Moderate | Deriv ticks |
| Regularized causal online updates | `b9e46865da15` | regime | Moderate | Deriv ticks |
| Separate sign prediction from participation gating | `b21dcd675df8` | selection-gating | Moderate | Deriv ticks |
| Multi-horizon return-distribution auxiliary heads | `bf7103caef67` | features | Weak | Deriv ticks |
| Small recurrent direct-policy baseline | `a53a5f416f1f` | direction | Moderate | Deriv ticks |
| Rolling validation-based model selection | `b5dab7bbc60e` | ensemble | Moderate | Deriv ticks |
| Regularized time-and-return path signatures | `b12321600dc4` | features | Weak | Deriv ticks |

Evidence against the priors is mixed: the thesis reports neural ensembles beating trees in daily stocks, while trees slightly outperform neural predictors in its intraday comparison. Simulated Kalman and mean-reversion sign gains assume predictable dynamics. Neither establishes a robust contradiction to the sign-versus-magnitude prior.

No document establishes an above-break-even Deriv fixed-expiry edge.
=== reinforcement-learning-trading__05of05
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/reinforcement-learning-trading__05of05/records.jsonl): **44 records**, **138 verified page-cited quotes**, **100 levers**. JSON, shard order, IDs, and required fields pass validation.

Relevance: **3: 12 · 2: 17 · 1: 15 · 0: 0**. Coverage: 27 full reads, 15 triages, two selectively read long works. **None unreadable.**

The ten most promising candidates are below. Evidence describes source support; transfer to Deriv remains unproven.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Train on every settled rise/fall/skip payoff | `dd1742948286` | labels | moderate | Deriv ticks |
| Gate trades using conservative payoff bounds | `e11df2ed4bed` | selection-gating | moderate | Deriv ticks |
| Share compact encoders across pairs and expiries | `fc6a7432885b` | features | moderate | Deriv ticks |
| Jointly forecast quantiles and tail expectations | `f21a0763564d` | loss | moderate | Deriv ticks |
| Stress training paths, then adapt on recent unaltered data | `ca6c36d23a1e` | regime | moderate | Deriv ticks |
| Cap interaction complexity and measure forward degradation | `e7ee42948b66` | validation | moderate | Deriv ticks |
| Ensemble calibrated predictions across seeds | `fe5d8fc96ce9` | ensemble | moderate | Deriv ticks |
| Require frozen forward testing with exact settlement | `d9a9f449f42c` | validation | moderate | Deriv ticks |
| Resample synchronized time blocks across pairs | `e80502eb171b` | validation | moderate | Deriv ticks |
| Blend specialists using causal regime context | `f36a8260c071` | ensemble | weak | Deriv ticks |

The older intraday GBPUSD study (`e7ee42948b66`) reports no significant profits after realistic costs, tempering the optimistic direction prior. Other high win-rate claims use conditional samples or variable exits. Nothing establishes a Deriv sign edge from volatility or regime statistics. Test leakage, selected seeds, and overstated significance materially weaken several headline results.
=== sports-betting-analytics__01of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/sports-betting-analytics__01of04/records.jsonl): **120 records**, verified for JSON validity, shard order, required fields, and 144 verbatim page-cited findings.

Relevance counts: **3: 12 · 2: 44 · 1: 37 · 0: 27**.

The ten most promising levers all use **`deriv-ticks`**. Evidence reflects the source studies; FX transfer remains untested.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Conformal residual return distributions | `41bca9788150` | calibration | moderate |
| Pool pair/session calibration effects | `404fc79e90a2` | calibration | moderate |
| Chronologically fitted temperature scaling | `422bc703a69c` | calibration | moderate |
| Equal-weight diverse ensembles | `0545f157c46e` | ensemble | moderate |
| Explicit unchanged-price probability | `1ce5d31c21ee` | labels | moderate |
| Causal multiscale quantiles and dispersion | `1b7d6820c7a4` | magnitude | weak |
| Adaptive historical borrowing | `29bd4b5f9650` | regime | weak |
| Finite-sample null tests for streaks | `20cf2016b03b` | validation | moderate |
| Test incremental information beyond baseline forecasts | `04bdf5f891cf` | ensemble | moderate |
| Check gate stability across plausible specifications | `4296e294ef26` | selection-gating | moderate |

**Unreadable documents: none.** Two long works received selective chapter reads, explicitly marked partial: `1f7594acbe27` and `2d902d80a89a`.

No convincing FX evidence contradicts the in-house priors. Several impressive sports results rely on random splits, future-informed features, altered class prevalence, or simulation. Conformal and pooling results support further calibration experiments, without establishing a tradable Deriv direction edge.
=== sports-betting-analytics__02of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/sports-betting-analytics__02of04/records.jsonl): **120 valid records**, correct shard order, verified quotes and numeric citations.

Relevance counts: **3: 15 · 2: 45 · 1: 38 · 0: 22**.

Reading depth: **33 full, 27 partial, 60 triage**. The full-reading requirement remains incomplete for the 27 marked partials. No files were missing or wholly unreadable.

The ten most promising levers below all use **data_needed="deriv-ticks"**. Evidence describes source support, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Match streak tests to finite-sample selection bias | `78fb47852d53` | validation | strong |
| Estimate uncertainty with dependence-aware resampling | `5aaafae21b86` | validation | moderate |
| Examine calibration across probability and horizon | `6ad1d5f434dc` | calibration | strong |
| Test conditional calibration with regularized splines | `7322e52a398d` | calibration | moderate |
| Shrink sparse success rates toward pooled estimates | `649ec426c54b` | calibration | moderate |
| Shrink pair-specific coefficients toward shared effects | `589fc51ac9b5` | features | moderate |
| Inspect surrogate trees for preprocessing leakage | `7013e9500016` | validation | moderate |
| Distinguish probability bias from profitable opportunity | `698f20ee5e05` | selection-gating | strong |
| Check randomized PIT uniformity and dependence | `81d2cfa4d9c2` | validation | moderate |
| Select ensemble members using prior temporal blocks | `752516f761f0` | ensemble | moderate |

No credible direct contradiction of the Deriv FX priors emerged. Two qualifications matter: goal-margin weighting failed to improve categorical forecasts (`72c1fc41c443`), and catalytic smoothing reduced accuracy (`5aaafae21b86`). Neither technique should be assumed to improve an edge universally.
=== sports-betting-analytics__03of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/sports-betting-analytics__03of04/records.jsonl): **120 records**, with order, JSON, schema, quotations and numeric support verified.

Inspected by relevance: **0: 22 · 1: 27 · 2: 65 · 3: 4**, plus two cover-only records. Depth: **5 full, 64 partial, 49 triage, 2 unreadable**. **The full-reading requirement remains incomplete.**

The most promising proposed FX tests all need `deriv-ticks`. Evidence grades concern the source method, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence |
|---|---|---|---|
| Frozen forecast combinations against recalibrated baselines | `a41e6990954d` | validation | strong |
| Informed shrinkage for sparse states | `b6f55a425868` | features | moderate |
| Empirical-Bayes ridge tuning | `be08f96d452a` | calibration | moderate |
| Nested temporal selection of betting thresholds | `a3e4161f1337` | validation | strong |
| Clock and availability-delay audits | `abcc98b7ee29` | validation | strong |
| Conditional zero-return probability | `a97cd371962a` | labels | moderate |
| Joint occurrence and outcome modeling | `b2817503af31` | labels | moderate |
| Smooth, pooled monotone calibration | `af4cf5218464` | calibration | moderate |
| Posterior-averaged probability forecasts | `c09b103f3298` | calibration | moderate |
| Complementary forecasts over standalone accuracy | `bfbb47b5e748` | ensemble | moderate |

Unreadable full texts: `9421a9b695ea`, **A Brownian Motion Model for the Progress of Sports Scores**; `95f8089bd3c8`, **A Statistical Analysis of Hitting Streaks in Baseball**. Both contain only cover text.

No inspected result directly contradicts the FX priors. A sports CNN beats LightGBM under weak shuffled validation (`8684d854833f`); basketball latent-state evidence is in-sample (`98c43187e989`). Neither establishes an FX sign edge.
=== sports-betting-analytics__04of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/sports-betting-analytics__04of04/records.jsonl): **120 records**, in shard order. JSON, IDs, required fields and numerical quotations validated.

Relevance counts: **3: 13 · 2: 46 · 1: 37 · 0: 24**. All 59 relevance 2–3 documents received full reads; 61 received triage reads. None was unreadable.

The ten most promising transferable levers are below. “Strong” describes methodological support, not demonstrated FX profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Block uncertainty estimates across overlapping labels and simultaneous pairs | `d184b3d7bc12` | validation | strong | deriv-ticks |
| Report Brier reliability and resolution alongside AUC | `c89b90c0283a` | validation | strong | deriv-ticks |
| Fit blending and calibration inside temporal validation | `e0ff290266eb` | validation | strong | deriv-ticks |
| Model up, down and ties coherently before applying payouts | `efbe1d37eac3` | labels | strong | deriv-ticks |
| Pool pairs with pair identity before fitting separate models | `d96af5f40575` | ensemble | moderate | deriv-ticks |
| Benchmark a small regularized online logistic model | `fd83165448b9` | ensemble | moderate | deriv-ticks |
| Build a shrunken, past-only empirical-rate teacher | `e660736cf14c` | labels | moderate | deriv-ticks |
| Shrink predictions toward historical base rates | `f82bdc9e4c67` | calibration | moderate | deriv-ticks |
| Calibrate using shrunken historical forecast residuals | `ff984481d98e` | calibration | moderate | deriv-ticks |
| Abstain when uncertainty includes an unprofitable probability | `ce441057a895` | selection-gating | moderate | deriv-ticks |

No study directly confirms or contradicts the reported in-house FX edges. Sports deep-network gains use richer inputs and sometimes weak validation, so they do not overturn the boosted-tree prior. Small tennis serial dependence qualifies blanket independence claims, but establishes no FX edge. Several papers reinforce that predictive significance, magnitude skill and apparent momentum can coexist with unprofitable betting after costs.
=== statistical-arbitrage__01of04
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/statistical-arbitrage__01of04/records.jsonl): **41 records**, matching shard order. JSON, IDs, quotation lengths and cited source passages checked.

Relevance: **3: 10 · 2: 21 · 1: 10 · 0: 0**. Depth: 28 full, 3 partial, 10 triage.

The strongest candidates for testing are below. Evidence grades concern the recorded mechanism, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Hierarchical shrinkage across pairs | 2766caa50c55 | ensemble | Moderate | deriv-ticks |
| Heavy-tailed error-correction innovations | 0d46509f2899 | features | Moderate | deriv-ticks |
| Discounted autoregression with uncertainty | 1bee8af70b80 | features | Moderate | deriv-ticks |
| Small-factor residual features | 24b54ff5be5d | features | Moderate | deriv-ticks |
| Robust clipping of extreme residuals | 0f062275b3b7 | features | Moderate | deriv-ticks |
| Strictly causal cross-pair lead–lag features | 3cf21e54906c | features | Weak | deriv-ticks |
| Conditional copula dislocation features | 075eaa9d654d | features | Weak | deriv-ticks |
| Reversal conditioned on common-factor momentum | 391011ef41c4 | regime | Moderate | deriv-ticks |
| Dependent-bootstrap correction for strategy search | 1d065597b72f | validation | Moderate | deriv-ticks |
| Reversion-speed gate matched to expiry | 24b54ff5be5d | selection-gating | Weak | deriv-ticks |

No document was wholly unreadable. Long-document partial reads were **13a748852990, 2766caa50c55 and 3aa6328b4df6**; extraction gaps and duplicate evidence are flagged in the records.

Nothing robustly contradicts the in-house priors. Deep-learning superiority remains unsubstantiated here, and filtering, entropy or volatility statistics do not independently establish sign prediction. A reviewed negative volatility-timing result cautions against assuming every magnitude gate improves trading. No document establishes an executable Deriv expiry-direction edge.
=== statistical-arbitrage__02of04
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/statistical-arbitrage__02of04/records.jsonl): **41 ordered records, 137 cited findings, 69 levers**.

Relevance counts: **3: 10 · 2: 16 · 1: 15 · 0: 0**. Reading depth: 25 full, 15 triage, one targeted thesis read marked partial (`5d41a1558cd6`). None unreadable.

Ten promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Sparse cross-pair lag forecasts | `75e4341ffe42` | direction | Moderate | Deriv ticks |
| Separate own, peer and residual returns | `58ca41fcc4bc` | features | Moderate | Deriv ticks |
| Median/IQR residual scaling | `65982d757976` | features | Moderate | Deriv ticks |
| Linear online factor residuals | `4264212a8a66` | features | Moderate | Deriv ticks |
| Momentum × lagged volatility | `5298938d5ece` | direction | Weak | Deriv ticks |
| AUDUSD–NZDUSD lead-lag features | `58ec7083d968` | features | Weak | Deriv ticks |
| Bootstrap intervals with parameter refitting | `63deb47e8bd1` | calibration | Moderate | Deriv ticks |
| Residual crossing-duration features | `55b17e1aca25` | features | Moderate | Deriv ticks |
| Nested temporal parameter selection | `5118b71f2143` | validation | Strong | Deriv ticks |
| Calibration within traded subsets | `63deb47e8bd1` | validation | Strong | Deriv ticks |

Evidence grades support the lever, **not a demonstrated Deriv edge**.

No credible result overturns the in-house FX priors or establishes standalone Kalman/Hurst sign prediction. Important cautions: causal retuning can disappoint (`5549b416e30f`), durable equity cointegration is poorly supported (`63784b10915e`), and profitable return strategies can have low winning fractions (`75e4341ffe42`).
=== statistical-arbitrage__03of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/statistical-arbitrage__03of04/records.jsonl): **41 validated records, 88 levers**, in shard order. All numerical findings have page-cited verbatim quotes.

Relevance: **3: 11 · 2: 13 · 1: 17 · 0: 0**. Reading depth: 23 full, 17 triage, one selective long-document reading.

The 10 most promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized cross-pair VAR | `91f5eaceda3c` | direction | moderate | deriv-ticks |
| Sparse cross-pair residual baskets | `7c51b86dd431` | features | moderate | deriv-ticks |
| Posterior sign-stability gate | `a28f7eeee5c9` | selection-gating | moderate | deriv-ticks |
| Fixed-expiry meta-classifier | `90387735d21e` | selection-gating | moderate | deriv-ticks |
| Brier-based probability selection | `90387735d21e` | calibration | moderate | deriv-ticks |
| Rough-volatility forecasting | `7a489e7542fa` | magnitude | moderate | deriv-ticks |
| Jointly learned compact residuals | `b3fe6e6828d5` | features | moderate | deriv-ticks* |
| Empirical excursion-duration validation | `a745e720814d` | validation | moderate | deriv-ticks |
| Calendar-span-aware estimation | `b4040a7d279b` | validation | moderate | deriv-ticks |
| Nested window and refresh selection | `b743f1ddfbf1` | validation | moderate | deriv-ticks |

\*Price-only adaptation; the published model uses external equity attributes. Evidence grades describe source support, not demonstrated Deriv profitability.

No documents were unreadable. `90f459e33bbb` was read selectively; its lengthy GUI source was omitted.

No robust contradiction to the in-house priors emerged. Hurst-based direction claims have weak FX validation. Joint deep models outperform PCA-based alternatives in daily equities, but do not establish superiority over boosted trees for short-horizon FX.
=== statistical-arbitrage__04of04
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/statistical-arbitrage__04of04/records.jsonl): **39 records**, correct shard order, 97 page-verified findings and 107 levers.

Relevance: **3: 11 · 2: 17 · 1: 11 · 0: 0**. Reading depth: 27 full, 11 triage, one selective book reading. None unreadable.

Ten promising levers; evidence grades describe supporting research, not established Deriv performance:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Separate permanent and transient residuals | `e15f1b50be56` | features | Moderate | Deriv ticks |
| Noise-aware volatility estimation | `f8307bdcc9e3` | magnitude | Moderate | Deriv ticks |
| Stable cross-pair lead-lag signals | `e022fa26f061` | direction | Moderate | Deriv ticks |
| Separate jumps before estimating reversion | `c7abdf38c55e` | features | Moderate | Deriv ticks |
| Enter on inward band recrossing | `e21ae6d77d3f` | selection-gating | Moderate | Deriv ticks |
| Rolling close-location within price range | `f279c945c456` | features | Weak | Deriv ticks |
| EMA momentum interacting with volatility | `ea687470df1f` | direction | Weak | Deriv ticks |
| Average plausible signal formulations | `6a07f999a144` | ensemble | Moderate | Deriv ticks |
| Test complete searches against null data | `6a07f999a144` | validation | Moderate | Deriv ticks |
| Stress entry delays and recent-period failures | `e022fa26f061` | validation | Strong | Deriv ticks |

Hurst-based directional claims in `caf9921dfe07` challenge the size-versus-sign prior, but selected thresholds and omitted costs/ties weaken them. Other filtering results derive direction from signed deviations and assumed reversion. Several profitable strategies fail in later periods, and portfolio profitability frequently does **not** imply useful binary win rates. No convincing comparison overturns the boosted-tree prior.
=== tail-risk-extreme-events__01of06
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/tail-risk-extreme-events__01of06/records.jsonl): **76 ordered records, 125 levers**, with source-verified finding quotes.

Relevance counts: **3: 12 · 2: 37 · 1: 22 · 0: 5**. Depth: 47 full, 27 triage, 2 partial. None unreadable. Partial documents: `1b87a969619f` and `258d9bcf2e8b`; coverage is documented explicitly.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Conditional GPD boosting | `2d2d4a58338f` | magnitude | moderate | Deriv ticks |
| Volatility filtering before tail fitting | `1020d56b1b1c` | magnitude | moderate | Deriv ticks |
| Compact autoregressive tail forecasts | `1391b3485f2b` | magnitude | moderate | Deriv ticks |
| Separate scale/shape regularization | `1eae6f2e870c` | magnitude | moderate | Deriv ticks |
| Small, diverse forecast ensembles | `2a7a80390a7d` | ensemble | moderate | Deriv ticks |
| Exceedance age and waiting-time features | `29b2733e1800` | magnitude | moderate | Deriv ticks |
| Joint threshold/declustering diagnostics | `052b504c11a8` | validation | moderate | Deriv ticks |
| Audit components alongside joint scores | `1b9bdc191115` | validation | strong analytical | Deriv ticks |
| Stress-test tail-family uncertainty | `0a9a32ddd795` | validation | moderate | Deriv ticks |
| Pool normalized tails across pairs | `1b87a969619f` | magnitude | weak | Deriv ticks |

Evidence ratings concern the original studies, not demonstrated Deriv performance.

No robust contradiction of the magnitude-over-sign prior emerged. Neural-superiority claims in `2c3999a302ce` have serious evaluation inconsistencies. Two qualifications matter: larger ensembles can perform worse, and improved joint scores can conceal worse component accuracy. No document establishes a deployable short-horizon FX direction edge.
=== tail-risk-extreme-events__02of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/tail-risk-extreme-events__02of06/records.jsonl): **76 records, 99 levers**. Verified JSON parsing, shard order, required fields, and 64 quotations against source pages.

Relevance counts: **3: 16 · 2: 34 · 1: 25 · 0: 1**. Full reading: 50; triage: 26.

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Separate exceedance occurrence from excess severity | `6154401e8a7a` | magnitude | moderate | Deriv ticks |
| Add lagged absolute variation and variation/net-move ratio | `3fede62ddd11` | features | moderate | Deriv ticks |
| Pool tail shape separately from scale | `51cfb598460b` | magnitude | moderate | Deriv ticks |
| Fit moderate quantiles, then resample for rarer tails | `5f09cc61d197` | magnitude | moderate | Deriv ticks |
| Compare two-tail Hawkes with GARCH magnitude gates | `49348d908fa7` | magnitude | moderate | Deriv ticks |
| Validate thresholds separately at each contract horizon | `4b5331a7f632` | labels | strong | Deriv ticks |
| Ablate magnitude-weighted versus unweighted binary losses | `38b80e12d7ff` | loss | moderate | Deriv ticks |
| Audit threshold and extrapolation stability | `36705c50997c` | validation | moderate | Deriv ticks |
| Use consistent joint quantile/expected-shortfall scores | `5b20cb9d258f` | loss | strong | Deriv ticks |
| Enforce nested magnitude-exceedance probabilities | `60b1ebf6c3c6` | calibration | strong | Deriv ticks |

“Strong” identifies mathematical or validation support, not demonstrated Deriv profitability.

No files were unreadable. The FCIC source text ends mid-report; its contents and commission conclusions were available for triage.

Nothing establishes a Deriv FX direction edge or overturns the magnitude-versus-sign caution. The main challenge to the in-house priors is theoretical: **return-magnitude weighting can misalign training with fixed-payout wins**. Tail-focused losses and more complex dynamic models also do not consistently outperform simpler alternatives.
=== tail-risk-extreme-events__03of06
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/tail-risk-extreme-events__03of06/records.jsonl): **76 records**, matching shard order.

Relevance: **3: 14 · 2: 38 · 1: 20 · 0: 4**. Checked 145 verbatim page-cited quotes. Evaluation grades: 10 B, 32 C, 10 D; none A.

Ten promising candidates below. Evidence grades reflect the original studies, not demonstrated Deriv performance.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Subsampled realized ranges alongside variance | 763838a7795a | features | moderate | deriv-ticks |
| Adaptive POT frequency and scale | 7336ac967d4b | magnitude | moderate | deriv-ticks |
| Cross-fitted intermediate quantile features | 65f14f0887ed | features | moderate | deriv-ticks |
| Shared tail shape with shrunk regime scales | 7c0706ee4eda | magnitude | moderate | deriv-ticks |
| Orthogonal GPD boosting with clipped gradients | 8d3e6aa64a25 | loss | moderate | deriv-ticks |
| Lagged cross-pair tail-risk component | 8801989f0421 | magnitude | moderate | deriv-ticks |
| Joint bulk-tail fitting with censored likelihood | 8dfb7697a325 | calibration | moderate | deriv-ticks |
| Convex, order-preserving forecast combinations | 8724fb889f52 | ensemble | moderate | deriv-ticks |
| Dependence-aware incremental-information tests | 8724fb889f52 | validation | strong | deriv-ticks |
| Bootstrap threshold selection with bias checks | 7b926fa5641b | validation | moderate | deriv-ticks |

None was wholly unreadable. Extracted text is incomplete in **8cab5768173c**, page 4, and **8e354d8be632**, page 7’s table; both limitations are recorded.

No credible finding overturns the magnitude-versus-sign prior. Neural tail models sometimes outperform boosting in simulations and flood data, qualifying any universal preference for trees. Conversely, realized-volatility inputs and more flexible tail distributions do **not** consistently improve crisis-period forecasts. No study establishes an actionable Deriv FX direction edge.
=== tail-risk-extreme-events__04of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/tail-risk-extreme-events__04of06/records.jsonl) with all **76 records**, in shard order.

- Relevance **3: 11 · 2: 46 · 1: 17 · 0: 2**
- Reading depth: **16 full, 41 partial, 19 triage**. Partial reads are explicitly marked.
- None unreadable. JSON, IDs, order and **130 page-cited quotes** passed validation.

Most promising levers—all use **Deriv ticks**. Evidence ratings concern the source studies, not demonstrated Deriv gains.

| Lever | Document ID | Kind | Evidence | Data |
|---|---|---|---|---|
| Volatility-standardized POT tails | `9ab9f1149fe5` | magnitude | moderate | ticks |
| Subsampled realized variance/range | `a3839f271c78` | features | moderate | ticks |
| Paired noncrossing conditional quantiles | `98c258c97554` | magnitude | moderate | ticks |
| Shallow GPD-likelihood trees | `ace924613811` | magnitude | moderate | ticks |
| Pool tail-shape parameters across pairs | `91acd6fc7fdc` | magnitude | moderate | ticks |
| Ensemble forecasts across thresholds | `ad7ac91a98bd` | ensemble | moderate | ticks |
| Account for multiple threshold tests | `a52cfc47e6bd` | validation | moderate | ticks |
| Dependence-adjusted posterior uncertainty | `b327c2e90f15` | calibration | moderate | ticks |
| Asymmetric block-bootstrap uncertainty | `b1abffa217f4` | validation | strong | ticks |
| Require higher moments to beat variance alone | `9de2c35e5471` | features | moderate | ticks |

No extracted result establishes an executable Deriv direction edge. Higher realized moments failed to improve out-of-sample tail forecasts (`9de2c35e5471`), supporting parsimony. Equity flash-crash rebounds offer a narrow possible sign mechanism, with substantial timing and selection caveats (`9b1dd1f40386`). The entropy-bound paper does **not** establish a universal no-sign theorem (`a6cb3a02afb9`).
=== tail-risk-extreme-events__05of06
Completed [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/tail-risk-extreme-events__05of06/records.jsonl): **76 records**, in shard order. JSON, IDs, schema and all 144 page-cited quotes verified.

Relevance: **3: 11 · 2: 41 · 1: 21 · 0: 3**. Reading depth: 51 full, 24 triage, 1 partial.

The ten most promising levers are below. “Moderate” describes methodological evidence, not demonstrated Deriv profitability.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Audit stale ticks and repeated-price runs | bc95de3b9a32 | data | Moderate | deriv-ticks |
| Normalize seasonal volatility causally | cf90cd573da7 | calibration | Moderate | deriv-ticks |
| Pool volatility-standardized magnitude tails | d527c572b3fa | magnitude | Moderate | deriv-ticks |
| Combine preceding-session returns and realized volatility | c6df64445446 | features | Moderate | deriv-ticks |
| Ensemble a small conditional-quantile grid | d3557d41532c | ensemble | Moderate | deriv-ticks |
| Optimize the target quantile loss directly | d3ea6e63bd5d | loss | Moderate | deriv-ticks |
| Compare subsampled realized variance and range | d9da8ff26880 | features | Moderate | deriv-ticks |
| Apply recency-weighted residual calibration | da10df3435fd | calibration | Moderate | deriv-ticks |
| Use selection-matched correlation nulls | d86a9dae8c2e | validation | Moderate | deriv-ticks |
| Quantify small-tail-sample uncertainty | b5f4b67ac1dd | calibration | Moderate | deriv-ticks |

No files were missing. **c9400bc64183**, *Asset Market Linkages in Crisis Periods*, remains partially unreadable because of damaged encoding and truncated extraction; smaller extraction gaps elsewhere are documented.

This shard provides no convincing evidence overturning the magnitude-versus-sign prior or GBDT competitiveness. It does qualify the calibration prior: regime-weighted conformal methods sometimes underperform simpler alternatives. Reported neural gains often confound architecture with loss choice or rely on simulation-matched tests.
=== tail-risk-extreme-events__06of06
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/tail-risk-extreme-events__06of06/records.jsonl): **73 records**, validated for JSON, shard order, IDs, and page-matched quotes.

Relevance counts: **3: 8 · 2: 50 · 1: 12 · 0: 3**. Reading depth: 57 full, one partial book, 15 triaged.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Combine realised variance, bipower and noise-robust measures | f4bad42ce8ff | features | Moderate | Deriv ticks |
| Compare volatility-filtered EVT and empirical residual tails | ce513832f24d | magnitude | Moderate | Deriv ticks |
| Shrink tail parameters across pairs | e47e6d8baaac | magnitude | Moderate | Deriv ticks |
| Use event age and previous severity in exceedance hazards | e73ce491ca28 | magnitude | Moderate | Deriv ticks |
| Fit a penalised distribution spanning body and tail | f3ffc148bf2b | magnitude | Moderate | Deriv ticks |
| Regularise quantile-specific forecast combinations | e370bae3166a | ensemble | Moderate | Deriv ticks |
| Learn combination weights exclusively from held-out forecasts | f686e1f81c89 | validation | Strong | Deriv ticks |
| Check threshold stability using residual coefficients of variation | ff63a5b4b79f | validation | Moderate | Deriv ticks |
| Compare binary loss with clipped and unbounded return weighting | 758e18b73378 | loss | Moderate | Deriv ticks |
| Distinguish endpoint magnitude from path peaks and ranges | ee5b5a5e9586 | labels | Moderate | Deriv ticks |

Evidence grades concern the source method or validation principle; none establishes a Deriv trading edge.

**Unreadable:** none. “Deep Extreme Quantile” (`eaf50fd97a71`) is an incomplete excerpt. The Taleb book (`758e18b73378`) is truncated and remains explicitly partial.

**In-house priors:** no convincing contradiction of the magnitude-versus-sign distinction emerged. Apparent directional results were retrospective, selected, or otherwise weak. The book qualifies return-weighted training because magnitude weighting changes the objective for fixed binary payouts; it does not empirically refute its usefulness. Nothing here validates the earlier Deriv-relevant direction estimates or establishes deep-net superiority.
=== volatility-options-derivatives__01of17
Saved all 48 records in [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__01of17/records.jsonl). Validation passed: JSON/schema, shard order, complete coverage, and 77 verbatim page-cited quotes.

Relevance: **3: 3 documents; 2: 17; 1: 28; 0: 0.** Full reads: 20; triage reads: 28. No unreadable documents.

The ten most promising levers are below. Evidence supports the source result; transfer to intraday Deriv FX remains untested.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Compact HEAVY volatility recursions | `07aa1695b84a` | magnitude | moderate | deriv-ticks |
| Pooled HAR with other-pair volatility averages | `0f6fd2b45d0f` | magnitude | moderate | deriv-ticks |
| Low-rank multivariate HAR | `0adb94992c12` | magnitude | moderate | deriv-ticks |
| Adaptive homogeneous estimation windows | `058b66bcbeb9` | regime | moderate | deriv-ticks |
| Signed semivariance and extreme-move components | `015cebf92d6f` | features | moderate | deriv-ticks |
| Exponentially weighted return-path summaries | `015cebf92d6f` | magnitude | moderate | deriv-ticks |
| Direct expiry-specific variance objectives | `07aa1695b84a` | loss | moderate | deriv-ticks |
| Subsampled RV and noise-robust volatility measures | `07aa1695b84a` | features | moderate | deriv-ticks |
| Test Hurst features against sampling-matched nulls | `08090cef3dce` | validation | moderate | deriv-ticks |
| Explicit announcement-spanning magnitude component | `107ee57737b2` | magnitude | moderate | external: exact UTC release calendar; approval needed |

No credible result overturns the stronger-magnitude/weaker-direction prior. Apparent directional successes include **volatility-change direction**, selected small backtests, and inconsistent lead–lag claims. Important qualifications: roughness estimates can reflect measurement artifacts; FX volatility gains can be modest; adaptive sparse networks and filter switching do not consistently beat simpler alternatives. No document validates the required Deriv binary win rate.
=== volatility-options-derivatives__02of17
Created [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__02of17/records.jsonl): **48 records**, in shard order. JSON, quotation and numeric-citation checks passed.

Relevance counts: **3: 7 · 2: 15 · 1: 26 · 0: 0**. Depth: 20 full, 26 triage, two partial long-document readings. No unreadable files.

The ten most promising test candidates all use **deriv-ticks**. Evidence grades concern the source findings; transfer to intraday FX remains unproved.

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Regularized multiscale HAR baseline | `18c305635fee` | magnitude | moderate | deriv-ticks |
| Upside/downside realized variance | `130e86e5df3b` | features | moderate | deriv-ticks |
| Multiplicative slow/fast volatility | `144e4418701e` | magnitude | moderate | deriv-ticks |
| Quarticity-based variance reliability | `174244dc2e8f` | features | moderate | deriv-ticks |
| Range-derived volatility | `18276d12e731` | features | moderate | deriv-ticks |
| Training-only UTC seasonality normalization | `19df55729959` | features | moderate | deriv-ticks |
| Lagged cross-pair tail events | `1b27141eb022` | features | moderate | deriv-ticks |
| Log-to-level uncertainty correction | `18276d12e731` | calibration | moderate | deriv-ticks |
| Audit filtering versus hindsight smoothing | `174244dc2e8f` | validation | strong | deriv-ticks |
| Judge gates by payout, coverage and missed opportunities | `17d6388b4f84` | selection-gating | moderate | deriv-ticks |

No robust short-horizon FX result contradicts the in-house priors. `1d4b191dfd28` claims a large SPY direction edge, but temporal validation is insufficiently specified and volume is central. `1862d7a9d453` predicts **volatility direction**, not price direction. Several comparisons favor simple HAR models over more elaborate alternatives.

The partial readings are explicitly marked for `116595939870` and `17d6388b4f84`, with pages recorded.
=== volatility-options-derivatives__03of17
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__03of17/records.jsonl): **48 records**, in shard order, with 102 cited findings and 59 levers.

Relevance: **3: 10 · 2: 11 · 1: 27 · 0: 0**. Read 20 fully, selected chapters from one long document, and triaged 27. No unreadable documents.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Separate continuous variance from jumps | `21dd5a9fea25` | magnitude | moderate | Deriv ticks |
| Noise-robust jump features with causal timestamps | `20ecbfd0065b` | features | moderate | Deriv ticks |
| Normalize features by adaptive intraday seasonality | `25ff58e3417e` | features | moderate | Deriv ticks |
| Add rolling cross-pair volatility factors | `264be5d5b446` | features | moderate | Deriv ticks |
| Reduce scale-model parameters through mean targeting | `21486beb2154` | calibration | moderate | Deriv ticks |
| Shrink noisy rolling roughness estimates | `1ff5ac3d7f60` | regime | moderate | Deriv ticks |
| Fit magnitude models directly for each horizon | `25b94ef2de55` | magnitude | moderate | Deriv ticks |
| Adjust model comparisons for repeated searches | `23d27d4d21fb` | validation | moderate | Deriv ticks |
| Stabilize correlation-based feature selection | `293bb9b91eea` | selection-gating | moderate | Deriv ticks |
| Gate by scheduled macro-release timing | `23de2e4c7c65` | selection-gating | moderate | external: release calendar |

Evidence grades describe source support; the FX adaptations remain untested.

There is **no convincing contradiction** of the magnitude-over-sign prior. `2360f717141d` reports a weak historical SPX signed-leverage return relation using external options. The roughness paper cautions that apparent regime changes can largely reflect estimation noise. No clean comparison overturns the tuned-tree prior.
=== volatility-options-derivatives__04of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__04of17/records.jsonl). Verified all **48 records**, shard order, JSON/schema validity, and verbatim page citations.

Relevance: **3: 13 · 2: 10 · 1: 24 · 0: 1**. Reading depth: 22 full, 25 triage, one textbook selectively read. No unreadable files.

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Parsimonious multiscale HAR | `3a98fa84fb63` | magnitude | moderate | deriv-ticks |
| Signed realized semivariances | `30257527eb61` | features | moderate | deriv-ticks |
| Sparse cross-pair volatility pooling | `39ab3a1cbdac` | magnitude | moderate | deriv-ticks |
| Recursive assumed-density volatility filter | `3c738f9408a7` | magnitude | moderate | deriv-ticks |
| Adaptive fast/slow volatility estimates | `3941af906ae2` | ensemble | moderate | deriv-ticks |
| Huber regression loss | `3a98fa84fb63` | loss | moderate | deriv-ticks |
| Shrinkage beta calibration across horizons | `2f9b5ca26a47` | calibration | moderate | deriv-ticks |
| Dependent-noise variance filtering | `412ae89d4924` | magnitude | moderate | deriv-ticks |
| Smooth-volatility null tests for roughness | `41bdeda05486` | validation | moderate | deriv-ticks |
| Combine option- and return-based volatility | `3a98fa84fb63` | data | moderate | external: FX option quotes and forwards |

These grades reflect source support, not demonstrated Deriv profitability.

No convincing contradiction of the size-versus-sign prior emerged. The leverage study supports return-to-future-volatility effects while finding little reverse relation. Option-implied correlations show long-horizon equity-return predictability in-sample, using external data; that does not establish an intraday FX sign edge.

Material cautions recorded include spurious roughness from measurement error, reconstruction accuracy failing to translate into forecasting accuracy, inconsistent sample counts, and look-ahead risks in cleaning and normalization. No document independently validates the reported in-house direction edge or tree-versus-deep-net ranking.
=== volatility-options-derivatives__05of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__05of17/records.jsonl): **48 records**, with shard order, JSON parsing and all 89 quoted findings verified.

Read by relevance: **3: 7 · 2: 15 · 1: 24 · 0: 1**. One additional relevance-1 document was unreadable.

The ten most promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale log-variance features | `41ca3afb1175` | features | moderate | deriv-ticks |
| Separate jumps from continuous variance | `41ca3afb1175` | magnitude | moderate | deriv-ticks |
| Positive/negative semivariance features | `44cfda95b99b` | features | moderate | deriv-ticks |
| Cross-pair joint-sign semicovariances | `44cfda95b99b` | features | moderate | deriv-ticks |
| Fractional powers of absolute returns | `4cd8b2e59fda` | features | weak | deriv-ticks |
| Shrink forecasts toward simple baselines | `460fd6ba5a73` | calibration | moderate | deriv-ticks |
| Family-wide block-bootstrap SPA comparisons | `41f5305b5108` | validation | strong | deriv-ticks |
| Audit Hurst across scales and sampling noise | `492bee13c678` | validation | strong | deriv-ticks |
| Strict expiry labels with explicit tie probability | `4cf38bb721ab` | labels | strong | deriv-ticks |
| Verify magnitude targets contain future returns only | `46add493a4cd` | validation | strong | deriv-ticks |

Unreadable: **`4d20d9916d85`, “Illiquidity and Derivative Valuation”**—severely truncated text extraction.

No robust contradiction of the in-house priors emerged. The strongest transferable evidence concerns magnitude and validation. Weak monthly equity return associations do not establish intraday FX direction skill; option-implied probability gaps do not establish a Deriv edge. “Strong” validation evidence above does not imply trading profitability.
=== volatility-options-derivatives__06of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__06of17/records.jsonl): **48 records**, verified JSON, shard order, schema, and all finding quotes/pages.

Relevance counts: **3: 11 · 2: 13 · 1: 23 · 0: 1**. Completed 23 full reads, one textbook by relevant sections, and 24 triages. None unreadable.

The ten most promising levers are candidates for testing; none establishes a Deriv trading edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Parsimonious multiscale HAR variance baseline | `5951c81212bc` | magnitude | moderate | deriv-ticks |
| Separate jump-arrival probability and jump size | `5951c81212bc` | magnitude | moderate | deriv-ticks |
| Lagged jump counts and time since jump | `530bfe38fd25` | magnitude | moderate | deriv-ticks |
| Multiscale high–low ranges | `5229c7fcf877` | features | moderate | deriv-ticks |
| Noise-aware cross-pair covariance | `579be2212caf` | features | moderate | deriv-ticks |
| Validate sampling frequency separately from expiry | `5ec892e52053` | magnitude | moderate | deriv-ticks |
| Distinguish realized-variance targets from terminal magnitude | `5ec892e52053` | labels | moderate | deriv-ticks |
| Held-out distribution calibration with tie mass | `5c1da3efd683` | calibration | moderate | deriv-ticks |
| Joint block bootstrap across pairs | `5902de620aae` | validation | moderate | deriv-ticks |
| Tail-preserving shuffled controls for scaling features | `52a13a24bbd0` | validation | moderate | deriv-ticks |

No reliable contradiction of the size-versus-sign prior emerged. Option-implied risk-premium papers report directional predictability, but require external data and largely in-sample evidence. Nothing here independently validates the reported in-house FX direction edge. Several apparent successes rely on future volatility, known future covariates, or payoff proxies; these limitations are recorded explicitly.
=== volatility-options-derivatives__07of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__07of17/records.jsonl). Verified 48 ordered, unique JSON records and all finding quotes against their cited pages.

Relevance counts: **3: 12 · 2: 10 · 1: 26 · 0: 0**.

Ten promising levers for testing:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Consecutive-return products | `6a55ed5b7421` | features | moderate | deriv-ticks |
| Sparse variance change-point filter | `68ff86510fd7` | magnitude | moderate | deriv-ticks |
| Average variance estimates before forecasting | `63e4ab0561df` | magnitude | moderate | deriv-ticks |
| Small HAR baseline | `69cad886614f` | magnitude | moderate | deriv-ticks |
| Realized range alongside RV | `69dad893f5ed` | features | moderate | deriv-ticks |
| Equal-weight magnitude ensembles | `69cad886614f` | ensemble | moderate | deriv-ticks |
| Causal time-of-day variance adjustment | `6fbd9b6a5ef3` | magnitude | moderate | deriv-ticks |
| Separate total and jump-suppressed variance | `6fbd9b6a5ef3` | features | moderate | deriv-ticks |
| Block-bootstrap, multiplicity-aware comparisons | `63e4ab0561df` | validation | strong | deriv-ticks |
| Fixed-side and base-rate benchmarks | `6d1252879fe7` | validation | strong | deriv-ticks |

One reading limitation: `6c2ed1b95428` is **partial** because of corrupted font encoding. No files were missing.

Nothing credibly overturns the in-house priors or independently validates the reported directional edge. Hawkes models describe fleeting signed dependence, but their empirical evidence here concerns volatility estimation. The strongest transferable ideas concern magnitude and evaluation.
=== volatility-options-derivatives__08of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__08of17/records.jsonl): **48 records**, verified JSON, shard order, required fields, and exact page-quote matches.

Relevance: **3: 10 · 2: 9 · 1: 27 · 0: 2**. Reading depth: 18 full, 1 partial, 29 triaged.

The most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Low-rank intraday variance completion | `7ff96b610916` | magnitude | Moderate | Deriv ticks |
| Separate roughness from volatility persistence | `758eb625cb9d` | magnitude | Moderate | Deriv ticks |
| Log-linear Realized GARCH | `7d1ccbde15d4` | magnitude | Moderate | Deriv ticks |
| Two-scale realized variance | `7801e31883ff` | features | Moderate | Deriv ticks |
| Continuous variance and jump-share features | `7ba3404e19c9` | features | Moderate | Deriv ticks |
| Measurement-error-aware persistence audit | `80516125cda8` | validation | Moderate | Deriv ticks |
| Pool cross-pair volatility/correlation models | `7c6df22c6481` | features | Weak | Deriv ticks |
| Causal intraday seasonality adjustment | `758eb625cb9d` | features | Moderate | Deriv ticks |
| Correct log-variance retransformation bias | `758eb625cb9d` | calibration | Moderate | Deriv ticks |
| QLIKE with block-bootstrap model comparisons | `758eb625cb9d` | validation | Moderate | Deriv ticks |

Evidence grades concern source results; none establishes profitable Deriv performance.

No document was wholly unreadable. *Phynance* received selected-section reading; OCR damage and truncated passages are documented.

No convincing contradiction of the magnitude-over-sign prior emerged. SIP reports outperforming XGBoost on ETF volatility, which warrants testing a structured baseline but does not resolve FX direction or trees versus deep nets. The gamma paper’s strongest directional association is contemporaneous and uses external data.
=== volatility-options-derivatives__09of17
Saved and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__09of17/records.jsonl): **48 records**, exact shard order, valid JSON, and verbatim page-checked quotes.

Relevance: **3: 3 documents · 2: 17 · 1: 28 · 0: 0**. Twenty received full reads.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multi-candle range, absolute return and dispersion | `8d89daec48c9` | features | moderate | Deriv ticks |
| Regularised trend/activity volatility kernels | `8b65146f90b8` | magnitude | moderate | Deriv ticks |
| HEAVY with realised variance and cross-pair covariance | `893876a21ddb` | magnitude | moderate | Deriv ticks |
| Pool dynamics and shrink covariance targets | `893876a21ddb` | regime | moderate | Deriv ticks |
| Realised kernels versus subsampled variance | `8dc51abf56b1` | features | moderate | Deriv ticks |
| Sampling-frequency signature plots | `8dc51abf56b1` | validation | moderate | Deriv ticks |
| Simple fast/slow volatility factors before rough models | `8634cc3f3964` | magnitude | moderate | Deriv ticks |
| Multiplicative cascade with linear forecasting—daily evidence | `91c42d393291` | magnitude | moderate | Deriv ticks |
| Dependent bootstrap and multiple-testing control | `9494bd3a57b1` | validation | strong | Deriv ticks |
| Refit generated predictors inside every training window | `950b11359930` | validation | strong | Deriv ticks |

No document was wholly unreadable. Lecture notes `92154addf7a6` end midchapter before the later chapters advertised in their contents; that limitation is recorded.

No convincing evidence contradicts the in-house sign/magnitude or boosted-tree priors. Important qualifications: roughness estimates can be spurious, robust training can hurt calm-period performance, and some volatility models lose to historical averages. The strongest return-prediction claim uses monthly equity options/macro data and explicitly admits look-ahead bias.
=== volatility-options-derivatives__10of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__10of17/records.jsonl): **48 records**, validated for JSON, shard order, schema and quoted evidence.

Relevance: **3: 15 · 2: 5 · 1: 28 · 0: 0**. Twenty full reads; twenty-eight triages. No unreadable documents.

Ten promising levers—all require only **Deriv ticks**:

| Lever | Document id | Kind | Evidence |
|---|---|---|---|
| HARQ measurement-error adjustment | `9ace1ef9c070` | magnitude | moderate |
| Combine realized variance and range | `9f964684d955` | magnitude | moderate |
| Noise-robust realized kernels | `a25c6fabc961` | magnitude | moderate |
| Joint cross-pair volatility forecasts | `9a0264b3baae` | magnitude | moderate |
| Integrate future-variance uncertainty | `a14e0e5de7e8` | calibration | moderate |
| Discounted Bayesian variance filter | `a518fda58267` | magnitude | moderate |
| UTC seasonality and session spillovers | `a49a226a8f60` | features | moderate |
| Shrink pooled volatility-factor models | `a49a226a8f60` | ensemble | moderate |
| Test conditional calibration using PITs | `9be982b05f89` | validation | moderate |
| Require mature targets and horizon embargoes | `a563feb6d202` | validation | strong |

Transfer to Deriv remains untested. Nothing robustly contradicts the in-house magnitude-versus-sign or simpler-model priors. Bayesian “price forecasting” gains mainly sharpen predictive densities; post-jump option profits become negative after spreads. Several apparent improvements rely on retrospective preprocessing, proxy targets or thin holdouts, explicitly flagged in the records.
=== volatility-options-derivatives__11of17
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__11of17/records.jsonl): **48 records in shard order**, with page-checked quotations.

Relevance counts: **3: 9 · 2: 9 · 1: 29 · 0: 1**. Reading depth: 17 full, 1 partial, 30 triaged.

The ten most promising levers are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Weight training examples by volatility-state similarity | `ac211c71a657` | regime | Moderate | Deriv ticks |
| Regularized HAR variance baseline | `aee7864f6954` | magnitude | Moderate | Deriv ticks |
| Separate upside/downside realized semivariances | `ae9477ebef3e` | features | Moderate | Deriv ticks |
| Jump age, count and size features | `ad87498ff24b` | magnitude | Moderate | Deriv ticks |
| Sampling-grid and noise diagnostics | `ad5beff94230` | features | Moderate | Deriv ticks |
| Variance-uncertainty gates using fixed-k intervals | `a5f822b4ada8` | selection-gating | Moderate | Deriv ticks |
| Dynamic cross-pair correlation features | `a7c0b306086b` | features | Moderate | Deriv ticks |
| Pool volatility feedback across standardized pairs | `af66617c1db6` | features | Moderate | Deriv ticks |
| QLIKE-based variance evaluation | `aee7864f6954` | validation | Moderate | Deriv ticks |
| Condition magnitude gates on scheduled announcements | `ad87498ff24b` | data | Moderate | External: timestamped macro calendar |

No documents were missing or wholly unreadable. `ae2ca30a347d` is marked **partial** because several source paragraphs terminate mid-sentence.

No robust FX direction evidence contradicts the in-house priors. The semivariance paper’s daily equity-return result (`ae9477ebef3e`) is in-sample; the monthly return claim in `b16512781be9` is specification-sensitive and requires options data. The strongest transferable ideas concern magnitude, measurement and validation.
=== volatility-options-derivatives__12of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__12of17/records.jsonl).

All 48 records validated: correct shard order, valid JSON, and 111 quotes matching their cited pages. Recorded 84 levers.

Read by relevance: **3: 12 · 2: 6 · 1: 30 · 0: 0**. Eighteen received full reads; thirty were triaged. None unreadable.

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pool regularized magnitude models across pairs | b49eb211d70d | magnitude | Moderate | Deriv ticks |
| Separate fast and slow volatility | c1dbc4544168 | magnitude | Moderate | Deriv ticks |
| Smooth time-of-day volatility curves | c1dbc4544168 | features | Moderate | Deriv ticks |
| Average realized variance across sampling grids | b736cd1cbb1e | features | Moderate | Deriv ticks |
| Quarticity-adjusted HAR baseline | b736cd1cbb1e | magnitude | Moderate | Deriv ticks |
| Break-aware short-memory models | ba8e605aefbf | regime | Moderate | Deriv ticks |
| Separate zero-return probability from move size | b7c09feeaebb | labels | Moderate | Deriv ticks |
| Regularized absolute-return lag models | bfa5209073bd | magnitude | Moderate | Deriv ticks |
| Nested temporal selection of all tuning parameters | bfa5209073bd | validation | Strong | Deriv ticks |
| Announcement effects with learned decay | c1dbc4544168 | selection-gating | Moderate | External: point-in-time macro calendar |

Evidence ratings describe the papers; transfer to Deriv remains untested.

No convincing contradiction of the size-versus-sign prior emerged. A minute-level stock Markov paper claims reversal, but only descriptively. Nothing establishes a Deriv directional edge or overturns the tree-versus-deep prior. Significant cautions include spurious roughness from measurement error and forecasting gains tuned on the reported test period.
=== volatility-options-derivatives__13of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__13of17/records.jsonl): **48 records in shard order**, validated JSON, with **101 verbatim page-checked quotations**.

Relevance counts: **0: 0 · 1: 31 · 2: 9 · 3: 8**. Read depth: 16 full, one relevant-chapter reading, 31 triage. **None unreadable.**

The ten most promising levers are:

| Lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Multiscale HAR with negative-return effects | `c45cea55cc8b` | magnitude | moderate | deriv-ticks |
| Adapt volatility lookback to local homogeneity | `ca1fd99ca96a` | regime | moderate | deriv-ticks |
| Low-power absolute-return aggregates | `ca1fd99ca96a` | features | moderate | deriv-ticks |
| Signed realized semivariances | `d3c18792188b` | magnitude | moderate | deriv-ticks |
| Tail-partitioned realized variance | `d4c215940a04` | features | moderate | deriv-ticks |
| Signed cross-pair semicovariances | `d16e1bf68e1d` | features | moderate | deriv-ticks |
| Noise-aware realized auxiliary targets | `c5995afb333c` | labels | moderate | deriv-ticks |
| Pool magnitude slopes across pairs | `d3c18792188b` | ensemble | weak | deriv-ticks |
| Nested, purged threshold selection | `d4c215940a04` | validation | moderate | deriv-ticks |
| Implied-volatility benchmark and combination | `c5995afb333c` | data | moderate | external: FX implied volatility |

**No credible contradiction to the weak-direction/strong-magnitude priors emerged.** The reported 62% accuracy concerns volatility direction; weekly return predictability is in-sample. Most stronger evidence concerns daily equity volatility, so intraday FX transfer remains unproven. Semivariance gains also depend on the baseline: one paper finds little incremental value after leverage and jump controls. No convincing modern trees-versus-deep-nets comparison appears here.
=== volatility-options-derivatives__14of17
Completed and verified [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__14of17/records.jsonl): 48 valid records in shard order, with exact quote/page checks.

Relevance: **3: 11 · 2: 20 · 1: 17 · 0: 0**. Depth: 30 full, 17 triage, one partial.

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Sparse realized-variance baseline | daf37103a026 | magnitude | strong | deriv-ticks |
| Causal intraday seasonality adjustment | d9e7f09e5ff1 | magnitude | moderate | deriv-ticks |
| Parsimonious multiscale EWMA variance | df9601153fb9 | magnitude | moderate | deriv-ticks |
| Pool volatility dynamics across pairs | dabd5e7d9c58 | magnitude | moderate | deriv-ticks |
| Quarticity-adjusted volatility persistence | dce3e3612b59 | magnitude | moderate | deriv-ticks |
| Robust local-quantile variance | dcaedfc1ec3b | magnitude | moderate | deriv-ticks |
| Truncated variance with separate jump variation | daf37103a026 | features | strong | deriv-ticks |
| Robust local cross-pair correlations | de776d0f29c7 | features | moderate | deriv-ticks |
| Block-resampled comparisons with multiple-testing controls | daf37103a026 | validation | strong | deriv-ticks |
| Lagged volume surprises interacting with session | e1d1d961b1d1 | magnitude | moderate | external: FX futures volume/prices |

Evidence grades describe the studies; transfer to Deriv remains untested.

None were unreadable. **db15687d9462** received main-text coverage; its appendices remain unread.

No convincing contradiction to the in-house size-versus-sign or trees-versus-deep priors emerged. The hybrid LSTM paper beats GARCH without comparing trees, and its “direction” metric concerns volatility direction. Several apparent direction claims rely on contemporaneous event regressions or price-level Hurst estimates without a credible forecasting test.
=== volatility-options-derivatives__15of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__15of17/records.jsonl): **48 records**, in shard order. All JSON, IDs and 99 page-cited quotes validated.

Relevance counts: **3: 9 · 2: 14 · 1: 25 · 0: 0**. Reading depth: 22 full, 25 triage, one partial.

The ten most promising levers follow. Evidence grades describe the source setting; FX transfer remains untested.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Quarticity-dependent HAR/EWMA attenuation | `e3bd7718a3cc` | magnitude | moderate | deriv-ticks |
| Time-varying log-HAR persistence | `e72b5cfe80f4` | magnitude | moderate | deriv-ticks |
| Average variance across staggered sampling grids | `eaa197e35673` | magnitude | moderate | deriv-ticks |
| Training-only seasonal volatility normalization | `e9ab50b1bdb3` | features | moderate | deriv-ticks |
| Pool variance and correlation components across pairs | `e3bd7718a3cc` | features | moderate | deriv-ticks |
| Volatility-scaled empirical residual quantiles | `e636c221ab62` | calibration | moderate | deriv-ticks |
| Block-bootstrap model confidence sets and reality checks | `e3bd7718a3cc` | validation | moderate | deriv-ticks |
| Regularize unstable higher-moment features | `eca3c7d30adf` | features | moderate | deriv-ticks |
| Score threshold probabilities directly | `e52d8c1e1b4e` | calibration | moderate | deriv-ticks |
| Add lagged FX implied variance | `e4f8a05a480a` | data | moderate | external: FX option-implied variance |

No document was wholly unreadable. `eca3c7d30adf` is partial because table pages P31–37 contain corrupted text; its numerical findings use readable body passages.

**No credible contradiction to the in-house priors emerged.** Kalman, roughness and complexity results concern magnitude. One external-sentiment study claims stronger direction accuracy, but inconsistent results and non-timestamped joins undermine that evidence.
=== volatility-options-derivatives__16of17
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__16of17/records.jsonl): **48 records**, verified for shard order, JSON validity and quoted evidence.

Relevance counts: **3: 11 · 2: 17 · 1: 20 · 0: 0**. Records contain 93 page-cited findings and 66 testable levers.

The ten most promising levers chiefly concern magnitude and evaluation:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Aggregate fine squared/absolute returns | `f6b32e28a74f` | features | moderate | deriv-ticks |
| Range and wick-asymmetry features | `f1cec67c49cc` | features | moderate | deriv-ticks |
| Joint clock-seasonality normalization | `f8c77970f42d` | features | moderate | deriv-ticks |
| Fast/slow volatility decay components | `f37227975c3a` | magnitude | moderate | deriv-ticks |
| Hierarchical cross-pair volatility | `fa6f91fc957c` | magnitude | moderate | deriv-ticks |
| Regularized asymmetric EGARCH baseline | `ede8b2c983d8` | magnitude | moderate | deriv-ticks |
| Dependence-aware cross-pair inference | `f1d691b4ce22` | validation | moderate | deriv-ticks |
| Explicit strict outcomes and tie mass | `f6415869f4c3` | labels | moderate | deriv-ticks |
| Freeze calibration forecasts before entry | `fa8b799e17ff` | validation | strong | deriv-ticks |
| Pooled announcement-response kernels | `f8c77970f42d` | magnitude | moderate | external: timestamped macro calendar |

**No unreadable files.** The French Monte Carlo notes (`ee790de7ec20`) have a partial-depth record: relevant chapters were read, but extraction is truncated.

No direct refutation of the in-house FX results emerged. Cautions: roughness can be an estimation artifact; persistence features can add little beyond HAR; one separate volatility study favors structured linear models over boosting. None validates the reported Deriv directional edge or AUC figures.
=== volatility-options-derivatives__17of17
Wrote [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/volatility-options-derivatives__17of17/records.jsonl): **46 records**, validated for JSON, shard order, quote lengths and cited-page text.

Relevance: **3: 10 · 2: 16 · 1: 20 · 0: 0**. Coverage: **14 full, 12 partial, 20 triage**. None wholly unreadable; extraction damage and incomplete coverage are noted.

The ten most promising levers:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Pooled, regularized HAR | `546d23612677` | magnitude | moderate | deriv-ticks |
| Absolute-return MIDAS | `546d23612677` | features | moderate | deriv-ticks |
| Bias-corrected preaveraged variance | `fabcd35c3e8b` | magnitude | moderate | deriv-ticks |
| Separate continuous and jump variation | `03eb17547d07` | magnitude | moderate | deriv-ticks |
| Shared cross-pair volatility factor | `26db2586cb0d` | magnitude | moderate | deriv-ticks |
| Block-bagged linear HAR | `546d23612677` | ensemble | moderate | deriv-ticks |
| Proxy-robust QLIKE evaluation | `0e6ea94fe645` | loss | strong | deriv-ticks |
| Dependence-aware multiple-testing control | `0e6ea94fe645` | validation | strong | deriv-ticks |
| Conditional probability-error diagnostics | `85e49716e6d9` | validation | strong | deriv-ticks |
| Historical/implied volatility blend | `fca455449f6b` | ensemble | moderate | external: FX option quotes |

Evidence strength concerns each method’s stated purpose, not demonstrated Deriv profitability.

The main qualification to the priors is theoretical: volatility can affect sign probabilities when the conditional mean is nonzero (`85e49716e6d9`, P13). No usable short-horizon FX sign edge is established. The rough-volatility hedging backtest also uses future data for Hurst calibration; that limitation is recorded explicitly.
=== weather-climate-forecasting__01of04
Saved [records.jsonl](./records.jsonl): **138 valid records**, with IDs in shard order and all quotations checked against their cited pages.

**Reading remains incomplete:** 7 full readings, 70 partial readings, and 61 triages. Partial coverage is explicitly marked.

Relevance counts: **3: 5 · 2: 72 · 1: 38 · 0: 23**.

The most promising transfer hypotheses are:

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Validate exact settlement labels | `16a384f602fe` | validation | Moderate | deriv-ticks |
| Model tie probability explicitly | `0567c454ef17` | labels | Weak | deriv-ticks |
| Train with tail-weighted CRPS | `0ded9509ed3a` | loss | Moderate | deriv-ticks |
| Extend forest distributions with EVT tails | `3f846f04bc8f` | magnitude | Moderate | dukascopy |
| Enforce coherent exceedance probabilities | `02e2ae5331b0` | magnitude | Weak | deriv-ticks |
| Conformalize normalized residuals | `13a25e46b661` | calibration | Moderate | deriv-ticks |
| Combine offline stacking with online mixtures | `037d27dff21c` | ensemble | Moderate | deriv-ticks |
| Compare paired scores using temporal blocks | `0b9f13f94cf1` | validation | Moderate | on-disk |
| Calibrate final transformed probabilities | `3a1fd40dcc7e` | calibration | Moderate | on-disk |
| Separate uncertainty level from spread sensitivity | `20a5eb341d27` | calibration | Moderate | deriv-ticks |

These evidence ratings concern methodological transfer, not demonstrated FX profitability.

No source file was missing or wholly unreadable. `3c80b21ded5e` has substantial OCR artifacts; `3e1835f46953` contains adjacent unrelated material, but its weather article is readable.

No reviewed FX evidence contradicts the in-house priors. A relevant caution is that better extreme-event forecasts can worsen calibration elsewhere in the distribution.
=== weather-climate-forecasting__02of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/weather-climate-forecasting__02of04/records.jsonl): **138 valid records**, matching shard order. All finding quotes passed page-text checks.

**Reading remains incomplete:** 6 full reads, 103 partial reads, 29 triages. Relevance counts: **0: 12 · 1: 17 · 2: 94 · 3: 15**.

The ten most promising recorded levers are below. All use **deriv-ticks**; evidence is **moderate for the source method**, with FX transfer unproven.

| Lever | Document ID | Kind |
|---|---|---|
| Quantile boosting for magnitude gates | `4b7a4a7dc8bc` | magnitude |
| Similarity-based pooled calibration | `6fc2eb8faaad` | calibration |
| Equal-weight ensemble baseline | `52424ccc945c` | ensemble |
| Purged out-of-fold residual training | `75efdbbcc332` | validation |
| Delayed-feedback conformal updates | `6d2e87ed44ea` | calibration |
| Threshold-by-horizon reliability checks | `6e374430424f` | validation |
| Threshold-weighted proper scoring | `5e77f60e2bb2` | validation |
| Purging overlapping forecast horizons | `6240d5072929` | validation |
| Simple ensemble-disagreement rejection | `7cbb63ede10f` | selection-gating |
| Payout-specific probability gates | `5d7575f04e4a` | selection-gating |

No files were unreadable. `67ced789c2ce` contains only a short summary extract.

The main qualifications to the in-house priors are that conformal marginal coverage does **not** guarantee coverage on selected trades or extremes, calibration can worsen forecasts, and neural postprocessors sometimes beat simpler statistical methods. Nothing inspected directly validates a major-FX sign edge.
=== weather-climate-forecasting__03of04
Saved [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/weather-climate-forecasting__03of04/records.jsonl): **138 records**, matching shard order. JSON, IDs and all 163 page-cited quotes passed validation.

Relevance counts: **3: 15 · 2: 97 · 1: 1 · 0: 25**.

**Coverage limitation:** 14 full readings, 98 partial readings and 26 triages. No files were unreadable, but the whole-document reading requirement remains incomplete.

Ten promising levers follow. Evidence concerns methods and weather applications; none establishes a Deriv trading edge.

| Lever | Document ID | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Learn magnitude CDFs from all observations | `a3507717ae39` | magnitude | moderate | deriv-ticks |
| Benchmark distributional boosted trees | `a9cf62285d98` | magnitude | moderate | deriv-ticks |
| Use proper threshold-weighted CRPS | `a2e06e3b56ac` | loss | strong | deriv-ticks |
| Compare unweighted probability loss against weighting | `96422935948b` | loss | moderate | deriv-ticks |
| Benchmark pooled regularized logistic regression | `a2cd8a5cd93c` | calibration | moderate | deriv-ticks |
| Combine matured residual volatility with disagreement | `ac8965dcaedf` | magnitude | moderate | deriv-ticks |
| Aggregate complete CDFs with rolling weights | `8670e2c1c663` | ensemble | moderate | deriv-ticks |
| Pool calibration with pair embeddings | `a0eca0dc4e9f` | calibration | moderate | deriv-ticks |
| Model exact-zero mass explicitly | `c149772febd6` | magnitude | moderate | deriv-ticks |
| Test conditional coverage and exceedance dependence | `bc8cdbd62778` | validation | strong | deriv-ticks |

The clearest challenges to the in-house priors concern **outcome-weighted losses**, which can distort probability estimation, and assumptions that calibration or additional ensemble components always improve forecasts. No strong evidence here overturns the weak-direction/stronger-magnitude prior. The entropy-based ENSO claims do not establish FX sign predictability.
=== weather-climate-forecasting__04of04
Saved and validated [records.jsonl](/mnt/data/deriv-sota-lab/literature/work/weather-climate-forecasting__04of04/records.jsonl): **137 ordered records**, 149 findings and 186 levers.

Relevance counts: **3: 17 · 2: 98 · 1: 13 · 0: 9**.

**Reading remains incomplete:** 6 full reads, 109 partial reads and 22 triage records. Depth limits are recorded explicitly.

| Promising lever | Document id | Kind | Evidence | Data needed |
|---|---|---|---|---|
| Evaluate actual contract payoff and selected-trade calibration | de8368fe8d35 | validation | moderate | deriv-ticks |
| Bootstrap calibration-parameter uncertainty | e2a69821fe0a | calibration | moderate | deriv-ticks |
| Pool pairs with small pair embeddings | feecf0118a39 | ensemble | moderate | deriv-ticks |
| Distributional forests for magnitude | f4e809c86b88 | magnitude | moderate | deriv-ticks |
| Explicit zero-move mass plus continuous magnitudes | fd7e5ebfc59f | magnitude | weak | deriv-ticks |
| Regularized linear probability pooling | f42ec3d4897a | ensemble | moderate | deriv-ticks |
| Delayed online expert weighting | db592f409785 | ensemble | moderate | deriv-ticks |
| Causal forecast-error recalibration | ef363c2dbb4b | calibration | moderate | deriv-ticks |
| Cross-pair volatility spillovers | d79870ff3957 | magnitude | moderate | deriv-ticks |
| Whole-episode bootstrap and matched comparisons | d8fc36f68783 | validation | moderate | deriv-ticks |

No files were unreadable. **be6c07ee7b36** is truncated before its forecasting chapter.

No direct FX contradiction was established. Weather evidence sometimes favors shallow neural postprocessors over trees; other neural advantages involve noncausal preprocessing. One conformal paper has unsupported coverage claims, reinforcing the need to validate gating on actual settlement outcomes.
