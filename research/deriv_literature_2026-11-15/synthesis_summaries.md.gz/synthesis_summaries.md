=== calibration__01of03
Created [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/calibration__01of03/candidates.jsonl), covering all 602 levers in 114 candidates.

| Status | Count |
|---|---:|
| testable_now | 93 |
| needs_external_data | 13 |
| closed_family | 2 |
| out_of_scope | 4 |
| already_done | 2 |

All 12 medium-prior candidates have verified source quotations. None received a high prior.

Top 10 testable candidates, all **low prior for direction gains**:

1. **Conditional sign stacker** — combine rival forecasts and magnitude context.
2. **Matured residual correction** — test persistent signed forecast errors.
3. **Student-t distributional regression** — estimate signed location and scale separately.
4. **Terminal-return hurdle model** — model Rise, Fall and tie mass coherently.
5. **Signed residual CDF** — derive strict contract probabilities from empirical errors.
6. **Online logistic layer** — update coefficients after outcomes mature.
7. **Local probability calibration** — test recurring context-dependent score errors.
8. **Conditional skew** — test asymmetric probability allocation beyond volatility.
9. **Ridge/Bayesian logistic baseline** — shrink noisy signed coefficients.
10. **Compact kernel baseline** — test a small set of nonlinear signed interactions.
=== calibration__02of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/calibration__02of03/candidates.jsonl): **102 candidates covering all 602 levers**.

Counts: **72 testable_now**, 15 needs_external_data, 6 closed_family, 6 out_of_scope, 3 already_done. All 12 medium-prior candidates have verified primary-text quotes; none received a high prior.

Top 10 testable candidates, in rank order:

1. Context and matured-residual logit correction — low.
2. Coherent signed-return CDF with zero atom — low.
3. Within-pair sign-reflection regularization — low.
4. Conditional skew and signed-shock correction — low.
5. Regularized stacking of existing forecasts — low.
6. Per-pair ridge logistic benchmark — low.
7. Separate ranking and probability heads — low.
8. Uncertainty-integrated, shrunk drift baseline — low.
9. Sparse kernel probability benchmark — low.
10. Identity-shrunk affine logit calibration — medium; repairs probabilities without adding ranking information.
=== calibration__03of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/calibration__03of03/candidates.jsonl): **602 levers → 122 candidates**, with complete input coverage.

Counts: **95 testable now · 11 need external data · 3 closed family · 12 out of scope · 1 already done.**

All nine medium-prior candidates have verified page quotes. None establishes new Deriv directional alpha.

Top 10 testable candidates, in ranked order:

1. **Shrunk affine-logit calibration** — medium; correct probability slope and bias.
2. **Rise/Fall/tie coherence** — low; enforce valid strict-win probabilities.
3. **Monotone beta calibration** — medium; correct asymmetric probability distortion.
4. **Isotonic PAV calibration** — medium; test flexible monotone correction.
5. **Final ensemble recalibration** — medium; calibrate the combined forecast.
6. **Past-only probability shrinkage** — low; restrain unsupported extremes.
7. **Matured signed-residual correction** — low; test persistent signed forecast bias.
8. **Local state calibration** — low; test context-dependent signed errors.
9. **Hierarchical postcalibration** — low; share small calibration offsets across frozen forecasts.
10. **Delayed online Platt updates** — low; adapt calibration after outcomes settle.
=== data__01of02
Created [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/data__01of02/candidates.jsonl): **178 candidates covering all 478 levers**.

| Status | Count |
|---|---:|
| testable_now | 29 |
| needs_external_data | 125 |
| closed_family | 2 |
| out_of_scope | 20 |
| already_done | 2 |

No direction candidate earned more than a low prior. Four medium-prior validation safeguards have page-verified quotations.

Top 10 testable candidates, all low prior:

1. **Historical neighbors** — past-only, pair-specific signed-pattern probability feature.
2. **Training-block valuation** — nested day-block reweighting with strict controls.
3. **Window augmentation** — training-only amplitude and duration transformations.
4. **Local joint resampling** — cheap feature/outcome resampling versus equivalent weights.
5. **Causal factor imputation** — recover missing companion inputs without inventing labels.
6. **Sampling-probability weights** — correct context-dependent subsampling, if present.
7. **Tabular augmentation** — small joint sampler versus real-only training.
8. **Synthetic replay** — conditional on a demonstrated storage/update constraint.
9. **Missingness gate** — coverage and staleness features for magnitude/reliability.
10. **Tick Hawkes activity** — price-change excitation for magnitude only.
=== data__02of02
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/data__02of02/candidates.jsonl): **163 candidates covering all 477 levers**.

| Status | Candidates |
|---|---:|
| testable_now | 15 |
| needs_external_data | 121 |
| already_done | 2 |
| closed_family | 2 |
| out_of_scope | 23 |

Top 10 testable candidates, in the requested order:

1. Conditional return-path augmentation — SIGN hypothesis; low prior.
2. Defective-training-window filtering — SIGN robustness; low.
3. Past-only missing-input reconstruction — restores signed inputs; low.
4. Gap and staleness masks — SIZE/gating; low.
5. Signature-moment scenarios — SIZE; low.
6. Rare-regime augmentation — SIZE; low.
7. Extreme-shape lifting — SIZE scenarios; low.
8. UTC/New York DST audit — validation; medium.
9. Raw-tick and endpoint integrity — validation; medium.
10. Missing-outcome ledger and conservative bounds — validation; medium.

All five medium-prior candidates include page-verified quotations. No direction candidate earned a medium or high prior.
=== direction__01of01
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/direction__01of01/candidates.jsonl): **115 candidates covering all 483 levers**.

Counts: **61 testable now** (57 direction, 4 magnitude/gating), **42 need external data**, **5 closed family**, **4 out of scope**, **3 already done**.

Top 10 testable candidates:

1. Fixing-clock drift and pre/post-fix reversal — **medium**; source claim verified.
2. Small regularized strict-direction classifier — low.
3. Same-clock returns from preceding trading days — low.
4. Session-end continuation from opening/day-to-date returns — low.
5. Session-conditioned continuation/reversal slopes — low.
6. Sparse per-target cross-pair lags with stability controls — low.
7. Common-USD-factor residual reversal — low.
8. Nonlinear response to signed shock strength — low.
9. Rejection at deterministic round pip levels — low.
10. Continuation after confirmed round-level crossings — low.

Build costs are labeled estimates; unknown compute hours are `null`. No candidate received a high prior.
=== ensemble__01of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/ensemble__01of03/candidates.jsonl): **120 candidates covering all 556 levers**.

Status counts: **98 testable now · 10 need external data · 7 closed family · 4 out of scope · 1 already done**. Six medium priors have verified source quotes; none ranked high. Unknown cost hours are `null`.

Top 10 testable candidates:

1. Equal-weight heterogeneous probability pooling.
2. Convex stacking shrunk toward equal weights.
3. Short/long training-window ensembles.
4. Shallow bagged-tree alternatives to boosting.
5. Predeclared LightGBM seed averaging.
6. Balanced contributions across model families.
7. Separate price-feature views before pooling.
8. Linear baseline with a small residual correction.
9. Shrinkage of forecast-error covariance.
10. Bootstrap model-form selection, followed by original-data refits.
=== ensemble__02of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/ensemble__02of03/candidates.jsonl): **86 candidates covering all 556 levers**.

| Status | Candidates |
|---|---:|
| testable_now | 74 |
| needs_external_data | 5 |
| closed_family | 4 |
| out_of_scope | 2 |
| already_done | 1 |

Top 10 testable candidates, ranked:

1. Equal pooling across distinct feature/model families — medium.
2. Simplex weights shrunk toward equal weighting — medium.
3. Weights using shrunk residual covariance — medium.
4. Blend short and long training histories — low.
5. Median and trimmed probability pools — low.
6. Bag causal feature/lookback subsets — low.
7. Blend own-pair and cross-pair feature experts without pooled training — low.
8. Fixed seed and time-block bagging — low.
9. Correct forecasts using fully settled residuals — low.
10. Small nonlinear corrections around a simple baseline — low.

All seven medium-prior candidates have verified quotations and pages. None is rated high. Build and compute hours are `null` because they are unbenchmarked.
=== ensemble__03of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/ensemble__03of03/candidates.jsonl): **91 candidates covering all 556 levers**, each assigned once.

| Status | Count |
|---|---:|
| testable_now | 59 |
| needs_external_data | 6 |
| closed_family | 18 |
| out_of_scope | 4 |
| already_done | 4 |

Five medium-prior candidates have verified source quotes; none received a high prior.

Top 10 testable candidates, ranked:

1. **Equal family pool** — average separately fitted tree and linear probabilities.
2. **Shrunk static stack** — constrain proper-score weights toward equality.
3. **Training-window pool** — combine short, long and expanding histories.
4. **Incremental diversity selection** — require marginal held-out value from additions.
5. **Family-balanced pool** — prevent correlated variants from dominating.
6. **Temporal block bagging** — vary historical exposure using contiguous masks.
7. **Pooling geometry** — compare arithmetic, logit and probit aggregation.
8. **Robust probability pool** — test median and trimmed means.
9. **Randomized-tree challengers** — test RF/ExtraTrees complementarity with LightGBM.
10. **Diagonal error weights** — weight by past Brier losses without covariance inversion.

The first four have medium priors; the remaining six are low.
=== features__01of05
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/features__01of05/candidates.jsonl): **108 candidates covering all 653 levers exactly once**.

| Status | Candidates |
|---|---:|
| testable_now | 73 |
| needs_external_data | 18 |
| closed_family | 10 |
| out_of_scope | 3 |
| already_done | 4 |

Top 10 testable candidates, ranked:

1. **Round-level response** — causal approach, touch and crossing features; medium.
2. **Compact return kernels** — replace redundant indicators; medium.
3. **Ridge/elastic-net baseline** — constrain weak-signal estimation; medium.
4. **Same-clock returns** — prior-day continuation versus recent reversal; low.
5. **Common-USD residuals** — test individual-pair correction; low.
6. **Event-clock histories** — price-change sampling with UTC expiry; low.
7. **Quote-reflection augmentation** — coherent symmetry with ties preserved; low.
8. **Signed run asymmetry** — continuation, alternation and zero states; low.
9. **Record-duration asymmetry** — signed drawup/drawdown summaries; low.
10. **Bounded trend response** — constrained continuation/reversion interactions; low.

All eight medium-prior candidates have source-verified page quotes. None received a high prior. Build costs are estimates; compute hours remain null because runtime is unknown.
=== features__02of05
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/features__02of05/candidates.jsonl): 156 candidates covering all 653 levers exactly once.

Counts: **101 testable_now**, 37 needs_external_data, 11 closed_family, 4 already_done, 3 out_of_scope.

Top 10 testable candidates, all with **low direction priors**:

1. Post-fix reversal conditioned on the pre-fix move.
2. Local sessions and London/NY DST mismatch.
3. Per-pair ridge/logistic shrinkage.
4. Common-USD factor and signed residuals.
5. Volatility-normalized leader shocks.
6. Signed small-move consistency.
7. Lagged signed price innovations.
8. Group and fused-lag shrinkage.
9. Fixed smooth lag compression.
10. Time-augmented path signatures.

Five magnitude/validation candidates receive medium priors; all have raw-text-verified quotes. Compute hours remain null because baseline runtimes are unknown.
=== features__03of05
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/features__03of05/candidates.jsonl): **160 candidates covering all 653 levers**.

| Status | Count |
|---|---:|
| testable_now | 107 |
| needs_external_data | 36 |
| closed_family | 8 |
| out_of_scope | 5 |
| already_done | 4 |

Top 10 testable candidates, all **low prior** for direction:

1. Signed momentum conditioned on path continuity.
2. Separate own return, common USD return, and residual.
3. Fast/slow signed trend agreement.
4. Disjoint signed lag bands.
5. Shrunk VAR innovations.
6. Target-aware low-rank factors.
7. Low-order signed lag compression.
8. Shrunk calendar-phase means and residual returns.
9. Matured-label context encodings.
10. Correlation/session-conditioned peer effects.

Seven magnitude candidates received medium priors; all have verified source-page quotations. No candidate received a high prior.
=== features__04of05
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/features__04of05/candidates.jsonl): **129 candidates**, covering all 653 levers exactly once.

| Status | Candidates |
|---|---:|
| testable_now | 95 |
| needs_external_data | 20 |
| closed_family | 6 |
| out_of_scope | 3 |
| already_done | 5 |

Top 10 testable candidates, in ranked order—all **low prior**:

1. Common-USD factor and signed residual histories.
2. Prewhitened cross-pair innovations.
3. Compact distributed-lag return features.
4. Path sign consistency conditional on cumulative return.
5. Restricted dynamic cross-pair leadership.
6. Signed shock age and decay.
7. Short versus long trend interactions.
8. Interrupted runs, drawdown and recovery stage.
9. Shallow time-augmented path signatures.
10. Mature historical motif probabilities.

Three magnitude/validation candidates received medium priors, each with a page-verified supporting quote. Schema, coverage and ranking checks passed.
=== features__05of05
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/features__05of05/candidates.jsonl): **126 candidates**, covering all **652 levers exactly once**.

| Status | Candidates |
|---|---:|
| testable_now | 83 |
| needs_external_data | 28 |
| closed_family | 9 |
| already_done | 5 |
| out_of_scope | 1 |

Top 10 testable candidates, all with **low direction priors**:

1. Clock-phase dependence: boundary-aligned return lags with shifted-grid controls.
2. Jump response: signed continuation/reversal after common versus isolated shocks.
3. Round-level crossings: normalized distance, crossing direction and age.
4. Session response: prior-session returns around scheduled benchmark windows.
5. Cross-pair lag asymmetry: sparse directed kernels fitted per target.
6. Relative currency strength: USD-oriented ranks and relative displacement.
7. Residual reversion: stable signed deviations after common-factor removal.
8. Trend saturation: bounded momentum interacting with anchor displacement.
9. Signed state interactions: return effects conditional on volatility and session.
10. Trend fit quality: signed slope weighted by path smoothness.

Four magnitude-only candidates receive **medium priors**, each with a verified source quote: truncated RV/jumps, semivariance, trend products and partial variance. Schema, coverage, quote and ranking checks passed.
=== labels__01of01
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/labels__01of01/candidates.jsonl): all 510 levers clustered into 67 candidates.

| Status | Count |
|---|---:|
| testable_now | 44 |
| needs_external_data | 13 |
| already_done | 6 |
| closed_family | 1 |
| out_of_scope | 3 |

Top 10 testable candidates, in ranked order—all low-prior direction hypotheses:

1. **sign-symmetry** — Within-pair sign reflection and odd momentum mappings.
2. **ordinal-return-bins** — Coherent signed-return categories preserving ties and magnitude boundaries.
3. **empirical-return-cdf** — Conditional return distributions yielding strict side probabilities.
4. **soft-rate-teacher** — Cross-fitted shrinkage probabilities anchored to actual outcomes.
5. **small-sign-head** — Compact conditional sign models separated from activity.
6. **scaled-residual-target** — Causal volatility normalization, verified against raw settlement outcomes.
7. **joint-expiry-tasks** — Within-pair supervision shared across contractual horizons.
8. **smoothed-auxiliary** — Auxiliary trend predictions evaluated exclusively on actual expiry outcomes.
9. **expiry-convergence** — Empirical spread convergence mapped to target-leg direction.
10. **entry-reaction-persistence** — Causal breakout/pullback timing with fresh fixed-expiry labels.

All five medium-prior candidates have page-verified quotes; they concern magnitude measurement or validation. No high priors were assigned. No backtests were run.
=== loss__01of02
Created [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/loss__01of02/candidates.jsonl): **114 candidates covering all 394 levers**.

Counts: **84 testable_now · 7 needs_external_data · 16 closed_family · 5 out_of_scope · 2 already_done**.

All five medium-prior candidates have verified page quotes; none received a high prior.

Top 10 testable candidates, in rank order:

1. **Dense L2 direction logits** — retain diffuse weak signals; medium prior.
2. **Brier versus log-loss training** — bounded proper-loss comparator; low prior.
3. **Ex-ante inverse-variance regression** — reduce noisy-return influence; low prior.
4. **Recency-weighted loss** — discount stale relationships; low prior.
5. **Huber signed-return regression** — limit extreme-observation influence; low prior.
6. **Capped worst-window reweighting** — reduce reliance on favorable periods; low prior.
7. **Matched classifier versus return regressor** — compare targets directly; low prior.
8. **Shared-expiry tree partitions** — share supervision across eligible horizons; low prior.
9. **Joint sign/magnitude trees** — test auxiliary supervision for incremental SIGN; low prior.
10. **Sparse L1/elastic-net logits** — test a small stable feature subset; low prior.
=== loss__02of02
Created [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/loss__02of02/candidates.jsonl), covering all **394 levers** in **136 candidates**.

Counts: **109 testable_now**, **8 needs_external_data**, **14 closed_family**, **2 out_of_scope**, **3 already_done**.

Top 10 testable candidates, direction first:

1. Ridge/elastic-net logistic baseline — medium.
2. Brier versus binary log-loss fitting — medium.
3. Exponential recency weighting — low.
4. Bounded learnability-based sample weights — low.
5. Causal inverse-variance weighting — low.
6. Group/fused penalties over lag coefficients — low.
7. Mild label smoothing with recalibration — low.
8. Shared tree partitions across expiry heads — low.
9. Capped return-magnitude training weights — low.
10. Proper sign loss plus magnitude auxiliary supervision — low.

All seven medium/high priors have verified source-page quotes. The only high prior concerns probability-target correctness, not directional alpha.
=== magnitude__01of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/magnitude__01of03/candidates.jsonl): **154 candidates covering all 663 levers**.

Counts: **123 testable_now**, **21 needs_external_data**, **5 closed_family**, **5 already_done**, **0 out_of_scope**. All 11 medium-prior candidates have verified source quotes; none has a high prior. Unknown build/compute hours are null.

Top 10, with sign-capable tests first:

1. `factor-quantile` — Signed factor-quantile CDF; SIGN unverified, low prior.
2. `coherent-cdf` — Joint strict-sign, tie and magnitude probabilities; SIGN unverified, low.
3. `seasonal-scale` — Expiry-integrated seasonal scale adjustment; SIZE, medium.
4. `har-scale` — Regularized multiscale realized-variance forecast; SIZE, medium.
5. `ewma-mixture` — Fast/slow volatility-memory mixture; SIZE, medium.
6. `garch` — Constrained conditional-volatility benchmark; SIZE, medium.
7. `monotone-exceedance` — Coherent nested threshold probabilities; SIZE, medium.
8. `filtered-historical` — Recursive volatility-scaled residual simulation; SIZE, medium.
9. `isotonic-cdf` — Distributional calibration of a frozen scale score; SIZE, medium.
10. `jump-continuous` — Separate continuous and jump variation; SIZE, medium.
=== magnitude__02of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/magnitude__02of03/candidates.jsonl): all 663 levers clustered into 127 candidates.

Counts: **100 testable_now · 12 needs_external_data · 10 closed_family · 4 out_of_scope · 1 already_done**.

Top 10 testable candidates, with exploratory direction ideas first:

1. Asymmetric tail classifiers — SIGN, low prior.
2. Joint signed-return density with tie atom — SIGN, low.
3. Shrunk linear return/scale heads — SIGN, low.
4. Properly scored terminal-exceedance classifier — SIZE, medium.
5. Clock seasonality × recent volatility — SIZE, medium.
6. Frequently refitted ridge HAR — SIZE, medium.
7. Fixed exponential variance bank — SIZE, medium.
8. Dynamic scale with empirical residual tails — SIZE, medium.
9. Causal cross-pair volatility factor — SIZE, medium.
10. Realized-GARCH/HEAVY updates — SIZE, medium.

All 10 medium-prior candidates have verified page quotes. None received a high prior. Full row mapping is in [synthesis_audit.json](/mnt/data/deriv-sota-lab/literature/synthesis/work/magnitude__02of03/synthesis_audit.json).
=== magnitude__03of03
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/magnitude__03of03/candidates.jsonl): 124 candidates covering all 663 levers.

Counts: **98 testable_now**, **14 needs_external_data**, **7 closed_family**, **2 out_of_scope**, **3 already_done**. All 11 medium-prior candidates have verified page quotes. Every direction hypothesis has a low prior.

Top 10 testable candidates, in file order:

1. Noncrossing return-quantile CDF — sign/size, low.
2. Joint location-scale boosting — sign/size, low.
3. Transformation forest — sign/size, low.
4. Signed-return ridge regression — direction, low.
5. Auxiliary magnitude supervision — direction regularization, low.
6. Event-sign renewal model — direction hypothesis, low.
7. Quantized-return Markov model — sign/size, low.
8. Pair-specific HAR scale baseline — magnitude, medium.
9. Filtered historical residual CDF — magnitude, medium.
10. EW absolute-return scale — magnitude, medium.
=== regime__01of02
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/regime__01of02/candidates.jsonl): **128 candidates covering all 550 levers**.

| Status | Count |
|---|---:|
| testable_now | 89 |
| needs_external_data | 31 |
| closed_family | 5 |
| out_of_scope | 0 |
| already_done | 3 |

Top 10 testable candidates, all with **low direction priors**:

1. Predictable versus surprise volatility interacting with signed returns.
2. Common USD momentum interacting with pair-specific reversal.
3. Trend conditioned on drawdown and volatility.
4. Shock continuation/reversal by initial direction and elapsed time.
5. Extreme signed session displacement as a continuation interaction.
6. Regularized routing between momentum and reversal experts.
7. Shrunk state-specific UP/DOWN probabilities with asymmetric responses.
8. Conservative recency weighting and LightGBM refit schedules.
9. State-similarity training weights with effective-sample constraints.
10. Small delayed-feedback correction to frozen direction probabilities.

Six size/validation candidates received medium priors; all six have source-verified quotations and page references. No candidate received a high prior.
=== regime__02of02
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/regime__02of02/candidates.jsonl): **549 levers → 133 candidates**, with complete provenance.

| Status | Count |
|---|---:|
| testable_now | 95 |
| needs_external_data | 28 |
| closed_family | 5 |
| already_done | 3 |
| out_of_scope | 2 |

All seven medium-prior candidates have verified source quotations. None received a high prior.

Top 10 testable candidates, all **low prior**:

1. Fast/slow signed-return agreement, correction and rebound.
2. Causal changepoint severity interacting with signed trend.
3. Smooth state-dependent momentum/reversal coefficients.
4. Signed shock continuation versus recovery by shock age.
5. Causal cross-pair residual bands for reversion.
6. Failed range breaks versus persistent breakouts.
7. Shrunk session-dependent signed responses.
8. Common currency state interacting with momentum.
9. Lagged realized momentum/reversal skill.
10. Rolling versus expanding fitting histories.
=== selection-gating__01of02
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/selection-gating__01of02/candidates.jsonl): **108 candidates covering all 617 levers**. All six medium-prior candidates have verified verbatim quotes and pages.

| Status | Candidates |
|---|---:|
| testable_now | 67 |
| needs_external_data | 28 |
| closed_family | 8 |
| already_done | 3 |
| out_of_scope | 2 |

Top 10 testable candidates, all with **low prior**:

1. Cross-fitted correctness meta-filter.
2. Fast/slow signed-trend interactions.
3. Stable cross-pair lead–lag gate.
4. Expiry-compatible residual reversion with uncertainty rejection.
5. Currency-oriented cross-pair confirmation.
6. Visibility-weighted signed amplitude/frequency gate.
7. Range-contraction breakout with completed-bar confirmation.
8. Shallow direct-payoff policy with abstention.
9. Delayed-loss selector among existing forecasts.
10. Regularized logistic sign baseline.

Every input row is mapped in [lever_assignments.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/selection-gating__01of02/lever_assignments.jsonl).
=== selection-gating__02of02
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/selection-gating__02of02/candidates.jsonl): **617 levers → 128 candidates**, with every input assigned exactly once.

| Status | Count |
|---|---:|
| testable_now | 99 |
| needs_external_data | 16 |
| closed_family | 3 |
| out_of_scope | 6 |
| already_done | 4 |

Top 10 testable candidates, direction first—all **low prior**:

1. Cross-fitted routing by incremental expert benefit.
2. Residual-reversion gate matched to expiry.
3. Sparse cross-pair predictor selection.
4. Opening and session-to-date sign agreement.
5. Joint direction and coverage-constrained selection.
6. Signal-response decay aligned with expiry.
7. Supervised Rise/Fall/wait policy.
8. USD-oriented relative momentum context.
9. Volatility-normalized inward recross.
10. Fixed small portfolio of tabular defaults.

All eight medium-prior gate/validation candidates have source-verified quotations and pages. Schema, source coverage and ranking checks passed; no Deriv experiments were run.
=== sizing__01of01
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/sizing__01of01/candidates.jsonl): **192 levers clustered into 41 candidates**, with complete coverage checked.

Counts: **36 testable_now**, **1 needs_external_data**, **0 closed_family**, **3 out_of_scope**, **1 already_done**.

No new SIGN mechanism is supported. All 11 medium-priority candidates have verified page quotes; none received a high prior.

Top 10 testable candidates, ranked:

1. **Uncertainty edge gate — medium:** abstain when calibration uncertainty consumes the payout edge.
2. **Outstanding-stake cushion — medium:** reserve pending maximum losses against the drawdown budget.
3. **Currency exposure caps — medium:** constrain long and short currency buckets separately.
4. **Capped fractional Kelly — medium:** use calibrated probabilities, asymmetric payouts and explicit cash.
5. **Binary payoff covariance — medium:** regularize actual contract-loss dependence.
6. **Residual risk floor — medium:** prevent factor compression from inventing risk-free combinations.
7. **Joint log-wealth allocation — low:** size concurrent contracts from joint settlement scenarios.
8. **Baseline exposure shrinkage — low:** damp noisy allocation changes.
9. **Dependence cluster budgets — low:** share risk budgets among correlated signals.
10. **Empirical co-loss network — low:** constrain pairs with persistent joint binary losses.
=== validation__01of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__01of10/candidates.jsonl): **99 candidates covering all 686 levers**.

| Status | Count |
|---|---:|
| testable_now | 67 |
| already_done | 7 |
| needs_external_data | 14 |
| closed_family | 7 |
| out_of_scope | 4 |

Top 10 testable candidates, in ranked order:

1. Regularized linear sign baseline — low prior.
2. Recalibration-controlled logit pooling — low.
3. Fixed-seed LightGBM ensemble — low.
4. Causal trailing-scale normalization — low.
5. Rolling versus expanding refit policy — low.
6. Recover eligible inner-validation training rows — low.
7. Raw versus smoothed probabilities — low.
8. Future-magnitude scoring robustness — medium; SIZE only.
9. Perturbation-based correctness gate — low; gating only.
10. Simple magnitude benchmarks — low; SIZE only.

All **14 medium-prior candidates** have source-verified quotations. No direction candidate received a medium or high prior.
=== validation__02of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__02of10/candidates.jsonl): all 686 levers mapped into 112 candidates.

Counts: **88 testable_now**, **14 needs_external_data**, **4 closed_family**, **4 out_of_scope**, **2 already_done**. All 17 medium-prior candidates have page-verified quotes; none received high prior.

Top 10 testable candidates, all low-prior direction experiments:

1. Rolling versus expanding training history.
2. Contract-aware parsimonious direction baselines.
3. Ensemble complementarity with duplicate-member controls.
4. Maturity-safe online recalibration and retraining.
5. Expiry-specific signal validation.
6. Future-sign residual tests using current features.
7. Frozen-core feature and interaction ablations.
8. Shock continuation/reversal after feasible entry.
9. Residual convergence against actual binary labels.
10. Within-pair horizon sharing with full overlap purging.
=== validation__03of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__03of10/candidates.jsonl): **92 candidates covering all 685 levers**. Verified source-page quotations for all 22 medium/high-prior candidates.

Counts: **64 testable_now**, **16 needs_external_data**, **5 closed_family**, **4 already_done**, **3 out_of_scope**.

Top 10, ordered by direction hypotheses, magnitude/gating, then validation:

1. Recent versus expanding training windows — SIGN hypothesis; low.
2. Regularized price and constant-action baselines — SIGN comparator; low.
3. Block-stable feature selection — SIGN hypothesis; low.
4. Shrunken cross-pair magnitude additions — SIZE only; low.
5. Uncertainty gates evaluated at matched coverage — selection; low.
6. Search-wide Romano–Wolf correction — validation; high.
7. Complete immutable trial registry — validation; high.
8. Synchronized paired block inference — validation; high.
9. Exact tick entry/expiry and losing-tie replay — validation; medium.
10. Nested feature, ensemble, calibration and gate selection — validation; medium.

High priors concern certification quality. No candidate establishes a new Deriv direction edge.
=== validation__04of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__04of10/candidates.jsonl): **125 candidates covering all 685 levers**. All 15 medium/high candidates have verified source quotes.

| Status | Count |
|---|---:|
| testable_now | 94 |
| needs_external_data | 15 |
| closed_family | 6 |
| out_of_scope | 4 |
| already_done | 6 |

Top 10 testable candidates, ranked by validation value—not expected directional alpha:

1. **High:** Replay the active search on known sign-null paths.
2. **High:** Apply joint block-bootstrap Reality Check/SPA promotion tests.
3. **High:** Estimate paired uncertainty using synchronized calendar blocks.
4. **High:** Audit dependence among the 15 CPCV paths.
5. **Medium:** Compare CPCV estimates with repeated forward-only development walks.
6. **Medium:** Audit probability reliability near the 0.541 threshold.
7. **Medium:** Select using tie-aware payout utility alongside forecast scores.
8. **Medium:** Maintain a complete preregistered research-family ledger.
9. **Medium:** Require complex gates to beat cheap volatility/activity controls.
10. **Medium:** Separate sign dependence from magnitude dependence and base rates.

None establishes a verified new sign predictor.
=== validation__05of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__05of10/candidates.jsonl): **110 candidates covering all 685 levers**. All 16 medium-prior entries have verified source quotes. Direction ideas remain low prior.

Counts: **88 testable_now · 11 needs_external_data · 3 closed_family · 8 already_done · 0 out_of_scope**

Top 10 testable candidates, in ranked file order:

1. Regularized logistic direction benchmark — reduce estimation variance.
2. Forecast encompassing — test incremental information in existing forecasts.
3. Low-capacity calibration — audit probabilities near break-even.
4. Relative versus within-pair returns — separate relative exposure from timing.
5. Sparse cross-pair lag network — permit no predictive edges.
6. Training-window and refresh policy — test adaptation against expanding history.
7. Shallow spline comparator — screen constrained nonlinear models.
8. Empirical magnitude baseline — benchmark flexible size forecasts.
9. Conditional gate payoff — require size selection to improve binary utility.
10. Matched-coverage policy evaluation — score complete abstention and repeated-entry rules.
=== validation__06of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__06of10/candidates.jsonl): all **685 levers** mapped to **79 candidates**. All 11 medium-prior candidates have page-verified quotes; none received a high prior.

| Status | Candidates |
|---|---:|
| `testable_now` | 50 |
| `needs_external_data` | 14 |
| `closed_family` | 6 |
| `already_done` | 5 |
| `out_of_scope` | 4 |

Top 10 testable candidates, in rank order:

1. Recent-window refitting — direction probe; low prior.
2. Conditional cross-pair innovations — direction probe; low.
3. Matured out-of-time forecast blends — direction probe; low.
4. Confirmed swing-anchor controls — direction probe; low.
5. Magnitude alarms at matched coverage — SIZE only; low.
6. Synchronized block inference — certification uncertainty; medium.
7. Research registry and selection adjustment — false-promotion control; medium.
8. Rise/Fall selected-trade calibration — actionable probability audit; medium.
9. Leave-one-episode-out influence audit — concentrated-edge detection; medium.
10. Payout-threshold proper scores — decision-relevant model comparison; medium.
=== validation__07of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__07of10/candidates.jsonl): **118 candidates covering all 685 levers**.

Counts: **87 testable now**, 15 need external data, 8 closed family, 6 already done, 2 out of scope. All 10 medium-prior candidates have verified source quotes; none received a high prior.

Top 10 testable candidates, all with low directional priors:

1. Regularized logistic comparator at matched coverage.
2. Base-score-conditioned residual correction.
3. Reduced tree and rule complexity.
4. Smoothed return-state transition baseline.
5. Seasonality-neutralized session continuation.
6. Frozen equal-weight versus selected-expert ensemble.
7. Restricted rolling-history and decay comparison.
8. Conventional ridge return-lag baseline.
9. Matched volatility treatment for linear/tree comparisons.
10. Past-fit cross-pair residual reversal test.
=== validation__08of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__08of10/candidates.jsonl): **97 candidates covering all 685 levers**.

Counts: **80 testable_now**, **8 needs_external_data**, **2 closed_family**, **4 out_of_scope**, **3 already_done**.

All 24 medium-prior candidates have verified source quotations and pages. Every direction candidate has a low prior.

Top 10 testable candidates, in rank order:

1. Cross-pair lag encompassing — low; target-specific directional comparison.
2. Compact classifiers — low; matched controls against LightGBM.
3. Training-window and refit cadence — low; test directional decay.
4. Ensemble encompassing — low; require complementary signed information.
5. Relaxed sparse logistic refits — low; reduce estimation error.
6. Mean-drift ablation — low; separate direction from volatility adaptation.
7. Cross-horizon blending — low; test incremental endpoint information.
8. Fixed-event forecast smoothing — low; test probability revisions.
9. Selected-trade calibration — medium; audit reliability after gating.
10. Payout-threshold abstention — low; optimize fixed-payout utility.
=== validation__09of10
Wrote [candidates.jsonl](/mnt/data/deriv-sota-lab/literature/synthesis/work/validation__09of10/candidates.jsonl): **116 candidates covering all 685 levers**, with no duplicate assignments.

| Status | Count |
|---|---:|
| testable_now | 88 |
| needs_external_data | 13 |
| closed_family | 4 |
| out_of_scope | 6 |
| already_done | 5 |

All 16 medium-prior candidates have source-verified quotes. No direction proposal received a medium or high prior.

Top 10 testable candidates, in file order—all low-prior:

1. Parsimonious signed-lag logistic/spline benchmark.
2. State-conditional comparison and restricted forecast switching.
3. Past-only residual correction and shrunken stacking.
4. Compact models with shared parameter defaults.
5. Frozen versus scheduled refitting.
6. Fixed random-feature ridge control.
7. Input aggregation at unchanged expiry.
8. Clock-conditioned empirical magnitude baseline.
9. Calibrated fixed-payout abstention control.
10. Matched-coverage gate and complete alarm evaluation.
=== validation__10of10
Wrote [candidates.jsonl](candidates.jsonl): **81 candidates covering all 685 levers**.

Counts: **60 testable_now**, 9 needs_external_data, 5 already_done, 5 closed_family, 2 out_of_scope. All 14 medium/high-prior claims have verified source-page quotes.

Top 10 testable candidates, in the requested direction-first order—all low prior:

1. Conditional feature lift beyond the current calibrated model.
2. Sign-versus-size audit of claimed direction signals.
3. Signal decay at exact 15m+ expiries.
4. Cross-pair nulls preserving persistence and common shocks.
5. Event aftereffects versus matched volatility/activity controls.
6. Finite-sample calibration of sign-history depth.
7. Direct versus recursive simple horizon forecasts.
8. Causal historical analogs versus random matched histories.
9. Candle-context interaction ablation.
10. Retracement levels versus generic price-level placebos.

The strongest evidence supports certification safeguards; it does not establish a new Deriv direction signal.
